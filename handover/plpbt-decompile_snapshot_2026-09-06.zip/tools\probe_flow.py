#!/usr/bin/env python3
"""Log allocator calls + draw entries with bounded run; dump offscreen after 1st draw."""
import sys, os, struct
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from unicorn import *
from unicorn.x86_const import *
from bootlab import Plop
_xc = sys.modules['unicorn.x86_const']
for _n in dir(_xc):
    if _n.startswith('UC_X86_REG_'):
        globals()[_n[3:]] = getattr(_xc, _n)

def build_disk():
    disk = bytearray(8*1024*1024)
    mbr = bytearray(512); mbr[446]=0x80; mbr[447:450]=bytes([0,1,1]); mbr[450]=0x06
    mbr[451:454]=bytes([15,63,63]); mbr[454:458]=struct.pack('<I',63); mbr[458:462]=struct.pack('<I',1022)
    mbr[510:512]=b'\x55\xAA'; disk[0:512]=mbr
    pbs=bytearray(512); pbs[510:512]=b'\x55\xAA'; disk[63*512:64*512]=pbs
    return bytes(disk)

p = Plop(load_seg=0x7C00, entry=0x8BE, edd_type='ATA', max_insns=12_000_000)
p.bios.disk_attach(build_disk())
base = 0x7C00<<4
W,H = 80*8, 25*8
def mkdesc(size):
    d = bytearray(0x25)
    struct.pack_into('<I', d, 0x00, size)
    struct.pack_into('<H', d, 0x14, W)
    struct.pack_into('<H', d, 0x16, H)
    d[0x18]=1
    struct.pack_into('<H', d, 0x19, W)
    struct.pack_into('<H', d, 0x1B, 0)
    struct.pack_into('<H', d, 0x1D, H)
    struct.pack_into('<H', d, 0x1F, W)
    struct.pack_into('<H', d, 0x21, H)
    struct.pack_into('<H', d, 0x23, 0)
    return bytes(d)
p.uc.mem_write(base+0x9A26, mkdesc(0x2320))
p.uc.mem_write(base+0x9A4B, mkdesc(0x1000))
p.uc.mem_write(base+0xB732, bytes(bytearray(0x39)))
p.uc.mem_write(base+0xB76B, bytes(bytearray(0x39)))

log=[]
def code(uc, addr, size, ud):
    off=addr-base
    if off==0x6481:
        bp=uc.reg_read(X86_REG_BP)&0xFFFF; si=uc.reg_read(X86_REG_SI)&0xFFFF
        sz=struct.unpack('<I', bytes(uc.mem_read(base+bp,4)))[0]
        cur=struct.unpack('<I', bytes(uc.mem_read(base+0xAB4D,4)))[0]
        log.append('alloc bp=%04X si=%04X size=0x%X (cursor was 0x%X)'%(bp,si,sz,cur))
    if off==0x5EC2:
        ab6a=struct.unpack('<I', bytes(uc.mem_read(base+0xAB6A,4)))[0]
        ab62=struct.unpack('<H', bytes(uc.mem_read(base+0xAB62,2)))[0]
        ab74=struct.unpack('<H', bytes(uc.mem_read(base+0xAB74,2)))[0]
        log.append('DRAW 5EC2 ab6a=0x%X w=%d h=%d'%(ab6a,ab62,ab74))
    if off in (0x172E,0x6317,0x833D,0x1278,0x1271):
        log.append('  KEYPOLL %04X ax=%04X'%(off, uc.reg_read(X86_REG_AX)&0xFFFF))
    if off==0x664D:
        log.append('  664D-loop edi=%08X ecx=%08X'%(uc.reg_read(X86_REG_EDI), uc.reg_read(X86_REG_ECX)))
p.uc.hook_add(UC_HOOK_CODE, code)
r=p.run()
print('run:', r[:130])
for l in log[:60]: print(' ', l)
print('int16 count:', sum(1 for t in p.bios.int_trace if t[0]==0x16))
