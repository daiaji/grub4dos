#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Full EHCI async-list evidence probe (2nd gen):
- qTD chain walk with terminate-bit handling (no more false qTD@1 rows)
- endpoint-characteristics decode (device addr / EP number / speed / max packet)
- 0x200-byte pool dump around the async list (QH + any qTD pool)
- hookseg tail-trace with tick stamps (where the module stopped)
Runs the same 400M-insn path as probe_ehci_qh.py so the state matches."""
import os, sys, struct
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bootlab
from bootlab import Plop

last = []                       # (ticks, ip) for hookseg execs
def eh(uc, cs_off):
    cs = uc.reg_read(bootlab.X86_REG_CS)
    ip = uc.reg_read(bootlab.X86_REG_IP)
    if cs == 0x9A70:
        t = p.ticks_fired if hasattr(p, 'ticks_fired') else -1
        last.append((t, ip))
        if len(last) > 3000:
            last.pop(0)

p = Plop(keys='u', edd='USBD', tick_insns=200_000, feed_watchdog=True,
         hook_extra=eh, max_insns=400_000_000)
p.bios.disk_attach(bootlab.default_disk())
r = p.run()
print('run:', r, flush=True)

def d16(a):  return struct.unpack('<H', bytes(p.uc.mem_read(a, 2)))[0]
def d32(a):  return struct.unpack('<I', bytes(p.uc.mem_read(a, 4)))[0]

reg = bytes(p.uc.mem_read(bootlab.Bios.PCI_EHCI_BAR + 0x10, 0x30))
print('EHCI op regs:', reg.hex(' '), flush=True)
asynclist = d32(bootlab.Bios.PCI_EHCI_BAR + 0x10 + 0x18)
print('ASYNCLISTADDR = %08X' % asynclist, flush=True)
if asynclist:
    print('--- QH chain (async list) ---', flush=True)
    q = asynclist
    eps = {}
    for depth in range(8):
        d = [d32(q + 4*i) for i in range(0x20 // 4)]
        h, ep, cap, cur = d[0], d[1], d[2], d[3]
        ov = d[4:]                     # overlay: next, alt, token, buf0..buf4
        spd = {0: 'full', 1: 'low', 2: 'high'}.get((ep >> 12) & 3, '?')
        mps = (ep >> 16) & 0x7FF
        eps[q] = (ep & 0x7F, (ep >> 8) & 0xF)   # device addr, EP number
        print('QH@%08X h=%08X dev=%d ep=%d spd=%s mps=%d '
              'cur=%08X ov_n=%08X ov_a=%08X tok=%08X'
              % (q, h, ep & 0x7F, (ep >> 8) & 0xF, spd, mps,
                 cur, ov[0], ov[1], ov[2]), flush=True)
        if ov[0] & 1:                   # overlay next = terminate -> no qTD
            print('  overlay: no qTD (next=%08X)' % ov[0], flush=True)
        else:
            t = ov[0] & ~0x1F
            for tdepth in range(4):
                if not t:
                    break
                td = [d32(t + 4*i) for i in range(0x20 // 4)]
                print('  qTD@%08X n=%08X alt=%08X tok=%08X b0=%08X b1=%08X'
                      % (t, td[0], td[1], td[2], td[3], td[4]), flush=True)
                if td[0] & 1:
                    break
                t = td[0] & ~0x1F
        q = h & ~0x1F
        if h & 1 or q == asynclist or q == 0:
            break
    print('QH -> (dev,ep) map:', {hex(k): v for k, v in eps.items()}, flush=True)
    print('--- pool 0x%X..0x%X ---' % (asynclist & ~0xF, asynclist + 0x200),
          flush=True)
    base = asynclist & ~0xFF
    for off in range(0, 0x200, 0x10):
        row = bytes(p.uc.mem_read(base + off, 0x10))
        stars = ' <-QLIST' if base + off == asynclist else ''
        print('%06X  %s%s' % (base + off, row.hex(' '), stars), flush=True)

# driver data slots (same reader as probe_ehci_qh.py)
es = d16(p.base + 0x2B9A)
print('driver ES=%04X (from [0x2b9a], base [0x2b96]=%04X)' %
      (es, d16(p.base + 0x2B96)), flush=True)
print('ES:0000..:', bytes(p.uc.mem_read(es * 16, 0x20)).hex(' '), flush=True)
print('ES:0080..:', bytes(p.uc.mem_read(es * 16 + 0x80, 0x40)).hex(' '), flush=True)
print('[CF43]=%d [CF44]=%d' % (d16(p.base + 0xCF43), d16(p.base + 0xCF44)),
      flush=True)
print('hooksg execs:', len(last), flush=True)
print('last ips:', [(t, hex(ip)) for t, ip in last[-45:]], flush=True)