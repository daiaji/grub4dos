#!/usr/bin/env python3
"""Probe: does sub_0ED3 fill the window descriptor 0x9A26 / template 0xB732,
and what is [0xB063] at the call site?  (DYNAMIC_FINDINGS hypothesis #3)"""
import sys, os, struct
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from unicorn import *
from unicorn.x86_const import *
from bootlab import Plop
_xc = sys.modules['unicorn.x86_const']
for _n in dir(_xc):
    if _n.startswith('UC_X86_REG_'):
        globals()[_n[3:]] = getattr(_xc, _n)

def build_disk():
    disk = bytearray(8*1024*1024)
    mbr = bytearray(512); mbr[446]=0x80; mbr[447:450]=bytes([0,1,1]); mbr[450]=0x06
    mbr[451:454]=bytes([15,63,63]); mbr[454:458]=struct.pack('<I',63); mbr[458:462]=struct.pack('<I',1022)
    mbr[510:512]=b'\x55\xAA'; disk[0:512]=mbr
    pbs=bytearray(512); pbs[510:512]=b'\x55\xAA'; disk[63*512:64*512]=pbs
    return bytes(disk)

p = Plop(load_seg=0x7C00, entry=0x8BE, edd_type='ATA')
p.bios.disk_attach(build_disk())
base = 0x7C00<<4

events = []
def code(uc, addr, size, ud):
    if addr == base+0x0B3C:          # movzx ax,[0xb063] then call 0xED3
        b063 = uc.mem_read(base+0xB063, 1)[0]
        events.append('@0B3C [0xB063]=%02X ax=%04X' % (b063, uc.reg_read(X86_REG_AX)&0xFFFF))
    if addr == base+0x0ED3:          # sub_0ED3 entry
        events.append('  -> enter 0ED3 ax=%04X si=%04X' % (uc.reg_read(X86_REG_AX)&0xFFFF, uc.reg_read(X86_REG_SI)&0xFFFF))
    if addr == base+0x0F3A:          # sub_0ED3 ret (0F3A = ret)
        events.append('  <- ret 0ED3')
    if addr == base+0x0B44:          # after 0xED3: mov bp,0x9a26
        b063 = uc.mem_read(base+0xB063, 1)[0]
        n9 = struct.unpack('<I', bytes(uc.mem_read(base+0x9A26, 4)))[0]
        t32 = bytes(uc.mem_read(base+0xB732, 16))
        events.append('@0B44 [0xB063]=%02X 0x9A26=%08X tmpl16=%s' % (b063, n9, t32.hex()))
        uc.emu_stop()
p.uc.hook_add(UC_HOOK_CODE, code)
r = p.run()
print('run:', r[:80])
for e in events: print(e)
