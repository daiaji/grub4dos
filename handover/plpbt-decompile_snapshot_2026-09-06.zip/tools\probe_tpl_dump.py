#!/usr/bin/env python3
"""Dump the 0xB732 template + geometry vars right after sub_6481 alloc#1 and at
sub_5EC2 draw entry, to see exactly what bytes the emulated boot has vs what
the draw code expects.  Goal: pin down the correct loader-preset template."""
import sys, os, struct
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from unicorn import *
from unicorn.x86_const import *
from bootlab import Plop
_xc = sys.modules['unicorn.x86_const']
for _n in dir(_xc):
    if _n.startswith('UC_X86_REG_'):
        globals()[_n[3:]] = getattr(_xc, _n)

def build_disk():
    disk = bytearray(8*1024*1024)
    mbr = bytearray(512); mbr[446]=0x80; mbr[447:450]=bytes([0,1,1]); mbr[450]=0x06
    mbr[451:454]=bytes([15,63,63]); mbr[454:458]=struct.pack('<I',63); mbr[458:462]=struct.pack('<I',1022)
    mbr[510:512]=b'\x55\xAA'; disk[0:512]=mbr
    pbs=bytearray(512); pbs[510:512]=b'\x55\xAA'; disk[63*512:64*512]=pbs
    return bytes(disk)

def hexw(base, off, n=0x39):
    raw = bytes(p.uc.mem_read(base+off, n))
    return ' '.join('%02X'%b for b in raw)

p = Plop(load_seg=0x7C00, entry=0x8BE, edd_type='ATA', max_insns=80_000_000)
p.bios.disk_attach(build_disk())
base = 0x7C00<<4
W,H = 80*8, 25*8

def mkdesc(size):
    d = bytearray(0x25)
    struct.pack_into('<I', d, 0x00, size)
    struct.pack_into('<H', d, 0x08, 0)      # AB5E
    struct.pack_into('<H', d, 0x0A, 0)      # AB60
    struct.pack_into('<H', d, 0x0C, 0)      # AB56
    struct.pack_into('<H', d, 0x0E, 0)      # AB58
    struct.pack_into('<H', d, 0x10, 0)      # AB5A
    struct.pack_into('<H', d, 0x12, 0)      # AB5C
    struct.pack_into('<H', d, 0x14, W)      # AB62 screen width px
    struct.pack_into('<H', d, 0x16, H)      # AB64 screen height px
    d[0x18] = 1                             # AB7A border flag
    struct.pack_into('<H', d, 0x19, W)      # AB7B box width
    struct.pack_into('<H', d, 0x1B, 0)      # AB72
    struct.pack_into('<H', d, 0x1D, H)      # AB74
    struct.pack_into('<H', d, 0x1F, W)      # AB76 stride
    struct.pack_into('<H', d, 0x21, H)      # AB78 box height
    struct.pack_into('<H', d, 0x23, 0)      # AB81
    return bytes(d)

p.uc.mem_write(base+0x9A26, mkdesc(0x2320))
p.uc.mem_write(base+0x9A4B, mkdesc(0x1000))
p.uc.mem_write(base+0xB732, bytes(bytearray(0x39)))
p.uc.mem_write(base+0xB76B, bytes(bytearray(0x39)))

def geom():
    out=[]
    for o in (0xab56,0xab58,0xab5a,0xab5c,0xab5e,0xab60,0xab62,0xab64,
              0xab72,0xab74,0xab76,0xab78,0xab7a,0xab7b,0xab81,0xab4d,0xab53):
        out.append('[%04X]=%04X'%(o, struct.unpack('<H', bytes(p.uc.mem_read(base+o,2)))[0]))
    return ' '.join(out)

state={'seen_alloc':0, 'seen_draw':0}
def code(uc, addr, size, ud):
    off=addr-base
    if off==0x0B4A and state['seen_alloc']==0:
        state['seen_alloc']=1
        print('== 0x0B4A alloc#1 entry: BP=%04X SI=%04X  template0xB732=%s'%(
            uc.reg_read(X86_REG_BP)&0xFFFF, uc.reg_read(X86_REG_SI)&0xFFFF,
            hexw(base,0xB732)))
    if off==0x0B4D:
        print('== 0x0B4D after alloc#1:')
        print('   template0xB732=%s'%hexw(base,0xB732))
        print('   geom: '+geom())
    if off==0x0B82:
        print('== 0x0B82 alloc#2 entry (BP=%04X SI=%04X)'%(
            uc.reg_read(X86_REG_BP)&0xFFFF, uc.reg_read(X86_REG_SI)&0xFFFF))
    if off==0x0B85:
        print('== 0x0B85 after alloc#2:')
        print('   template0xB76B=%s'%hexw(base,0xB76B))
    if off==0x5EC2 and state['seen_draw']<3:
        state['seen_draw']+=1
        print('== sub_5EC2 draw#%d entry: SI=%04X  [0xAB52]=%s'%(
            state['seen_draw'], uc.reg_read(X86_REG_SI)&0xFFFF, hexw(base,0xAB52,0x39)))
        print('   geom: '+geom())
    if off==0x639A and state['seen_draw']<3:
        print('   -> 0x639A fill: cx=%04X ax=%04X es:di=%04X:%04X'%(
            uc.reg_read(X86_REG_CX)&0xFFFF, uc.reg_read(X86_REG_AX)&0xFFFF,
            uc.reg_read(X86_REG_ES)&0xFFFF, uc.reg_read(X86_REG_DI)&0xFFFF))
p.uc.hook_add(UC_HOOK_CODE, code)
r=p.run()
print('run:', r[:120])
