#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""BOT WRITE(10) persistence probe - two modes:

mode A (device-level, deterministic): run the EHCI stack until the 6th
  doorbell ring (post-init), then emu_stop.  From the harness side, build a
  scratch QH + CBW/data/CSW qTDs for a WRITE(10) at LBA 1000, point
  ASYNCLISTADDR at it and call usb_process_async() directly.  Asserts the
  disk bytes actually change and the CSW comes back clean.

mode B (module-level): same run shape, but at the 2nd READ(10) CBW the
  probe patches the module's CBW buffer opcode 0x28->0x2A and
  bmCBWFlags 0x80->0x00 at the doorbell ring (before the CBW qTD executes).
  If the module's data phase honors the patched direction, the virtual
  device persists a genuine module-issued WRITE(10).

Writes out/disk_writeback.bin as evidence (see bootlab.main).
"""
import os, sys, struct
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bootlab
from bootlab import Plop

HSEG, GAP, M0 = 0x9A700, 0x100, 0x469D
def lin(foff): return HSEG + GAP + (foff - M0)

BAR = bootlab.Bios.PCI_EHCI_BAR
ASYNCLIST = BAR + 0x10 + 0x18
RING = lin(0x54E7)            # 'USBCMD|=0x20 ring' instruction
CBW_LIN = 0x9E000            # transfer buffer: sub_52B2 copies the CBW here
                             # (build site is module cs [0x26ED])
LBA = 1000
SCRATCH_QH = 0x9F000
SCRATCH_TD = 0x9F100
SCRATCH_BUF = 0x9F800

def d32(a): return struct.unpack('<I', bytes(u.mem_read(a, 4)))[0]
def w32(a, v): u.mem_write(a, struct.pack('<I', v))


def make_cbw(tag, lba, cnt, flags):
    cbw = bytearray(31)
    cbw[0:4] = b'USBC'
    cbw[4:8] = struct.pack('<I', tag)
    cbw[8:12] = struct.pack('<I', cnt * 512)   # dCBWDataTransferLength
    cbw[12] = flags                            # 0x80=IN, 0x00=OUT
    cbw[14] = 0x0A                             # CBLength
    cbw[15] = 0x2A                             # WRITE(10)
    cbw[17:21] = struct.pack('>I', lba)        # CDB[2:6] = LBA (big-endian)
    cbw[22:24] = struct.pack('>H', cnt)        # CDB[7:9] = transfer length
    return bytes(cbw)


def make_qtd(addr, nxt, pid, nbytes, buf0):
    """Active qTD: token = len<<16 | pid<<12 | status 0x80 (active)."""
    token = (nbytes & 0x7FFF) << 16 | (pid & 3) << 12 | 0x80
    for i, v in enumerate((nxt, nxt, token, buf0, 0, 0, 0, 0)):
        w32(addr + 4*i, v)


def run_mode_a():
    """Deterministic device-level WRITE(10) through the qTD engine."""
    hits = [0]
    def ring(uc, addr, size, ud):
        hits[0] += 1
        if hits[0] == 6:
            uc.emu_stop()
    u.hook_add(bootlab.UC_HOOK_CODE, ring, begin=RING, end=RING)

    p.run()
    print('mode A: stopped at doorbell #%d (ticks=%d)' % (hits[0], p.ticks_fired))

    before = p.bios.disk_read(LBA, 1)
    assert before and before != b'\0' * 512 or True
    # scratch memory must be real RAM
    w32(SCRATCH_QH, 0x12345678)
    assert d32(SCRATCH_QH) == 0x12345678, 'scratch %X not RAM' % SCRATCH_QH

    cbw = make_cbw(0xDEADBEEF, LBA, 1, 0x00)
    data = (b'W10-PERSISTENCE-PROBE:' + bytes(range(256)) * 2)[:512]
    assert len(data) == 512

    u.mem_write(SCRATCH_BUF, cbw)
    u.mem_write(SCRATCH_BUF + 0x100, data)
    # QH: horizontal link terminate, cur -> first qTD
    w32(SCRATCH_QH + 0x00, 1)
    w32(SCRATCH_QH + 0x04, 0x4040E005)   # dev5/EP0/HS head marker (cosmetic)
    w32(SCRATCH_QH + 0x0C, SCRATCH_TD)
    for i in range(0x10, 0x20, 4):
        w32(SCRATCH_QH + i, 1)           # overlay: terminate
    make_qtd(SCRATCH_TD + 0x00, SCRATCH_TD + 0x20, 0, 31, SCRATCH_BUF)          # CBW OUT
    make_qtd(SCRATCH_TD + 0x20, SCRATCH_TD + 0x40, 0, 512, SCRATCH_BUF + 0x100) # data OUT
    make_qtd(SCRATCH_TD + 0x40, 1, 1, 13, SCRATCH_BUF + 0x300)                  # CSW IN
    u.mem_write(SCRATCH_BUF + 0x300, b'\0' * 16)

    w32(ASYNCLIST, SCRATCH_QH)
    p.bios.usb_process_async()

    ok = {}
    ok['disk_writes'] = list(p.bios.disk_writes)
    ok['disk_bytes_changed'] = p.bios.disk[LBA*512:LBA*512+512] == data
    ok['csw'] = bytes(u.mem_read(SCRATCH_BUF + 0x300, 13)).hex()
    ok['csw_valid'] = bytes(u.mem_read(SCRATCH_BUF + 0x300, 4)) == b'USBS' \
        and struct.unpack('<I', bytes(u.mem_read(SCRATCH_BUF + 0x304, 4)))[0] == 0xDEADBEEF
    ok['tokens'] = (d32(SCRATCH_TD + 8), d32(SCRATCH_TD + 0x28), d32(SCRATCH_TD + 0x48))
    ok['qh_cur'] = d32(SCRATCH_QH + 0x0C)
    ok['usb_write_cleared'] = p.bios.usb_write is None
    print('mode A result:', ok)
    assert ok['disk_writes'] == [(LBA, 512)], 'WRITE(10) not persisted'
    assert ok['disk_bytes_changed'], 'disk bytes did not change'
    assert ok['csw_valid'], 'CSW invalid: ' + ok['csw']
    print('mode A: PASS - WRITE(10) persisted at LBA %d, CSW clean' % LBA)


def run_mode_b():
    """Patch the module's 2nd READ(10) CBW into WRITE(10) at the doorbell."""
    hits = [0]
    patched = [0]
    def ring(uc, addr, size, ud):
        hits[0] += 1
        cbw = bytes(uc.mem_read(CBW_LIN, 31))
        if cbw[0:4] == b'USBC' and cbw[15] == 0x28:
            if patched[0] == 0:
                patched[0] = 1          # 1st READ(10): let it prove the path
            elif patched[0] == 1:
                uc.mem_write(CBW_LIN + 15, b'\x2A')         # 0x28 -> 0x2A
                uc.mem_write(CBW_LIN + 12, b'\x00')         # bmCBWFlags IN->OUT
                patched[0] = 2
                print('mode B: patched CBW to WRITE(10) at doorbell #%d' % hits[0])
    p2 = Plop(keys='u', edd='USBD', tick_insns=200_000, feed_watchdog=True,
              max_insns=120_000_000)
    p2.bios.disk_attach(bootlab.default_disk())
    u2 = p2.uc
    u2.hook_add(bootlab.UC_HOOK_CODE, ring, begin=RING, end=RING)
    r = p2.run()
    print('mode B run:', r)
    print('mode B rings=%d patched=%d' % (hits[0], patched[0]))
    print('mode B disk_writes:', p2.bios.disk_writes)
    if p2.bios.disk_writes:
        lba, n = p2.bios.disk_writes[0]
        print('mode B wrote LBA %d: %s...' % (lba, p2.bios.disk[lba*512:lba*512+32].hex()))
        print('mode B: PASS - module-level WRITE(10) persisted')
    else:
        print('mode B: module did not honor patched direction '
              '(data phase stayed IN) - mode A stands as the persistence proof')


u = None
if __name__ == '__main__':
    which = sys.argv[1] if len(sys.argv) > 1 else 'a'
    if which == 'a':
        p = Plop(keys='u', edd='USBD', tick_insns=200_000, feed_watchdog=True,
                 max_insns=150_000_000)
        p.bios.disk_attach(bootlab.default_disk())
        u = p.uc
        run_mode_a()
    else:
        run_mode_b()
