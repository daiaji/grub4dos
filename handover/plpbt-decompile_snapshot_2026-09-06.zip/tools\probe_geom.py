import sys, struct
import bootlab, unicorn
from unicorn.x86_const import *
_xc = __import__('unicorn.x86_const', fromlist=['x'])
for _n in dir(_xc):
    if _n.startswith('UC_X86_REG_'):
        globals()[_n[3:]] = getattr(_xc, _n)

p = bootlab.Plop(load_seg=0x7C00, entry=0x8BE)
disk = bytearray(8 * 1024 * 1024)
mbr = bytearray(512); mbr[446] = 0x80; mbr[450] = 0x06
mbr[454:458] = struct.pack('<I', 63); mbr[458:462] = struct.pack('<I', 1022)
mbr[510:512] = b'\x55\xaa'
disk[0:512] = mbr
pbs = bytearray(512); pbs[0] = 0xEA; pbs[510:512] = b'\x55\xaa'
disk[63*512:63*512+512] = pbs
p.bios.disk_attach(bytes(disk))

uc = p.uc
base = 0x7C000
# verify write-watch works: watch BOTH 0x9A26 (suspected) and 0xC4EB (known MBR buf)
writes = {'9a26': 0, 'c4eb': 0}
def hw9(u, access, addr, size, val, ud):
    writes['9a26'] += 1
def hw4(u, access, addr, size, val, ud):
    writes['c4eb'] += 1
uc.hook_add(unicorn.UC_HOOK_MEM_WRITE, hw9, begin=base+0x9A26, end=base+0x9AE2)
uc.hook_add(unicorn.UC_HOOK_MEM_WRITE, hw4, begin=base+0xC4EB, end=base+0xC4EB+512)
r = p.run()
print('run:', r[:60])
print('writes: 0x9A26=%d  0xC4EB=%d' % (writes['9a26'], writes['c4eb']))
print('BSS [0xb071]=%02X  [0xb063]=%02X  [0xb062]=%02X' % (
    bytes(uc.mem_read(base+0xB071,1))[0], bytes(uc.mem_read(base+0xB063,1))[0],
    bytes(uc.mem_read(base+0xB062,1))[0]))
print('window-desc output vars at crash:')
for off, name in ((0xAB56,'ab56'),(0xAB5E,'ab5e'),(0xAB60,'ab60'),(0xAB62,'ab62 width'),
                  (0xAB64,'ab64'),(0xAB72,'ab72'),(0xAB74,'ab74 height'),
                  (0xAB76,'ab76'),(0xAB78,'ab78 bh'),(0xAB7A,'ab7a'),(0xAB7B,'ab7b bw')):
    print('  [%s] = %04X' % (name, struct.unpack('<H', bytes(uc.mem_read(base+off,2)))[0]))