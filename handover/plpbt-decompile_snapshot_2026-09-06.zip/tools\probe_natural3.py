#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Natural-entry proof: SETUP screen (0xB7A4) opens from PURE KEYSTROKES.

Path (no far_call anywhere):
  main list, DOWN x5 (sel 1 -> 6), ENTER, ENTER(confirm message window)
  -> SETUP entry (runtime 0x6B64) -> screen draw (runtime 0x6BA3)
  -> window 0xB7A4 stays up.

This is the natural (keyboard) entry into the Setup partition-screen that
the previous rounds could only reach via far_call 0x6BA3.  Runtime
coordinate = file offset + 0x100.
"""
import os, sys, struct
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bootlab
from bootlab import Plop

p = Plop(tick_insns=200_000, feed_watchdog=True, max_insns=400_000_000)
p.bios.disk_attach(bootlab.default_disk())
u = p.uc

def d8(o): return u.mem_read(p.base + o, 1)[0]
def vis():
    out = set()
    for i in range(26):
        d = struct.unpack('<H', bytes(u.mem_read(p.base + 0xA825 + i*2, 2)))[0]
        if 0x1000 < d < 0xC000 and d8(d) & 1:
            out.add(d)
    return out

ENTRY, DRAW = 0x6B64, 0x6BA3        # RUNTIME (file+0x100)
hits = []
seq = ['down']*5 + ['enter', 'enter']
sent, last, n = [0], [0], [0]
st = ['nav']
def extra(uc, cs_off):
    if cs_off in (ENTRY, DRAW):
        if not hits or hits[-1][1] != cs_off:
            hits.append((p.ticks_fired, cs_off))
            print('[HIT %s @%d]' % ('SETUP entry' if cs_off == ENTRY else 'SETUP draw',
                                    p.ticks_fired), flush=True)
    n[0] += 1
    if n[0] < 400_000: return
    n[0] = 0
    v = vis()
    if 0xBC18 in v:                       # confirm popup: close it
        p.bios.key_push(0x011B)
        return
    if st[0] == 'nav':
        if p.ticks_fired > 560 and sent[0] < len(seq) and p.ticks_fired - last[0] >= 40:
            k = seq[sent[0]]; sent[0] += 1; last[0] = p.ticks_fired
            p.bios.key_push(0x5000 if k == 'down' else 0x1C0D)
        elif sent[0] == len(seq):
            st[0] = 'watch'
            print('== nav done @%d, sel=%d, B7A4=%s ==' %
                  (p.ticks_fired, d8(0xC126), 0xB7A4 in v), flush=True)
    elif st[0] == 'watch' and p.ticks_fired % 4 == 0:
        print('tick %d sel=%d vis=%s' % (p.ticks_fired, d8(0xC126),
              sorted(hex(x) for x in v)), flush=True)
        if len(hits) >= 2 and 0xB7A4 in v:
            st[0] = 'done'
            raise SystemExit

p.hook_extra = extra
try:
    r = p.run()
except SystemExit:
    r = 'exit'

ok = (len(hits) == 2 and hits[0][1] == ENTRY and hits[1][1] == DRAW)
print('run:', r)
print('hits:', hits)
print('RESULT: %s - SETUP screen opened by pure keystrokes (no far_call)' %
      ('PASS' if ok else 'FAIL'))