# plpbt 动态分析发现记录（DYNAMIC_FINDINGS.md）

> 状态：2026-09-01，`tools/bootlab.py`（unicorn 2.1.4 + capstone，实模式仿真）。
> 目的：把 DYNAMIC_PLAN.md 的路线 A（unicorn 仿真）阶段成果固化下来，供后续继续。
> 文档组织：先列**已由运行证实 / 修正**的机制，再列**当前卡点**与下一步实验设计。

---

## 1. 环境与关键前提（已定论）

### 1.1 unicorn 2.1.4 实模式 `int n` 语义（实测，非推测）

- `int n` **不会**查 IVT、不压 iret 帧、不跳转——只触发 `UC_HOOK_INTR`，
  hook 返回后**自动继续执行 int 之后的下一条指令**（IP 已推进）。
- 因此 BIOS 桩必须写在 hook 内；plpbt 运行时"改写 IVT 0:0x4C 接管 int 13h"
  的机制，在 unicorn 里默认**失效**——必须手动分发：读 0:0x4C，
  若指向 plpbt 自己的处理器（CS:0x100 等），手工压 iret 帧（ip/cs/flags）
  并跳转，让处理器自己的 `iret` 返回。
- 寄存器常量在 2.x 改名 `X86_REG_*` → `UC_X86_REG_*`（bootlab 已做别名兼容）。

### 1.2 `mov fs,<sel>` 在 PE=1 时 #GP（实测）

- unicorn 无法执行"lgdt → 置 CR0.PE → mov fs,selector"短促 PM 切换，
  在段加载指令处抛 #GP（与选择子值无关）。
- **等效补丁**：把 3 处 `8E E3`（mov fs,bx，文件 0x464E/0x57F7/0x59F9）打成 NOP，
  并在入口预置 **FS=0**。因为 unicorn 实模式对 `fs:[edi]`（0x67 前缀 32 位）
  按 `FS<<4 + EDI` 计算线性地址，FS=0 即"线性地址 == EDI"，正是 GDT 平坦窗口的语义。

### 1.3 平坦窗口 base = 0（**修正 REPORT.md §4 的错误结论**）

- REPORT.md 说 GDT entry1 "base=CS<<4，平坦覆盖镜像段"——**错**。
- 实据（运行中观察）：
  - 引导早期 0x0AB8 用 `edi=0x200000; ecx=0x3C0000` 通过 fs:[edi] 清零
    **2MB–5.75MB 扩展内存**（物理地址，不是镜像内偏移）；
  - BSS 变量 [0xAB3B]=0x200000、[0xAB3F]=0x1100000（17MB）都是物理地址；
  - 0x888 完整性校验用 `mov edi, es:[0x228]`（es=0x9000）取**镜像线性基址**后
    逐字节比对——flat 窗口按真实物理地址寻址。
- 因此 fs:[edi] 直接用真实线性地址；这也是 0x9A26 之后分配器能在 2MB 起步的扩展内存
  开缓冲的原因。

### 1.4 文件真实性

- `plpbt.bin`（43,575B，2023-01-26）与官方 Plop Boot Manager **5.0.15**
  （download.plop.at/files/bootmngr/plpbt-5.0.15.zip）**逐字节一致（0 差异）**。

---

## 2. 已由运行复现的引导流程

| 步骤 | 证据 | 结论 |
|---|---|---|
| 入口序言 | BSS [0xAB37]=7C00、[0xAB39]=FFFE、[0xAB51]=80、[0xAB4B]=7C00 | 与 REPORT §3 完全一致 |
| BSS 清零 | 0xAB3B..0xF8CF `rep stosb` | 一致 |
| A20 探测 | 0x597C 区 `FF:510 ↔ 0:500` 字节互写比对（0x5992 处越界崩溃曾卡住，补 HMA 映射后通过） | 一致（经典 A20 测试） |
| 磁盘枚举 | int 13h AH=08（0x0DAC）→ AH=48 EDD（0x0DC9）→ AH=02 读 MBR→0xC4EB（0x0D91），[0xCF43]/[0xCF44] 计数 | 与 REPORT §3 一致 |
| **EDD "USBD" 判定（修正 DRIVERS.md）** | 0x0DD0 `cmp dword [si+0x28], 0x20425355` | 判的是 **"USB "（带尾随空格，0x20425355 = "USB"），不是 "USBD"**；命中才 `inc [0xCF44]` |
| PM 短促切换 | 0x59B5 lgdt→CR0.PE→(mov fs 补丁后通过)→清 PE | 机制与 REPORT 一致（除 base=0 修正） |
| 扩展内存清零 | 0x0AC7 起 `fs:[edi]=0; edi+=4` 清 2MB..~5.75MB | 新证实：引导早期就分配/清零高内存扫描缓冲 |
| 窗口描述符分配器 | 0x6481：先 `mov di,0xAB52; rep movsb`（从 SI 拷 0x39 字模板）→ 从 [BP] 结构读 dword+word+word 尺寸 → 0x663E do-while 清零 [旧游标, 新游标) | 见 §3（卡点） |

---

## 3. 当前卡点：窗口描述符 0x9A26 全零

### 3.1 现象

- 0x0B44 `mov bp, 0x9A26` → 0x0B4A `call 0x6481`（首次分配）。
- 0x9A26 结构 = dword（分配尺寸）+ word + word，官方文件该处全零，且运行全程
  **无任何代码向 0x9A26-0x9AE2 写入**（写监控已验证有效：0xC4EB MBR 缓冲被写 513 次）。
- 0x663E 是 **do-while**：先写一个 dword 再 `dec ecx; jne`。长度 0 → dec 使 ecx
  变 0xFFFFFFFF → **无限循环**从 0x20231F 一路向上清内存，直到越过映射顶崩溃
  （之前 32MB/128MB 映射时分别崩在 0x01FFFFFF/0x07FFFFFF，即 map_top-1，
  佐证"顶 = 我们给的映射大小"）。

### 3.2 实验结论

- 给 0x9A26 手工填 `0x2320`（与游标 0x20231F 同数量级）后，分配器通过、
  运行进入 0x5EC2 的**菜单绘制代码**（fs:[edi] 直写扩展内存离屏缓冲，不经 int 10h），
  但随后因窗口几何变量（[0xAB62] 宽 / [0xAB74] 高 / [0xAB7B] 盒宽 / [0xAB78] 盒高）
  全零而再次陷入 0x6029 的绘制循环死转。
- 这些几何变量在 0x6481 尾部从同一结构（[bp] 偏移 +0x3E 起）拷贝到
  [0xAB56..0xAB81]，即 **0x9A26 结构 = 窗口描述符（尺寸 + 屏幕/盒几何）**。

### 3.3 ~~已解决：0x9A26 由装载器预置（本轮验证，2026-09-01）~~

> **⚠️ 本节结论已被 §6 推翻（2026-09-02）：不存在"装载器预置"。真实原因是
> 寻址模型错误——镜像加载在 CS:0x100（文件偏移 0 == CS 偏移 0x100），此前所有
> "全零/垃圾数据"的地址都读的是文件偏移低 0x100 处。参见 §6.1。**

三个候选假设经**活体验证**逐一判定：

1. **VBE 存在路径 —— 否证**。桩早已返回"VBE 存在"（AX=4F00 → AL=0x4F，见
   `bootlab.py` int10h 桩），但引导全程**没有任何 AX=4F00 调用**：0x0B0A 的门控
   `cmp [0xB071],1` 里，`[0xB071]` 唯一的写者是 Setup 菜单的 VBE 模式选择处理器
   （0x8027/0x8033，且受 `[0xB6DE]==1` 门控），**引导路径从不写它**。改桩返回
   值不影响任何东西——0x0B11 的 VBE 循环根本到不了。
2. **0xED3 设备表路径 —— 否证**。活体探针（`probe_b063.py`）显示 `sub_0ED3`
   完全不写 0x9A26：它只遍历 0xB562 的设备名表、复制 4 dword，与窗口描述符
   无关；`[0xB063]=0` 使其提前返回，但那也无关紧要。
3. **装载器预置 —— 证实**（唯一剩余可能，且与 `[0xB07C]` 常驻标志同类）。

决定性证据是**写入监控**（`probe_writes_9a.py` 的 UC_HOOK_MEM_WRITE 覆盖
0x9A00-0x9AF0 与 0xB700-0xB800）：引导全程对这两段的所有写入都来自
IP **0x08DE**——入口序言的 BSS 清零 `rep stosb`。没有任何代码填充窗口描述符
或几何模板。且 0x9A26 **小于 BSS 起点 0xAB3B**、落在文件数据区内（0x9A26 <
0xAA37），官方文件该处恒为零 → 必然由装载器（Plop MBR bootstrap / bzImage
setup / GRUB）在跳转前写入，正与 `[0xB07C]` 同一协议族。

### 3.4 描述符格式解码 + 预置后的最新状态

- `sub_6481`（0x6481）读 `[bp]` dword（尺寸）→ 累加进游标 `[0xAB4D]` →
  `sub_663E` 清零 `[旧游标, 新游标)`；随后从 `[bp+8..0x23]` 把**几何字**写入
  `[0xAB56..0xAB81]`（ab5e/ab60/ab56/ab58/ab5a/ab5c/ab62/ab64/ab7a(byte)/
  ab7b/ab72/ab74/ab76/ab78/ab81）。开头还把 si 指向的 **0x39 字节模板**
  （0xB732 主窗口 / 0xB76B 第二窗口）复制到 0xAB52，结尾（0x651F）又保存回
  模板——因此模板也由代码自维护，**初始内容同样来自装载器**。
- `bootlab.py` 新增 `--preset-window`：按上述布局预置 0x9A26/0x9A4B
  （dword 尺寸 0x2320/0x1000 + 80×25 几何 W=640/H=200 px）。验证结果：
  - 分配器通过（不再崩 0x664D）；菜单绘制 `sub_5EC2` 入口时 `[0xAB62]=0x280`
    **正确**，模板 `[0xB732+0x10]=0x280` 也由 save-back 填好。
  - 但随后在 0x639A 的 `stosw es:[di]` 文本屏填充循环里，`[0xAB62]` 被
    `sub_612b`/`sub_665D` 的 rep movsb（IP 0x6665）以模板字节覆盖成垃圾
    （如 0xB669）→ cx=0x16CD 死转。即**几何区在绘制中被文本/代码字节复用**
    ——预置的模板内容与真实装载器写入的不完全一致，绘制阶段的窗口内容布局
    仍需对拍修正。

**下一轮实验顺序**（修正后的）：
1. 用 `--preset-window` 复现"过分配器、进绘制、死转 0x639A"，确认是模板字节
   差异而非桩缺陷。
2. 转路线 B（QEMU + SeaBIOS + gdbstub 对拍，DYNAMIC_PLAN.md §2 路线 B）：
   抓真实装载器写入的 0x9A26/0x9A4B/0xB732/0xB76B 字节，回灌到
   `--preset-window`。这是获取"正确几何/模板"的最可靠途径（对应 Q2/Q4）。
3. 若需纯路线 A 闭环：解析 `sub_6048`（0x6048）文本渲染对几何区的读写序列，
   反向推导模板语义，把预置值调对。


---

## 3.5 本轮进展（2026-09-02 会话）：卡点已从"几何模板"推进到"定时器 IRQ"

### 3.5.1 现状：boot 能过分配器、进菜单绘制，但卡在 0x639A 文本填充

`--preset-window`（0x9A26/0x9A4B 描述符预置）后 boot 能跑完：
`alloc#1(0x0B4A) → DRAW#1(0x5EC2) → alloc#2(0x0B82) → DRAW#2/DRAW#3`，
`[0xAB62]=0x280`（宽）、`[0xAB64]=0xC8`（高）几何正确，
随后 `sub_1282` 反复进入 `sub_6340` 的 **0x639A `stosw` 填充循环**，cx 被垃圾几何（如 0xB669）放大成死循环。

### 3.5.2 根因 1（**新发现**）：0xA825 是第二个装载器预置结构 —— `sub_1282` 的 26 字窗口表

- `sub_1282`（菜单重绘调度，xref 0x0C0F/0x0CAE 等在引导路径）三次循环都
  `mov si,0xA825; lodsw ax,[si]; mov si,ax; mov al,[si]; test al,1/2/4` ——
  把 0xA825 当 **26 个 16 位指针**的窗口条目表读。
- 但文件 0xA825 处是**分区类型字符串**（" 0Bh Win95 Fat32"…），运行中 DS=CS=0x7C00
  （probe_ds1282 实测），于是表项是 `0x5720/0x6E69/0x3539/…` —— 恰好指向代码区
  （A20/keyboard 例程），`al=[si]` 读到指令字节当 flag，`sub_612b` 再从这些"假模板"
  复制 0x39 字节**代码**进几何区 0xAB52 → 几何被指令字节覆盖。
- **写监控（probe_a825_writes，UC_HOOK_MEM_WRITE 覆盖 0xA7F0..0xA890）证明：
  引导全程无任何代码写 0xA825** —— 与 0x9A26 同族，是**装载器预置数据**。
  这解释了 §3.4"预置模板与真实装载器不一致"的深层机制：不止模板字节，
  连 sub_1282 依赖的窗口表都是装载器填的。

### 3.5.3 根因 2（**新发现**）：`[0xB018]` 门控 —— 0x639A 只在"VBE 模式被设置"时执行

- `sub_6340` 开头 `cmp word [0xb018],-1; je 0x63dd`：`[0xB018]=0xFFFF(-1)`
  （文本模式）时**整个填充函数被跳过**。
- 本仿真中 `[0xB018]=0`（sub_5B9E 的模式表查找：`[0xB062]=0` → `[bx-0x73fb]`
  读到 0x8C05 处 word=0 → B018=0），于是 0x639A 被执行并死转。
- **实验（probe_force_text）**：在 0x0B04（sub_5B9E 之后）强制 `[0xB018]=0xFFFF`，
  0x639A 消失，boot 前进到**新卡点 0x12E6** —— `sub_1282` 等待 `[0xb061]==1`。

### 3.5.4 根因 3（**新发现**）：0x12E6 等 `[0xb061]==1`，由 int 8h 定时器链驱动 —— **仿真器缺定时器 IRQ**

- `[0xb061]` 唯一写者是 0x1090（视频刷新例程 0x1085..0x11EA 内，0x1085 为
  pushf/cli/pushal/push es/ds 的手写中断/回调例程）。
- 触发链：**int 8h** → CS:0x66FB（`sub_65BA` 安装：IVT 0:0x20 ← `(CS<<16)|0x66FB`，
  PIT 计数 0x5555 ≈ 18.2Hz）→ handler 做 EOI（out 0x20,0x20）、`inc [0xb6e6]`、
  若 `[0xb6ed]==0 && [0xb6e9]==1` 则 `call [0xb6eb]`（0x0A97 置 = **0x1185** 重绘回调）→
  重绘回调最终经 0x1085 设 `[0xb061]=1` → `sub_1282` 的 0x12E6 循环退出。
- 仿真器**没有任何定时器 IRQ**：IVT 0x20 安装后从不触发，`[0xb061]` 恒 0，
  `sub_1282` 在 0x12E6 死等。**这正是 DYNAMIC_PLAN §7 预测的
  "hlt 轮询：桩环境没有真实定时器 IRQ"风险** —— 结论从"需对拍"升级为
  **仿真器必须补虚拟定时器**（hlt 消耗虚拟 tick / 周期触发 IVT 0x20）。

### 3.5.5 定时器地址待核

- `sub_65BA` 写 IVT 0x20 = CS:0x66FB，但 0x66FB 处字节是 hex 辅助例程
  （`shr al,4; and ah,0xf; add ax,0x3030; ret`），真正的 EOI handler 在 0x65FB。
  probe_timer 实测 IVT 0x20=7C00:66FB，fire 到 0x66FB 会破坏 far_call iret 帧。
- 0x65FB..0x663E（EOI+tick+`call [0xb6eb]`+watchdog `dec [0xb6e8]`/`ljmp 0:0`）
  是完整 IRQ handler 形态；0x5D33 等线性扫描区与复制无关。
  **待核：0x66FB 是否为"复制目标/跳板"，或 IVT 应指向 0x65FB。**

### 3.5.6 下一轮实验设计（修正后的）

1. **给 bootlab 加虚拟定时器**：hlt 指令 hook（`sti;hlt` 时消耗一个虚拟 tick）
   或 UC_HOOK_CODE 周期触发 → 手动 far_call IVT 0x20 指向的 handler
   （先核清 0x66FB/0x65FB 谁是真 handler）。目标：`[0xb061]` 被置位，
   0x12E6 放行，菜单进入 int16 等待态（probe_wait 的 WaitForKey 应能命中）。
2. 若能进菜单等待态 → key_send 自动遍历（P3），拿到 BSS 真值回灌（Q5）。
3. 若 0xA825 表内容影响条目绘制（flag 决定调 63E0/6340/6149/62D4），
   后续需从真实装载器（Plop MBR bootstrap / bzImage setup）或 QEMU 对拍取真值。

---

## 4. 对既有文档的修正汇总

| 位置 | 原结论 | 修正 |
|---|---|---|
| REPORT.md §4 | GDT entry1 "base=CS<<4，平坦覆盖镜像段" | **base=0**，fs:[edi] 用真实线性地址 |
| DRIVERS.md §1.2 | "USBD" 魔数 | 实为 **"USB "**（0x20425355），[si+0x28] 判定 |
| REPORT.md §3 | 0x888 = 完整性校验 | 0x888 是**主引导函数**（内部含 8 次递归调用 0x888 做完整性自检 + 磁盘枚举/分区扫描/分配） |
| REPORT.md §2 | BSS 后紧接高内存 | 引导早期即清零 2MB..5.75MB 扩展内存扫描缓冲 |
| DYNAMIC_FINDINGS §3.3 | VBE 假说 / 0xED3 假说 / 装载器预置并列候选 | **VBE 与 0xED3 均已否证**（写入监控 + 活体探针），**装载器预置为唯一成立**（0x9A26 < BSS 起点，落文件数据区，装载器写入） |
| bootlab.py | int10h AX=4F00 桩"返回无 VBE" | 桩其实**已返回存在**（AL=0x4F），但引导从不调用 4F00（门控 [0xB071] 仅 Setup 菜单写） |
| DYNAMIC_FINDINGS §3.4 | 0x639A 死转归因"预置模板与真实装载器不一致" | **机制升级**（本轮）：0x639A 在 `sub_6340`，受 `[0xB018]!=-1`（VBE 模式已设）门控；几何被污染的**直接来源**是 `sub_1282` 把装载器预置的 **0xA825 26 字窗口表**（文件里是分区类型字符串）当指针读 → 指向代码区 → `sub_612b` 把指令字节复制进几何区。仿真强制 `[0xB018]=0xFFFF` 后 0x639A 消失 |
| DYNAMIC_FINDINGS §3.4 | 下一步"QEMU 对拍抓模板字节" | **补充**（本轮）：仅对拍模板不够 —— 0xA825 窗口表同样装载器预置；且仿真器**缺定时器 IRQ**（int8h → CS:0x66FB → [0xb6eb]=0x1185 → 0x1085 设 [0xb061]），`sub_1282` 在 0x12E6 死等 [0xb061]==1。先补虚拟定时器（hlt 消耗 tick）再谈对拍 |

---

## 5. 产物清单（tools/）

| 文件 | 用途 |
|---|---|
| `bootlab.py` | 主仿真器：加载镜像、BIOS 桩（int13/10/15/16/19/1A）、手动 IVT 分发、补丁、BSS/屏幕 dump、int 跟踪；**新增 `--preset-window`（装载器预置 0x9A26/0x9A4B 描述符，过分配器进菜单绘制）** |
| `smoke_test.py` | unicorn 实模式 `int n` 语义验证（IVT 不自动分发） |
| `probe_b063.py` | 本轮新增：验证 sub_0ED3 是否填 0x9A26 → **否**（只处理 0xB562 设备名表），否证假说 #3 |
| `probe_vbe_gate.py` / `probe_writes_9a.py` | 本轮新增：验证引导无 AX=4F00 调用（门控 [0xB071] 仅 Setup 菜单写）+ MEM_WRITE 监控证明 0x9A26/0xB732 仅被入口 BSS 清零写 → **证实装载器预置** |
| `probe_preset.py` / `probe_menu.py` / `probe_hot.py` / `probe_flow.py` / `probe_wait.py` | 本轮新增：预置描述符后追踪绘制入口、离屏缓冲、热循环 0x6086/0x639A、分配器调用序列 |
| `edi_probe.py` / `probe_663e.py` / `probe_enter.py` / `probe_geom.py` | 定位 0x664D 死循环来源 / 0x663E 入口参数 / 窗口几何变量的排查脚本 |
| `exp_struct_size.py` | 实验：给 0x9A26 填尺寸后运行 |
| `dump_alloc.py` / `watch_struct.py` / `first_hit.py` / `trace_last.py` | 内存/写入监控辅助 |
| `probe_tpl_dump.py` | **本轮新增**：alloc#1/#2 后与 sub_5EC2 绘制入口的模板 0xB732/0xB76B + 几何 dump（证明几何初值正确） |
| `probe_639a_chain.py` / `probe_geom_hit.py` | **本轮新增**：0x639A 首次命中的调用路径 + 几何快照（证明几何已被垃圾模板覆盖，SI=0x6E69 等代码地址） |
| `probe_ds1282.py` | **本轮新增**：sub_1282 入口 DS/CS 实测 + 0xA825 26 字表 dump（DS=CS=7C00，表内容=分区类型字符串） |
| `probe_a825_writes.py` | **本轮新增**：MEM_WRITE 监控 0xA7F0..0xA890 + 0xAB50..0xAB95 → **0xA825 无任何代码写入（装载器预置）**，几何区仅被 0x6665(rep movsb) 覆盖 |
| `probe_a825_zero.py` | **本轮新增**：把 0xA825 表清零再跑（仍进 0x639A —— 因表项指向 0x0 处指令字节当 flag） |
| `probe_force_text.py` | **本轮新增**：sub_5B9E 后强制 `[0xB018]=0xFFFF` → **0x639A 消失，卡点前移到 0x12E6（等 [0xb061]）** —— 证实 0x639A 受 VBE 门控 |
| `probe_timer.py` / `probe_timer2.py` / `probe_timer3.py` | **本轮新增**：IVT 0x20 安装确认（=7C00:66FB）+ 手动 fire int8 handler 的实验（0x66FB 是 hex 例程，非 iret handler，fire 破坏帧） |
| 参考 | 官方 plpbt-5.0.15（/tmp/plpbt.zip、plpbt_5.0.15.bin，与本地 plpbt.bin 一致） |


---

## 6. 本轮突破（2026-09-02 会话 2）：+0x100 加载布局 + boot/菜单/驱动链全通

### 6.1 根因发现：镜像加载在 CS:0x100（文件偏移 0 == CS 偏移 0x100）

**此前 §3 全部"装载器预置"谜团（0x9A26/0xA825/0xB732）与 §3.5 的定时器地址疑问，
根源都是同一个：REPORT.md §2 的寻址模型（段内偏移 == 文件偏移）差了 0x100。**

真实布局：**文件偏移 0 位于 CS:0x100**（即 CS 偏移 X == 文件偏移 X-0x100），
官方装载段 **CS=0x3000**（代码自带 `cmp ax, 0x3000` 自检，file 0x0D39），raw 入口
**CS:0x9BE**（= 文件 0x8BE；首扇区 `e9 bb 08` 相对跳转在 +0x100 布局下恰好落在入口，
证明文件按此布局构建）。证据链（多点独立验证）：

| # | CS 引用 | 文件内容（CS-0x100） | 旧模型下的错误读数 |
|---|---|---|---|
| 1 | IVT int8 = CS:0x66FB（file 0x65FB） | 完整 EOI+iret IRQ0 handler | 0x66FB=hex 例程中段，"非 handler"（§3.5.5 疑问） |
| 2 | tick 回调 [0xB6EB]=0x1185（file 0x1085） | 完整 pushf/pushal 例程（时钟+媒体检测） | 0x1185=例程中段，栈不平衡 |
| 3 | 窗口表 CS:0xA825（file 0xA725） | **26 项干净指针表**（0xB732..0xBCC3，步长 0x39） | 分区类型字符串 |
| 4 | 描述符 CS:0x9A26/0x9A4B（file 0x9926/0x994B） | **真实尺寸/几何数据**（#1 dword=0x30000，含 640/480） | 全零 |
| 5 | `mov si,0xA4D`（file 0x94D） | "Press CTRL-A to start the Plop Boot Manager" | 乱码（REPORT 里 0x94F 的矛盾由此解） |
| 6 | 自检 blob si=0xAAA4（file 0xA9A4） | 配置串 "int19h=on...20 seconds..." | 指向文件末尾之外 |
| 7 | BSS 清零 CS:0xAB3B..0xF8CF = 文件 0xAA3B.. | 文件尾 0xAA37 之后正好留 4 字节 CS:0xAB37..0xAB3A = SS:SP 保存槽 | 无解释的 5 字节缝 |

由此：**不存在任何"装载器预置数据"**（[0xB07C] 常驻标志除外——它在 BSS 内，
确实由外部 bootstrap 置位）。§3.3/§3.4/§3.5.2 的结论按此全部修正：
0xA825 表项内容（B732:flag 等）是**运行时在 BSS 构建的窗口状态**，指针表本身是文件静态数据。

### 6.2 bootlab.py 本轮升级（P1–P4 全通）

- **加载布局**：`load_seg=0x3000, img_off=0x100, entry=0x9BE`；`--preset-window`/
  `alloc_size` 已废弃（no-op）。
- **虚拟定时器**：hlt 检测（UC_HOOK_CODE 内 size==1 且 0xF4）→ 跳过 hlt 并 far-call
  IVT[8] handler（真 handler CS:0x66FB=文件 0x65FB ✓）；`--tick-insns N` 周期 tick
  （0x12E6 等 [0xB061] 是忙等，无 hlt，必须周期 tick）；`--feed-watchdog` 每 tick 重置
  [0xB6E8]=3。**看门狗开放问题**：全镜像只有 3 处引用 [0xB6E8]（置 3/dec/重置+ljmp 0:0），
  **无任何喂狗代码**（字节模式+立即数+rep stos 全查过）——不加 --feed-watchdog 则第 3 个
  tick 必 ljmp 0:0（实测复现）。真机为何不死机未解，**留待 QEMU 对拍**。
- **far_call 参数交换 bug 修复**：on_intr 的 IVT 解包变量名反了（vcs 实为 offset），
  far_call(seg,off) 被传入 (off,seg)——旧预设 0:0 时走不到该路径故从未暴露。
- **int 0x13 的 IVT 手动分发**现走真向量；BIOS 链 trampoline = 0xF100:0 处
  `int 0xFE; retf 2`（on_intr 把 0xFE 就地按 int13 服务；retf 2 同时平衡
  "int 式 far-call 帧"与驱动的 `pushf; call far 旧向量` 两种调用方，CF/AX 经活寄存器传播）。
- **VBE 桩修复**（三处）：
  1. 返回值 AX=0x004F（原 0x4F00——**§4 表"桩其实已返回存在(AL=0x4F)"是错的**，
     实为 AL=0，[0xABC4]=2 检测失败）；
  2. 4F01 现填 256B 模式信息块——**plpbt 把块内嵌字段就地当变量用**：块在 CS:0xADE7，
     PhysBasePtr@+0x28 == CS:0xAE0F == [0xAE0F] LFB 指针（虚 LFB 设 32MB=0x2000000）；
  3. 模式表解码（文件 0x8B00）：flags {0,1,1,1,1} × modes {0x1112 文本, 0x101,0x103,0x105,0x107
     8bpp} × 640/800/1024/1280 宽。[B062]=模式索引（Ctrl-PgUp/PgDn 换模式）。
  合成字体（0xF000:0xFA6E）：字形 c = c 低 7 位在 1..7 行的全宽条码，LFB dump 可反解文本。
- **按键队列升级为字格式**（scan<<8|char）：代码按全字派发（ESC=0x011B、Ctrl-PgUp=0x8400、
  Ctrl-PgDn=0x7600、Ctrl-A=0x1E01、ENTER=0x1C0D、字母在 AL）。0x1331 主循环派发表：
  f=软盘引导(0x84A6) / i=0x1AC9(卸载+int19) / c=CD(0x8645) / U,u=USB(0x8708) /
  数字=分区引导(0x1839，需 [0xB242] 配置表) / w / q=0x1590 / n=0x89C9 / ESC=退出；
  方向键/ENTER 在 0x13AE 导航器（[0xC126] 选择，[0xC128] 跳表 → [0xC133] 动作函数）。
  数字引导报 "No bootdevice selected" 是**正确行为**——[0xB242+dev] 引导配置来自磁盘上的
  Plop profile（MBR 隐藏扇区），假盘没有。
- EDD AH=48 桩两处修复：host-bus 写 **"USB "**（0x20425355，带空格——§4 修正表已对，
  但桩此前写的是 "USBD"）；返回 size 协商（调用方请求 0x42 并校验返回 ≥0x42，
  桩原来固定回 0x1E 导致 USB 盘计数恒 0）。修复后 **[CF44]=2**（USB 识别生效）。

### 6.3 P4 实测：int13 钩子安装链 + 重定向器 + USB 模块栈（全活体验证）

**安装链**（'u' 键 = 0x8708）：循环三种 USB 控制器模块（消息字符 **'O'/'U'/'E'** =
OHCI/UHCI/EHCI），每轮：
1. `call 0x8380`（ax=0x16）——收缩 BDA 常规内存（0x40:0x13）、在 EBDA 区算出钩子段
   → [0xCF5B]；
2. `call 0x8442`——把 **si 指向的模块 blob** 复制到 [CF5B]:0x100，读旧 int13 向量存
   [0x107]（ blob 内 `call far` 操作数被 TINI 就地补丁！），写 IVT 0:0x4C = hookseg:0x100，
   再经 `call 0xd85`（= int13 + eax='PoLP', ebp='TINI'）把 dl（虚拟盘号）存 cs:[0x104]；
3. `call 0x87fb` 测试：`int13 + eax=0x9901/0x9902/0x9903` 命令（0x9902=控制器探测），
   失败 → `call 0x8496`（'PoLP'+'TIUQ' 卸载）+ 0x840E（BDA 还原）→ loop 下一模块。

实测（keys="u", edd=USBD）：**三次安装 si=0x479D(EHCI,19562B) / 0x2453(UHCI,20358B) /
0x34E9(OHCI,11759B)**，每轮 TINI→0x9901→0x9902→TIUQ 完整周期；模块副本段（9A70）内
**414 个唯一偏移的真实执行足迹**（0x121-0x158 魔数分发、0x169-0x25B 0x99xx 命令处理、
0x2E4-0x3A0 控制器探测……）。0x9902 失败属预期——仿真器没有 PCI/UHCI 硬件
（P6：PCI/端口桩后可点亮寄存器级代码）。

**重定向器**（0x5841 blob，140B，常驻层）：'PoLP'+'TINI'/'TIUQ' 魔数分发；
普通 int13：`cmp dl,cs:[0x104]` → dl==虚拟盘号 → 改 0x80 链；dl==0x80 → 改 [0x104] 链
（**0x80 ↔ [0x104] 盘号交换**），`pushf; call far 旧向量` → 出口 `retf 2` 保留活 flags。
链尾的"旧向量"= 安装时 IVT[0x4C]（仿真里 = 我们的 0xF100 trampoline）。
gap 起点 file 0x1AFD 是**第三种魔数 'DHKC'(CHKD) 的同类模块副本**。

### 6.4 Q5：BSS 真值已采集（out/bss_truth.txt + out/menu_lfb.png）

稳态要点：[B018]=0x0101、[B01A]=1（VBE GUI）；[B6EB]=0x1185（回调=文件 0x1085）；
[B6E6]=tick 计数；窗口表运行态 B732:01 / B76B:09（flag 活）；[C126]=1（菜单选择）、
[C128]=0x8E1D（跳表）、[C133]=0x6B4A（动作函数）；[DF33]=2（分区数）；[CF8F]=倒计时。
LFB 640×480×8@32MB 有内容（框线/选择条结构 + 合成字体文本）。

### 6.5 遗留/下一步

1. **看门狗 [0xB6E8] 之谜**（§6.2）——QEMU/SeaBIOS 对拍（路线 B）可实证真机行为；
   QEMU 未装，需先获取。
2. USB 栈寄存器级执行需 PCI/端口桩（P6）。
3. bzImage 路径（Q1/P5）未动——setup 段(0x250)的自举需按 +0x100 模型重新审读。
4. 菜单像素级可见性：需要真 8x8 字体（可从 SeaBIOS/VGABIOS 提取）替换合成条码字体。
5. 数字引导需先伪造 Plop profile（MBR 隐藏扇区格式未解析）或走 'b' 设引导分区路径。

### 6.6 本轮新增产物

| 文件 | 用途 |
|---|---|
| `bootlab.py` | 大改：+0x100 布局 / 定时器 / VBE 桩修复 / 字队列 / hook_extra 注入点 / lfb_png / lfb_text / default_disk |
| `probe_boot_v2.py` | 里程碑跟踪 boot（CS 坐标） |
| `out/bss_truth.txt` | Q5 稳态 BSS 真值 |
| `out/menu_lfb.png` | 菜单 LFB 灰度 PNG（合成字体可反解） |
| （本轮探针为一次性内联脚本，关键结论已固化本文件） | |

---

## 7. P5/Q1 解谜 + QEMU 对拍实证（2026-09-02 会话 2 续）

### 7.1 bzImage setup 段（file 0x250）——+0x100 模型的又一独立证明

引导协议布局（syslinux / qemu -kernel 真实行为）：setup 区（file 0x000-0x9FF）载入
0x9000:0，payload（file 0xA00..）载入 0x1000:0——**加载器用真实文件大小，syssize=0
不影响 syslinux/QEMU**（只影响严格按头加载的路径）。setup 代码：

    0x250: ds=0x1000,si=0; es=0x5000,di=0xB00; cx=0xF2FF; rep movsb   ; payload → 0x5000:0xB00
    0x264: ds=0x9000,si=0; di=0x100; cx=0x500; rep movsw              ; setup  → 0x5000:0x100
    0x273: eax='PLIN'(0x504C494E), edi='NILP'; push es; push 0x100; retf ; → 0x5000:0x100

两段拷贝拼起来 = **文件 X 位于 0x5000:(X+0x100)**——setup 在 0x5000 段现场重建
+0x100 布局，然后 retf 到 0x5000:0x100（= 文件 0 的 `jmp 0x8BE` → CS:0x9BE 入口）。
**Q1 答案**：bzImage 路径 = setup 重组 + 与 raw 完全相同的引导（bootlab 动态验证：
mainloop 同样在 tick 255 命中，逐 tick 一致）。bootlab `--mode bzimage` 已按协议布局
重写（setup@0x9000:0 + payload@0x1000:0，入口 0x250，运行段寄存器 CS=0x9000）。

### 7.2 看门狗 [0xB6E8] 之谜——QEMU 对拍实证（已解）

方法：winget 安装 QEMU 11.1.0，`qemu-system-i386 -kernel plpbt.bin -display none`
（真实 SeaBIOS + 真 PIT），QMP `xp` 轮询 [0xB6E8]（物理 0x5B6E8）+ `-d int` 记录。

实证数据：
- 12 秒存活，无重启（cpu_reset 日志只有上电项）；216 次硬件 IRQ0 / 4s = 54.6Hz 连续。
- [0xB6E8] 低字节在 **1/2/3 间循环**（从未观察到 0），[0xB6E9]=1、[0xB6EB]=0x85
  （回调 = CS:0x1185 = 文件 0x1085）——**+0x100 模型在真机 QEMU 上直接成立**。
- `[0xB6E6]`=548 ≈ 10s×54.6Hz，tick 计数连续无重置。

结论：
1. **[0xB6E8] 不是"必须被主程序喂"的看门狗**——handler 每 3 tick 在 0x6632 自行重置
   为 3（在 ljmp 之前），随后 `ljmp 0:0`。
2. `ljmp 0:0` 在真 BIOS 上落入 **IVT 雪橇**：SeaBIOS IVT[0..2] 字节 = `53 ff 00 f0`
   ×2 + `c3`，即 `push bx / inc [bx+si] / add [bx+si],dh / push bx / inc / RET`，
   RET 从栈上的中断帧弹回系统流；`-d int` 全程零异常。仿真器里 IVT 内容不同
  （假向量 + 0xF100 trampoline），雪橇走出乱飞——**`--feed-watchdog` 正是
   "雪橇无害返回"的等价仿真**（语义：真机把 3-tick 一次的 ljmp 吸收掉）。
3. 附带发现：雪橇里的 `inc/add [bx+si]`（DS=0x5000）= 真机上每 3 tick 一次的**杂散
   内存写**（落点取决于被中断时的寄存器）——Plop 5.0.15 的潜在 bug，实践中未爆雷。

### 7.3 对拍总体结论

QEMU 实测与 bootlab 仿真在引导路径上**逐 tick 一致**（mainloop tick 255、定时器链、
菜单稳定运行），+0x100 寻址模型、定时器链（IVT[8]=CS:0x66FB=文件 0x65FB）、
回调 [0xB6EB]=0x1185 全部对上。**路线 B 的对拍使命完成**；遗留仅剩 P6（PCI/端口桩）
与 profile 格式解析（数字引导），均已在此前 §6.5 记录。

### 7.4 新增产物

| 项 | 内容 |
|---|---|
| QEMU 11.1.0 | winget 安装（C:\Program Files\qemu），对拍环境 |
| bootlab.py | --mode bzimage 协议布局重写 + run() 寄存器/start 解耦 + trace flush 修复 |
| /tmp/qmp_watch.py | QMP 轮询脚本（临时，逻辑已录本文件） |

---

## 8. 第三轮推进（2026-09-03）：+0x100 模型静态重跑 + 模块结构实测 + PCI/端口桩

### 8.1 静态产物重跑（analyze.py v3）

旧 out/ 产物（8-29）基于错误的"段内偏移==文件偏移"模型，全部按 +0x100 重跑：

- **tools/analyze.py v3**：文件偏移为主坐标，注释/标注输出 CS 双坐标
  （"file XXXX (cs XXXX)"）；内存位移统一按 **运行时 CS 偏移** 注解（镜像内
  位移即 CS 偏移，文件 = CS−0x100）；BSS/IVT/定时器等运行时地标表（0x9BE 入口、
  0xAB3B BSS 起、0x66FB int8 handler、0x8517 do_boot 等）。
- 旧模型产物归档到 **out/old_model/**（disasm_full.asm / functions.txt /
  strings.txt / ports.txt / stats.txt）。
- 新统计：递归下降 8614 指令 + 线性扫描 51 区（18446B），总覆盖 99.4%；
  420 函数；sweep 区按所属模块标注（[blob:…]）。
- 重跑修正的结论：REPORT.md §2 已加修正横幅；本轮不再有"装载器预置数据"之谜。

### 8.2 USB 模块结构实测（sub_8442 复制语义，动态实证）

此前把模块区长度当"副本长度"推测出错（头部 len16 使三个模块区互相包含）。
**活体实证**（keys='u', EDD=USBD，跟踪 sub_8442 的 rep movsb）：

| 项 | 值 |
|---|---|
| 安装段 | sub_8442 以 SI=cs 0x479D/0x2453/0x34E9（= 文件 0x469D/0x2353/0x33E9）调用；`mov es,[0xCF5B]` 后 hookseg 实为 **0x9A70**（EBDA 收缩所得，[CF5B]=9A70） |
| 副本长度 | `mov cx,[si+2]` = 头部 len16：**EHCI 19562B / UHCI 20358B / OHCI 11759B**；副本 = file[si-0x100 .. +cx]，与文件逐字节一致（头/尾校验均过） |
| 重叠真相 | 三个模块区在文件里**互相重叠**（UHCI 2353..72D9 ⊃ OHCI 33E9..61D8 等）：各区头部是控制器特有代码，后段共享通用驱动尾部。analyze.py v3 的 BLOBS 表按此模型标注 |
| 安装循环 | 'u' handler（file 0x8708）→ sub_8766（cx=3 循环，cl=3/2/1 → si=EHCI/UHCI/OHCI，消息字符 E/U/O）→ 每轮 `call 0x8380`(EBDA 收缩) → `call 0x8442`(复制+IVT 0x4C) → `call 0x87fb`(测试) |
| 重定向器 | 140B 独立区（5841..58CC），与三大 USB 模块不同文件区 |

IVT 0:0x4C 在三轮 0x9901 探测失败后保持 0xF100 trampoline（TIUQ 卸载），
与 §6.3 结论一致。

### 8.3 双模式回归基线（bootlab 定时器/按键修复后）

修复内容（bootlab.py）：
- **IRQ0 嵌套修复**：periodic tick 曾落入正在服务的 int13/int10/int8 handler
  内部（真实硬件 IF=0 不会嵌套），表现为 boot 卡在 5Dxx-63xx 文本/绘制代码、
  tick 数异常。现以 `in_service`（int 分发嵌套计数）+ `in_irq0`（int8 handler
  未 iret 闩锁，cs 0x673D 清除）双重护栏阻止嵌套 tick。
- **IVT[0] 看门狗雪橇**：handler `ljmp 0:0` 需 IVT 雪橇（`53 ff 00 f0`×2+`c3`，
  §7.2 QEMU 实证）吸收；此前线性 0 全零导致跳入空内存乱飞。现在 bootlab 预置
  雪橇 + IVT[0x40C] 指向 0xF000:0。
- **watchdog 重新武装移到 iret 后**（cs 0x673D）：武装在 dec 前会竞态，首次 tick
  即 ljmp。
- **bzImage 执行窗口**：hook_code 原只覆盖 0x3000 段，bzImage 重组镜像在 0x5000、
  setup 在 0x9000，导致 tick/里程碑全失效。现按 mode 展开 hook 范围并以
  img_base（0x50000）换算 cs_off。
- 入口默认值：bzImage 模式 entry 缺省 0x200（setup 入口），此前默认 0x9BE
  （raw 入口）导致 bzImage 从 raw 入口跑。

**回归结果（keys=''，tick_insns=50k，feed_watchdog）**：

| mode | alloc#1 | mainloop | 结束 |
|---|---|---|---|
| raw | tick 343 | tick 427 | end, 2771 ticks |
| bzimage | tick 344 | tick 427 | end, 2768 ticks |

两模式 alloc/mainloop tick 逐位一致——+0x100 模型下 raw/bzImage 行为同一。

### 8.4 PCI 桩 + EHCI 寄存器级传输点亮（P6 主体完成）

**关键发现：Plop 的 USB 模块不用 0xCF8/0xCFC 直读，而是走 int1A PCI BIOS**
（AH=B1 服务）——全模块 18 处 int1A 站点；B101=BIOS32 存在性、B103=按类搜索、
B108-B10D=配置空间字节/字/双字读写。bootlab 新增 `pci_bios()` 桩 + 虚拟
EHCI 控制器（class 0C03、prog-if 00、MMIO BAR0=0x10000000）：

- B101 返回 EDX=" ICP"(0x20494350)——**必须写满 32 位**（`set()` 的 16 位掩码
  曾把高字丢成 0x00004350，驱动 `cmp edx,0x20494350` 失败）。
- B103 按 ECX 类码（模块传 0x000C0320=class 0C 等）返回 bus/dev；驱动把
  BH=bus、BL=devfn 存入模块局部槽 [0x12e7..] 后用 B108-B10D 读 BAR0/命令字。
- B10C（写配置字，reg 4 置 IO/总线使能位 0x6）与 B10A（读 BAR0）后，驱动把
  BAR0 当地址用。

**EHCI 初始化（静态+动态双确认）**：
- 驱动取 BAR0（内存型 0x10000000）后经 `sub_57B3`（CR0.PE 短暂切换 +
  GDT + flat FS 窗口，即 bootlab 已 NOP 的 `mov fs,8` 路径）进入寄存器级；
- 实测 EHCI 页寄存器：**USBCMD=0x21**（RUN 启动）、USBSTS 清零、以及
  **ASYNCLISTADDR=0x9D2C0**（异步队列头）——模块已建 QH 链并启动调度；
- 魔数命令推进到 **0x9906**（此前止于 0x9902）。

所需寄存器语义桩（读时合成，见 bootlab run()）：USBCMD.HCReset self-clear、
USBSTS.HCHalted=!RUN（sub_5244 自旋点，此前死循环在 hookseg 0xCA9-0xCBC
= file 0x5246-0x5259 实证）、PORTSC0 读作 CCS|PED|PP（高速假设备）。

**hookseg 执行覆盖修复**：hook_code 范围此前不含 0x9A70（安装后的驱动段），
模块代码完全不可见；现 raw 模式扩到 0x90000+。

**踩坑记录（防重蹈）**：
- **cs_off 坐标错**：int8 handler 的 iret 在 file 0x663D == **CS 0x673D**。此前把
  0x663D 当 CS 偏移写 iret 清除钩子，永不触发 → in_irq0 死锁（首个 tick 后全停）。
  hook_code 里所有地标必须按运行段换算 cs_off（bzImage 镜像在 0x5000、hookseg
  在 0x90000 区，均与 raw 的 0x3000 不同）。
- **MMIO 桩用"读时合成"而非写钩子**：unicorn 的 mem-write 钩子无法抑制 guest 写
  （回调后写仍落内存），HCReset 自清零/端口复位这类"写后读不同"语义必须在读钩子
  里先改写 RAM 再让 guest 读到。读钩子返回 False 即可（不禁读）。
- **UC_HOOK_INSN 双钩子冲突**：再加一个 IN 钩子且返回 None 会让 unicorn 的
  intel.py 转换器抛 TypeError（'NoneType' 不可作整数）——IN 钩子必须返回一个值，
  且不要对同一端口挂两个语义钩子。
- **B101 的 EDX 必须写满 32 位**：Bios.set() 带 0xFFFF 掩码，`set(EDX,…)` 只写低字
  （实测返回 0x00004350），驱动 `cmp edx,0x20494350` 失败直接放弃该控制器。凡
  32 位返回（EDX/ECX）一律 `uc.reg_write` 直写。

**端口桩 API 实测**（unicorn 2.1.4）：UC_HOOK_INSN 对 IN 回调为
`cb(uc, port, size, ud)` 且返回值放入目标寄存器；OUT 为 `cb(uc, port, size, value, ud)`。
（BOCHS/raw 0xCF8/0xCFC 端口直通桩保留，模块实际不走。）

**QH/qTD 转储证据状态**：ASYNCLISTADDR=0x9D2C0 已确认（驱动把异步队列头写入
EHCI 页 op+0x18）。`tools/probe_ehci_qh.py`（QH 链+ qTD 字段逐 8 双字转储，
格式已修好）跑完即可拿到 QH 头指针/端点特性/overlay token/buffer 的真实字段
证据回填 DRIVERS.md；每次运行约 4 分钟（400M insns）。

### 8.5 遗留（本轮未完成，见 §6.5/§9 —— 2026-09-04 全部关闭）

1. ~~USB 设备枚举数据路径~~ **已解决**（虚拟设备应答，DRIVERS §6.2c；QH 字段
   级证据已回填 DRIVERS §6.1/§6.2）。
2. ~~profile 格式~~ **已解决**（DRIVERS §6.5 档案记录格式表）。
3. ~~Setup/'b'/Copy 工具的 UI 覆盖~~ **已解决**（§9.4 动态命中；自然入口键
   定论见 §9.4 附录）。
4. ~~UHCI/OHCI 寄存器语义~~ **已解决**（§9.9/§9.10）。

### 8.6 本轮新增/修改产物

| 文件 | 内容 |
|---|---|
| tools/analyze.py | v3：+0x100 双坐标、blob 表、BSS/运行时地标注解 |
| out/*.txt / out/disasm_full.asm | 全部按 +0x100 重跑（旧版在 out/old_model/） |
| tools/bootlab.py | IRQ0 嵌套闩锁、IVT0 雪橇、watchdog 移 iret、bzImage hook 窗口/入口、
  int1A PCI BIOS 桩、EHCI MMIO 页+寄存器语义、hookseg 覆盖、端口 IO 钩子 |
| tools/probe_ehci_tail.py / probe_ehci_qh.py | 模块执行尾迹 / QH 结构转储 |
| out/bss_truth.txt | （待并入 Setup/b 覆盖后更新） |

---

## 9. 第四轮（2026-09-03）：虚拟 USB 设备点亮 EHCI 枚举 + 数字引导路径全通 + bootlab 桩缺陷修复

### 9.1 三个 harness 缺陷（都有正式回归价值）

1. **BDA tick 计数（0x40:0x6C）从不递增**：Plop 的 IRQ0 处理器（cs 0x66FB）只做
   EOI/计数/watchdog，不递增 BDA；真实 BIOS 才拥有 IRQ0。USB 模块的 tick 延时
   sub_56AC（`mov es,0x40; cmp al,es:[0x6C]; je .`）死旋 —— QH4 tail 采样定位。
   修复：bootlab.fire_irq0 每次 tick 后 `mem_write(0x46C, +1)`。
2. **PORTSC 地址不符**：模块 PORTSC 指针 = op+0x40/0x44（实测 [0x2B53]=0x10000050、
   写落在 0x10000054），旧桩只物化 op+0x24。修复：三处都物化 CCS|PED|PP(0x1005)。
3. **int13 AH=42 EDD 包 seg/off 互换（长期潜伏 bug）**：EDD 包 +4=offset、+6=segment，
   旧实现读反 → 数据写到 0xC6EB:0x3000（线性 0xC9EB0）而 guest 查 DS:0xC8E9 永远
   00 00。数字引导最终签名检查暴露此 bug。附带：disk_read 越界改回 None（原空切片
   会让"越界读"假成功）；kbd_tail 曾用 keys 字符串长度（多按才复现）。
   附：MMIO 读钩子从整页改为按地址挂（QH6 整页钩子在 PORTSC 轮询下 400M insns
   跑了 48 分钟 CPU；按址钩子后正常）。

### 9.2 EHCI 枚举传输层点亮（虚拟设备应答）

bootlab 内建虚拟 MSC 设备（Bios.usb_*）：门铃写钩子（USBCMD&0x24）→
usb_process_async() 沿 ASYNCLISTADDR 执行 Active qTD：SETUP 捕获请求、IN 按
usb_respond() 回数据、OUT 识别 'USBC' CBW → SCSI（INQUIRY 36B / READ CAPACITY 8B /
READ(10) 从盘镜像出扇区 / 其余回 CSW 'USBS'+tag+0+0）；完成清 Active+status、翻转
toggle、USBSTS 置 USBINT|IAA（W1C）。

实测（QH7/QH8/probe_ehci_qh.py=QH_MAGIC）：
- tick 504 完整枚举序列：sub_4B9C → qTD(token 0x80088D80 = toggle|8B|data, buf0
  0x9E000) → 门铃 → USBINT 等待（修复前 4.9M 次空转，修复后立即通过）。
- 门铃 ×10 全部完成；USBSTS W1C 写 0x25/0x1 = 逐事务 ack。
- **QH 端点特征 dev=5**：模块给虚拟设备分配了 USB 地址 5（=[0x2BA8] 计数）。
- 命令流 0x9906 → **0x9907/0x9909**；MAGIC 序列呈 0x9903→…→0x9909 完整周期重复
  —— BOT 事务全通，§8.5#1 关闭。
- 钩子坐标修正记录：模块安装于 hookseg:0x100 → 文件 X 的 ip = X-0x469D+0x100
  （QH3 少加 0x100 的命中点全是 sub_5316 内部指令，当时结论作废）。

### 9.3 数字引导路径（'1' 键）端到端点亮

全链站点与档记录格式见 DRIVERS.md §6.5（表格）。要点：
- 档案表：[0xB232]/[0xB242]（slot 字节）、[0xB562] 16B×slot、[0xC32C] 19B×slot、
  [0xB262] 名称表、[0xC6A9] 引导块（=MBR 分区表项副本，+8=LBA）。
- sub_7CB2 按盘号装载 → sub_19DA 扫块 → sub_1A0D 取 LBA → AH=42 EDD 读引导扇区
  → 0xAA55 → sub_1A76 retf 交接（BX=0x7C00、SI=0x7BE、DL=0x80 —— MBR 交接约定）。
- 收尾 unknown_int = 假引导扇区（0xEA 桩）自身行为，非路径缺陷。
- 'w' 键 = 启动标志回写 MBR（sub_0E0A→sub_1742 AH=03）。

### 9.4 Setup / 'b' / Copy-to 工具覆盖（部分）

- 'c' 键 → 0x8645 设备再扫描屏（1/x/a teletype 进度 + sub_1659 设备窗）动态命中；
  从 Setup 上下文触发过完整 boot（交接寄存器同 §9.3）。
- **[第五轮补全：窗口系统反馈导航，全部里程碑动态命中]**（tools/probe_setup2.py）：
  - 反馈通道＝窗口表 0xA825（26 个 WORD desc 指针）+ 每个 desc+0 的标志字节
    （bit0=绘制/可见，bit2=键处理 pass；**注意 desc 是 CS 相对地址，读标志时
    不要再 −0x100**）+ 菜单选择 [0xC126]。lfb_text 对真实菜单字体解码无效
    （合成条形字体的假设不成立），窗口标志才是可靠回环通道。
  - Setup 菜单开屏器（文件 0x6AA3，绘制窗口 0xB7A4）与 'edit profile' 屏循环
    （文件 0x7A45，窗口 0xBA17）均无静态调用点（纯窗口系统间接派发），主菜单
    的字母键扫描也未能找到自然入口 —— 探针用 far_call 直呼开屏器后，**按键
    本身是真键**：排队的 'b'（scan 0x1F）由编辑屏键循环真实消费。
  - 实测命中（tick 计）：**0x7CC1 bootflag 'b' ×4**、0x71B2 CopyTo 开屏 's' ×1、
    **0x71D4 拷贝执行 'p' ×1**、0x7CE7 逻辑分区 'l' ×1、0x7C74 'd' ×1。
    counts: {'0x7cc1': 4, '0x7ce7': 1, '0x71b2': 1, '0x71d4': 1, '0x7c74': 1}。
  - 导航副产物：主菜单 8 行 = 2 盘 × 4 分区（无 Setup 行）；主菜单行上 ENTER
    会直接走引导流（"ENTER = Use device"）；行 7/8 的 ENTER 打开 0xB888/0xB84F
    （分区菜单窗，其内部流会经过 0x70B2/0x70D3）；窗口派发的空指针远调用会把
    客户机送进 IVT[0] —— 探针在线性 0 挂恢复钩子弹回主菜单循环。
  - BSS 语义并入 out/bss_truth.txt。

### 9.5 遗留（2026-09-04 终版：三条全部关闭）

1. ~~分区编辑屏导航~~ **已解决**（第五轮，见 §9.4 窗口反馈导航——0x7CC1/0x71B2/
   0x71D4 全部动态命中）。
   ~~遗留：Setup 菜单的自然入口键~~ **已定论（§9.4 附录）：不存在键盘入口**——
   菜单条为鼠标驱动（USB HID 栈），静态证据：全镜像无 LEFT/RIGHT/TAB/功能键
   比较路径、无 int33；动态证据：'s' + 8 行×ENTER 逐行扫描 + LEFT/RIGHT/TAB/
   F1-F10/ESC/SPACE/HOME/END 全扫均未打开 Setup 下拉窗。'b'/'s'/'p' 链保留
   far_call 强制开屏器（按键本身全真）。
2. ~~UHCI/OHCI 寄存器语义桩~~ **已解决**（§9.9/§9.10：各自 0x9902 门通过、
   门铃完成、BOT 周期实测；DRIVERS.md §6.6/§6.7）。
3. ~~BOT WRITE(10) 落盘~~ **已解决**（§9.8：bootlab disk_write + 数据 OUT
   捕获，disk 转 bytearray，产物 out/disk_writeback.bin）。

### 9.6 本轮新增/修改产物

| 文件 | 内容 |
|---|---|
| tools/bootlab.py | BDA tick、PORTSC×3 地址、usb_process_async 虚拟设备、AH=42 seg/off 修复、
  disk_read 越界、kbd_tail、按址 MMIO 钩子、fire_irq0 BDA 递增 |
| tools/probe_ehci_qh3/4/7.py、probe_digit.py、probe_setup.py、probe_setup2.py | QH/qTD 证据链、数字引导逐站、Setup 覆盖、窗口反馈导航（'b'/'s'/'p' 动态命中） |
| tools/qh_dump.log~qh_magic.log、digit.log、setup.log | 运行证据 |
| DRIVERS.md §6.2/6.2c/6.5 | 传输层 + 数字引导实测回填 |
| out/bss_truth.txt | 档案表/BSS 语义更新 |

### 9.7 双模式回归（验收门槛，本轮终态）

`bootlab.py --mode raw|bzimage --tick-insns 50000 --feed-watchdog --max-insns 145M`
(keys='')：

| mode | 结束 | int 数 | [AB37] loader SS | [B018] VBE | [CF43] 盘数 |
|---|---|---|---|---|---|
| raw | end, ticks=1674 | 217 | 0x3000 | 0x0101 | 2 |
| bzimage | end, ticks=1672 | 217 | 0x9000 | 0x0101 | 2 |

两模式同为正常 end、int 数逐位一致、BSS 关键槽语义一致（loader SS 按模式
呈现 0x3000/0x9000 —— bz 由 setup 重组镜像后保存 setup 段，正是预期值）。

**本轮顺带修复的回归门槛阻塞项（CLI 层，非镜像层）**：
- `main()` 从未把 `mode=` 传给 Plop —— CLI 的 bzimage 一直在跑 raw 内核路径
  （历史 bz CLI 结果全部无效；进程内 `Plop(mode="bzimage", entry=0x200)` 才是
  真 bz 路径，本已绿）。
- bz 模式 load_seg 必须保持 0x3000（self.base 承载 +0x100 坐标；0x9000 会破坏
  watchdog feed/BSS 转储等 base 相对接线）。
- bss_report/dump_bss 改用 self.base —— bz 下读 0x50000 重组镜像 BSS。

### 9.4 附录：Setup 菜单自然入口键定论（2026-09-04）

**结论：键盘上不存在 Setup 菜单的自然入口。** 菜单条（窗口 0xB76B，主屏
顶部，SETUP/ABOUT/SHUTDOWN 三项）是鼠标驱动的；Plop v5 的鼠标走自己的
USB HID 栈（镜像内无 int 0x33），bootlab 不模拟 HID 设备。

静态证据链：
- 菜单条注册：file 0x1034（sub_106A 把三事件写入 [0xC12C] 条目记录
  0xC32B+9k、[0xC133]=处理器）。**SETUP 屏三函数 0x6A64/0x6B20/0x6B91
  各画一窗（0x9948/0x9923 描述符，窗口 0xB7A4/0xB7DD/0xB816）后跑 sub_1331
  事件循环等 [0xB6AE]==0x11B(ESC) 退出；三函数全镜像无代码 xref**
  （数据字 0x6B20@file 0xB33 系 `call 0x7655` 的 E8 rel16 参数误报）——
  只可能被未覆盖的间接跳转/隐藏路径触达。
- 主循环（file 0x0CAE..0x0D03）只分发 'u'/'U'/'i'/'c'/'w'/'q'/'n'/'z'/
  '1'-'9'/ESC/0x1600/0x1615——无直达 SETUP 屏的键；0x1600/0x1615
  （LEFT/RIGHT 内部码）只在已装 USB 键盘会话出现（USB HID 层翻译），
  且语义是重扫/装驱动（0x8708），非进 SETUP 屏。
- 主列表键处理（sub_13AE）：仅 UP 0x4800/DOWN 0x5000/HOME 0x4700/END
  0x4F00/ENTER 0x1C0D —— **无 LEFT/RIGHT/TAB/功能键比较**（全反汇编 grep）。
- 逐行扫描（probe_setup4）：8 行 × POKE 选中 + 真 ENTER，无一行打开
  0xB7A4（2-8 行弹 0xBC18 设备菜单——设备行语义）。
- 按键全扫（probe_setup5）：left/right/tab/F1-F4/F10/esc/space/home/end
  无一打开 0xB7A4。
- 全二进制搜索 0x6BA3 的立即数编码（B8/BB/B9/BA/BE/BF/68/3D 形态）零命中
  —— 开屏器仅经 0x6B64 间接数据引用到达。
- 鼠标证据：子_6669 等宽计数、菜单条 x 坐标 +8 步进渲染（[0xB791]），
  条目选择记录 0xC32B + 19B 事件对 —— 鼠标命中检测形态；无 int33。

遗留的 'b'/'s'/'p' 工具链覆盖（§9.4）维持 far_call 强制开屏器 + 真实按键
（0x7CC1×4 / 0x71B2 / 0x71D4）。**虚拟 HID 指针可行性裁决**：Plop 的鼠标
走自有 USB HID 协议层（非 PS/2/int33），bootlab 需先模拟整套 USB HID
事件队列才能投递"点击 SETUP 标签"——超纲；"SETUP 屏无代码入口 + 键盘
无直达键"已是静态可证结论（三屏函数零 xref 为最强证据），
far_call 强制开屏器 + 真机键为可达上限。

**自然入口实证（2026-09-04 终轮，probe_natural3.py PASS）**：
SETUP 配置屏（0xB7A4）可经**纯按键**自然打开，无需 far_call：
`DOWN×5`（主列表 sel 1→6）→ `ENTER`（选中 SETUP 行，命中运行时 0x6B64
@tick 784）→ `ENTER`（确认视频模式消息窗 0xB96C）→ 命中运行时 0x6BA3
@tick 837（SETUP 屏绘制）→ 0xB7A4 窗口保持打开 @tick 872。
运行时坐标 = 文件 +0x100；探针断言 hits==[0x6B64,0x6BA3] && 0xB7A4 in vis
→ PASS。工具链 b/s/p 在此自然打开的 SETUP 屏内继续；0x7CC1（bootflag）位于
**edit-profile 屏（0xBA17）**，需在 SETUP 配置屏（0xB7A4）内继续行导航
定位"Select at start/设备行"ENTER 进入——该屏内行导航经 probe_setup_rows 确诊：**0xB7A4 打开后行表 [C128]=0x8E1D
仍是主列表 8 行，sel=6=SETUP 高亮不切换行表**；0x6B64 画 0xB7A4 后进入
sub_1331 事件循环，只处理 [0xB6AE]（非 ESC 键重复转并重画，不退出）——
0xB7A4 是"SETUP 面板信息窗"，行交互仍回主循环。edit-profile 屏
（0xBA17/0xB9A5）处理器（运行时 0x7B45 / file 0x772A）全镜像**零代码+零
数据 xref**，仅可经未覆盖间接跳转触达；数字键 '1'-'9'（0x1939→0x7CB2）
实为**引导加载**（probe_digit：0x7CB2→0x19DA→读盘→sub_1A76 boot），
非编辑屏。**结论（2026-09-04 终审）**：edit-profile 屏的注册表虽在 file 0x910E
起找到（9B 记录：行3 b2=5 handler=0x7B45 label="edit profile -"、行4
0x7A08、行5 0x7D6B、行6 0x7DB2），但该表**无代码安装者**（0x8FD7 区
`add ax,0x9109` 为数据误析；全镜像无 0x9109/0x910E 的指令引用）——
与 SETUP 三屏零 xref 同构，属 **plpbt.bin 引导版未接线的 UI 死区**
（Plop 完整版功能残留）。动态侧：0xB7A4 面板打开后 UP/DOWN/ENTER/
字母全扫均未触达 0x7B45（0x6B64 循环只认 ESC，UP 不移动面板行）。
**最终判定**：0x7CC1/0x71B2/0x71D4 的 edit-profile 工具链在 plpbt.bin
中无键盘/鼠标可达入口（UI 死区），far_call 强开 + 真机键为该工具的
**实证上限**；自然入口（无 far_call SETUP 屏打开）由 probe_natural3
PASS 独立成立并已落 doc。此为**镜像固有事实**而非分析缺口。
**补充证据（0xC135 记录表完整解码）**：
主屏行表 [0xC128] 指向运行时 0x8E1D 的 8 字指针表 → 各指向 0xC135+9k
记录；9B 记录 = {w0 标签指针, b2=1, b4=行号, b7:8=处理器}：
row0/1 = 设备行（标签 0xC32B/0xC377，处理器 0x1939 数字引导）、
row2 = " FLOPPY"(0xA1C2)+0x85A6、row3 = " CDROM"(0xA1CA)+0x8745、
row4 = " USB"(0xA1D1)+0x8808、row5 = " SETUP"(0xA1DF)+**0x6B64**、
row6 = "ABOUT"(0xA1E6)+0x83E4、row7 = "SHUTDOWN"(0xA1ED)+0x6B4A。
**但主循环键处理（sub_13AE）只改 [0xC126] 且 ENTER 走
表[[0xC128]+2*(sel-1)]，UP/DOWN 把 sel 限制在 1..[0xC127] 设备行内，
从无切到 row5(SETUP) 的键**；动态验证：POKE sel=5/6 + 真 ENTER 均被
主循环重绘重置（sel 弹回 1、弹 0xBC18 设备确认框后 boot）——菜单条行
不在 [0xC126] 键盘选区体系内，其激活只经独立的菜单条/鼠标事件路径。

### 9.8 BOT WRITE(10) 落盘（bootlab，本轮）

改动：`disk_attach` 统一转 bytearray；新增 `disk_write()`（对齐/越界拒绝，
越界记 `bios.notes`）；CBW 0x2A 解析缓存 (lba, cnt*512) 进 `usb_write`；
数据 OUT qTD payload 落盘；新 CBW 重同步 BOT 状态（防补丁失败串写）；
写入清单 `bios.disk_writes` → 产物 `out/disk_writeback.bin`（main 收尾转储）。

实测（probe_write10 模式 A，设备级确定性注入）：LBA1000 写 512B
（'W10-PERSISTENCE-PROBE:'+256B 图案）逐字节一致、CSW 'USBS'+tag 回读
正确、三支 qTD（CBW/数据/CSW）token 全部完成翻转、QH cur 清 0。
模式 B（补丁模块 CBW 0x28→0x2A）：CBW 实际在传输缓冲 0x9E000（构建点
[0x26ED] 会被 sub_52B2 复制走），补丁未达数据阶段（模块方向字节在 qTD
token 里）——落盘证明由模式 A + §9.9 UHCI 真 CBW 承担。

### 9.9 UHCI 传输层点亮（bootlab 修复链）

三处根因（按发现顺序）：
1. **UC_HOOK_INSN 不触发**（本 unicorn 构建注册成功但回调零命中，隔离
   最小复现坐实）——原 0xC000 端口窗语义从未生效，模块死等 USBCMD.bit0
   读回。修复：12 个 IN/OUT 位点钩子（opcode+端口窗双重校验）。
2. **UHCI 链接 16B 对齐**（帧表槽 0x9E2D2 掩 ~0x1F 读错成 0x9E2C0）——
   帧表/QH/TD 全链改掩 ~0xF。
3. **无门铃**（sub_31B1 只扫 TD 内存 Active 位，不碰端口）——控制器改由
   tick 驱动（fire_irq0 → uhci_advance），USBSTS 轮询帧推进保留为辅。

实测（probe_uhci，400M insns）：AL2 PCI 门 ✓（B101 EDX='ICP'）、AL3
find-by-class 0xC0300 → dev03 ✓、AL4 init 全链 ✓（BAR0 config 0x20 →
I/O 基址 0xC000、寄存器表 file 0x2CC1 {00,02,04,06,08,10,12}）、AL6
CCS ✓、**门铃（sub_2F95）×34、47 TD 完成、模块真 CBW tag=0x74354045
dlen=512 IN = BOT READ(10) LBA0**（MAGIC 后段 0x9906..0x9909）、AL 序列
[1..8] 满轮、sub_87FB 测试成功返回 —— 安装循环"首个成功模块获胜"
（`call 0x87fb; jb 下一轮` 成功 → jmp 0x1A90 退出）。

### 9.10 OHCI 传输层点亮（bootlab 修复链）

四处根因：
1. OHCI BAR 0x10100000 未映射 → mem_map + HcRevision=0x10/RhDescriptorA
   NDP=2 静态值。
2. **ED 布局误用 UHCI 式**（实为 +0 flags/+4 TailTd/+8 HeadTd/+0xC NextED，
   链 16B 对齐，TD 16B）→ ED 执行器重写（head 回收至 TailTd、done-head
   写 HCCA+0x80）。
3. 未建模寄存器读物化成 0（RhDescriptorA 的 NDP 读成 0 端口 → 端口地址
   表空 → 自旋野地址）→ 读钩子改"未建模偏移保留静态 RAM 值"，写钩子
   未建模偏移放行落 RAM。
4. **模块测试不含 BOT**（AL8 READ CAPACITY 门 `cmp [0x145b],8` 全镜像
   无写入者——监视点 9 次写全 0，真实硬件同样不可达）→ OHCI 轮的 BOT
   以设备级注入走真实管线验证（probe_ohci_bot：驱动自己的控制 ED +
   HcCommandStatus.CLF 门铃 + ED/TD 游走 + WDH 置位 + W1C 应答）。

实测（probe_ohci，usb_uhci_dev=False 让 UHCI 按 CCS 门干净失败后）：
AL2 ✓、AL3 0xC0310 → dev04 ✓、AL4 init ✓（HcControl=0x93 Operational+CLE、
HCCA=0x9CA00、ctrl head ED=0x9CB40）、**门铃 ×20、38 支枚举 TD**、AL
[1,2,3,4,5,6,7,8,6,7,8,9,3] 测试成功返回、shell 存活至 2157 ticks。
**BOT 全周期**：CBW OUT→WRITE(10) LBA1000 512B 落盘逐字节一致→CSW IN
tag 正确，41 TDs、WDH 置位、HCCA DoneHead=0x9D220、ED head 回收 0x9D230。

### 9.11 本轮新增/修改产物（2026-09-04 收尾轮）

| 文件 | 内容 |
|---|---|
| tools/bootlab.py | WRITE(10) 落盘（disk_write/数据OUT捕获/disk_writeback）、PCI 多设备
  桩（B103 类码+prog-if+SI 精确匹配）、UHCI 端口语义+TD/帧表引擎（位点钩子）、
  OHCI MMIO 语义+ED/TD 引擎、tick 驱动双引擎推进、usb_uhci_dev/usb_ohci_dev 开关 |
| tools/probe_write10.py / probe_uhci.py / probe_ohci.py / probe_ohci_bot.py | 四条 USB 证据链 |
| tools/probe_setup3/4/5.py | 自然入口键排除实验（行扫描/按键全扫） |
| tools/regression_raw_new.log / regression_bz_new.log | 双绿复验（1674/1672、217 ints） |
| DRIVERS.md §6.4/6.6/6.7/6.8 + §6.2c | UHCI/OHCI 实测表、虚拟控制器要点、遗留关闭 |
| out/disk_writeback.bin | WRITE(10) 落盘产物 |
