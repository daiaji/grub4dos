#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Menu-bar key sweep: the Setup entry lives in the menu-bar window
(0xB76B, flag 0x9) on the main screen, not in the device list.  Sweep
candidate keys (left/right/tab/function keys/plain letters), watching for
the Setup menu window 0xB7A4 after each."""
import os, sys, struct
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bootlab
from bootlab import Plop

M = {0x6BA3: "SETUP MENU OPENER", 0x7B45: "EDITOR OPENER"}
counts, phases = {}, []
def extra_milestones(uc, cs_off):
    if cs_off in M and cs_off not in counts:
        counts[cs_off] = 0
        phases.append((p.ticks_fired, M[cs_off]))
        print("[milestone] %s @tick %d" % (M[cs_off], p.ticks_fired), flush=True)

def vis():
    out = set()
    for i in range(26):
        desc = struct.unpack('<H', bytes(p.uc.mem_read(p.base + 0xA825 + i*2, 2)))[0]
        if 0x1000 < desc < 0xC000 and (p.uc.mem_read(p.base + desc, 1)[0] & 1):
            out.add(desc)
    return out

CANDS = [("left", 0x4B00), ("right", 0x4D00), ("tab", 0x0F00),
         ("f1", 0x3B00), ("f2", 0x3C00), ("f3", 0x3D00), ("f4", 0x3E00),
         ("f10", 0x4400), ("esc", 0x011B), ("space", 0x3920),
         ("home", 0x4700), ("end", 0x4F00)]
cand_i = [0]
wait_n = [0]
st = ["settle"]
found = []

def sample():
    if st[0] == "done":
        return
    v = vis()
    if st[0] == "settle":
        if p.ticks_fired > 350:
            st[0] = "try"
        return
    if st[0] == "try":
        if cand_i[0] >= len(CANDS):
            st[0] = "done"
            print("SWEEP DONE, found:", found, flush=True)
            return
        name, code = CANDS[cand_i[0]]
        p.bios.key_push(code)
        wait_n[0] = 0
        st[0] = "check"
        print("try %s ..." % name, flush=True)
        return
    if st[0] == "check":
        wait_n[0] += 1
        if 0xB7A4 in v:
            print(">>> %s OPENS THE SETUP MENU <<<" % CANDS[cand_i[0]][0],
                  flush=True)
            found.append(CANDS[cand_i[0]][0])
            st[0] = "done"
            return
        if 0xB7A4 not in v and wait_n[0] > 20:
            cand_i[0] += 1
            st[0] = "try"
        return

_n2 = [0]
def extra2(uc, cs_off):
    extra_milestones(uc, cs_off)
    _n2[0] += 1
    if _n2[0] >= 400_000:
        _n2[0] = 0
        sample()

p = Plop(tick_insns=200_000, feed_watchdog=True, hook_extra=extra2,
         max_insns=600_000_000)
p.bios.disk_attach(bootlab.default_disk())
r = p.run()
print("run:", r)
print("found:", found)
print("milestones:", phases)
