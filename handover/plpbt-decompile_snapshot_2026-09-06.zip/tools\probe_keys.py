#!/usr/bin/env python3
"""Inject keys; does the menu react (select device / boot / int19)?"""
import sys, os, struct
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from unicorn import *
from unicorn.x86_const import *
from bootlab import Plop
_xc = sys.modules['unicorn.x86_const']
for _n in dir(_xc):
    if _n.startswith('UC_X86_REG_'):
        globals()[_n[3:]] = getattr(_xc, _n)

def build_disk():
    disk = bytearray(8*1024*1024)
    mbr = bytearray(512); mbr[446]=0x80; mbr[447:450]=bytes([0,1,1]); mbr[450]=0x06
    mbr[451:454]=bytes([15,63,63]); mbr[454:458]=struct.pack('<I',63); mbr[458:462]=struct.pack('<I',1022)
    mbr[510:512]=b'\x55\xAA'; disk[0:512]=mbr
    pbs=bytearray(512); pbs[510:512]=b'\x55\xAA'; disk[63*512:64*512]=pbs
    return bytes(disk)

# keys: try Enter (0x1C0D) then Down arrow then Enter
keys=b"\x1c\x0d"
p = Plop(load_seg=0x7C00, entry=0x8BE, edd_type='ATA', max_insns=60_000_000, keys=keys)
p.bios.disk_attach(build_disk())
base = 0x7C00<<4
W,H = 80*8, 25*8
def mkdesc(size):
    d = bytearray(0x25)
    struct.pack_into('<I', d, 0x00, size)
    struct.pack_into('<H', d, 0x14, W)
    struct.pack_into('<H', d, 0x16, H)
    d[0x18]=1
    struct.pack_into('<H', d, 0x19, W)
    struct.pack_into('<H', d, 0x1B, 0)
    struct.pack_into('<H', d, 0x1D, H)
    struct.pack_into('<H', d, 0x1F, W)
    struct.pack_into('<H', d, 0x21, H)
    struct.pack_into('<H', d, 0x23, 0)
    return bytes(d)
p.uc.mem_write(base+0x9A26, mkdesc(0x2320))
p.uc.mem_write(base+0x9A4B, mkdesc(0x1000))
# put a real menu text template at 0xB732 (0x39 bytes): first byte 0x0B border, then a title?
# copy from the file's 0x9B13 font? no - this is the window template (geometry defaults)
p.uc.mem_write(base+0xB732, bytes(bytearray(0x39)))
p.uc.mem_write(base+0xB76B, bytes(bytearray(0x39)))

log=[]
def code(uc, addr, size, ud):
    off=addr-base
    if off==0x6481:
        bp=uc.reg_read(X86_REG_BP)&0xFFFF
        sz=struct.unpack('<I', bytes(uc.mem_read(base+bp,4)))[0]
        log.append('alloc bp=%04X sz=0x%X'%(bp,sz))
    if off==0x5EC2: log.append('DRAW')
    if off in (0x172E,0x6317,0x833D):
        log.append('KEYPOLL %04X ax=%04X'%(off, uc.reg_read(X86_REG_AX)&0xFFFF))
    if off==0x665D:  # rep movsb
        pass
p.uc.hook_add(UC_HOOK_CODE, code)
r=p.run()
print('run:', r[:140])
print('int16 count:', sum(1 for t in p.bios.int_trace if t[0]==0x16))
print('int19 count:', sum(1 for t in p.bios.int_trace if t[0]==0x19))
print('last ints:')
for t in p.bios.int_trace[-15:]:
    n,ax,bx,cx,dx,si,di,cs,ip=t
    print('  int %02X ax=%04X from %04X:%04X'%(n,ax,cs,ip))
print('log:', log[:50])
