import sys, struct
import bootlab, unicorn
from unicorn.x86_const import *
_xc = __import__('unicorn.x86_const', fromlist=['x'])
for _n in dir(_xc):
    if _n.startswith('UC_X86_REG_'):
        globals()[_n[3:]] = getattr(_xc, _n)

p = bootlab.Plop(load_seg=0x7C00, entry=0x8BE)
disk = bytearray(8 * 1024 * 1024)
mbr = bytearray(512); mbr[446] = 0x80; mbr[450] = 0x06
mbr[454:458] = struct.pack('<I', 63); mbr[458:462] = struct.pack('<I', 1022)
mbr[510:512] = b'\x55\xaa'
disk[0:512] = mbr
pbs = bytearray(512); pbs[0] = 0xEA; pbs[510:512] = b'\x55\xaa'
disk[63*512:63*512+512] = pbs
p.bios.disk_attach(bytes(disk))

uc = p.uc
base = 0x7C000
last = []
def hc(u, addr, size, ud):
    if addr >= base and addr < base + 0x10000:
        last.append(addr - base)
        if len(last) > 40:
            last.pop(0)
uc.hook_add(unicorn.UC_HOOK_CODE, hc)
r = p.run()
print('run:', r[:70])
print('--- last 40 executed image offsets:')
print(' '.join('%04X' % a for a in last))