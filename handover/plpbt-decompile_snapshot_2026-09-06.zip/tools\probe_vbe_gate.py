#!/usr/bin/env python3
"""Probe sub_5B9E (video-mode setup) and whether 0x9A26 is written before allocator."""
import sys, os, struct
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from unicorn import *
from unicorn.x86_const import *
from bootlab import Plop
_xc = sys.modules['unicorn.x86_const']
for _n in dir(_xc):
    if _n.startswith('UC_X86_REG_'):
        globals()[_n[3:]] = getattr(_xc, _n)

def build_disk():
    disk = bytearray(8*1024*1024)
    mbr = bytearray(512); mbr[446]=0x80; mbr[447:450]=bytes([0,1,1]); mbr[450]=0x06
    mbr[451:454]=bytes([15,63,63]); mbr[454:458]=struct.pack('<I',63); mbr[458:462]=struct.pack('<I',1022)
    mbr[510:512]=b'\x55\xAA'; disk[0:512]=mbr
    pbs=bytearray(512); pbs[510:512]=b'\x55\xAA'; disk[63*512:64*512]=pbs
    return bytes(disk)

p = Plop(load_seg=0x7C00, entry=0x8BE, edd_type='ATA')
p.bios.disk_attach(build_disk())
base = 0x7C00<<4
events=[]
def code(uc, addr, size, ud):
    if addr == base+0x6525:          # device name table copy
        events.append('sub_6525 entered')
    if addr == base+0x5B9E:          # video mode setup entry
        b062 = uc.mem_read(base+0xB062,1)[0]
        events.append('sub_5B9E: [0xB062]=%02X' % b062)
    if addr == base+0x5C02:          # after reading [0xB01A]
        b01a = uc.mem_read(base+0xB01A,1)[0]
        b018 = struct.unpack('<H',bytes(uc.mem_read(base+0xB018,2)))[0]
        events.append('  @5C02 [0xB01A]=%d [0xB018]=%04X' % (b01a, b018))
    if addr == base+0x5C44:          # VBE graphics branch
        events.append('  -> VBE graphics branch (0x5C44)')
    if addr == base+0x0B44:          # allocator call site
        n9 = struct.unpack('<I', bytes(uc.mem_read(base+0x9A26,4)))[0]
        events.append('@0B44 alloc: 0x9A26=%08X' % n9)
        uc.emu_stop()
p.uc.hook_add(UC_HOOK_CODE, code)
r = p.run()
print('run:', r[:80])
for e in events: print(e)
