#!/usr/bin/env python3
"""Definitive: hook MEM_WRITE on descriptor region 0x9A00..0x9AF0 + template 0xB700..0xB800
to see if ANY code writes them during boot (raw mode)."""
import sys, os, struct
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from unicorn import *
from unicorn.x86_const import *
from bootlab import Plop
_xc = sys.modules['unicorn.x86_const']
for _n in dir(_xc):
    if _n.startswith('UC_X86_REG_'):
        globals()[_n[3:]] = getattr(_xc, _n)

def build_disk():
    disk = bytearray(8*1024*1024)
    mbr = bytearray(512); mbr[446]=0x80; mbr[447:450]=bytes([0,1,1]); mbr[450]=0x06
    mbr[451:454]=bytes([15,63,63]); mbr[454:458]=struct.pack('<I',63); mbr[458:462]=struct.pack('<I',1022)
    mbr[510:512]=b'\x55\xAA'; disk[0:512]=mbr
    pbs=bytearray(512); pbs[510:512]=b'\x55\xAA'; disk[63*512:64*512]=pbs
    return bytes(disk)

p = Plop(load_seg=0x7C00, entry=0x8BE, edd_type='ATA')
p.bios.disk_attach(build_disk())
base = 0x7C00<<4
hits=[]
def hook_wr(uc, access, addr, size, val, ud):
    off = addr - base
    if 0x9A00 <= off < 0x9AF0 or 0xB700 <= off < 0xB800:
        ip = uc.reg_read(X86_REG_IP); cs = uc.reg_read(X86_REG_CS)
        hits.append('WRITE %06X (off %04X) size %d from %04X:%04X' % (addr, off, size, cs, ip))
p.uc.hook_add(UC_HOOK_MEM_WRITE, hook_wr)
r = p.run()
print('run:', r[:80])
print('writes to descriptor/template region:', len(hits))
for h in hits[:40]: print(' ', h)
