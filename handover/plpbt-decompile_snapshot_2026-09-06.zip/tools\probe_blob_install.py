#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Empirically measure the int13-blob install copies made by sub_8442 during the
'u' USB path: at each rep movsb capture (SI source, CX length, hookseg), then
after the copy byte-compare hookseg:0x100.. against file[SI-0x100 ...] to
establish the TRUE source extents of the three USB controller modules and the
redirector, settling whether the header len16 at [si+2] is the copy length.
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bootlab
from bootlab import Plop
from unicorn import *

CAPS = []          # dicts: attempt, si_file, cx, hookseg, first16, match_len
CS_SUB8442_END = 0x8495   # runtime cs offsets (file 0x8442..0x8495)
REP_AT = 0x8556           # cs offset of `rep movsb` (before execution: cx loaded)
AFTER_AT = 0x8558         # cs offset of `push es` right after rep (copy done)

def make_extra():
    state = {"n": 0}
    def extra(uc, cs_off):
        if cs_off == REP_AT:
            cx = uc.reg_read(bootlab.X86_REG_CX)
            si = uc.reg_read(bootlab.X86_REG_SI)
            hookseg = uc.reg_read(bootlab.X86_REG_ES)
            if cx and si:
                state["n"] += 1
                state["cur"] = dict(n=state["n"], si=si, cx=cx, hookseg=hookseg,
                                    buf=None)
        elif cs_off == AFTER_AT and state.get("cur") is not None:
            cur = state.pop("cur", None)
            if cur:
                hookseg = cur["hookseg"]
                n = min(cur["cx"], 4096)
                blk = bytes(uc.mem_read(hookseg * 16 + 0x100, n))
                cur["first16"] = blk[:16].hex()
                cur["buf"] = blk
                CAPS.append(cur)
    return extra

def match_file(cap):
    """Where do the copied bytes live in the file?  Search by exact 16B head
    then extend the match forward as far as it stays identical."""
    si_file = cap["si"] - 0x100
    head = bytes.fromhex(cap["first16"])
    pos = bootlab.open(bootlab.BIN, "rb").read().find(head)
    if pos < 0:
        return None
    # cap starts at the very first byte of the blob; hookseg:0x100 == blob head
    data = open(bootlab.BIN, "rb").read()
    n = cap["cx"]
    ext = 0
    while pos + ext < len(data) and ext < n and data[pos+ext] == cap["buf"][ext]:
        ext += 1
    return pos, si_file, ext, n

p = Plop(keys="u", edd="USBD", hook_extra=make_extra())
p.bios.disk_attach(bootlab.default_disk())
r = p.run()
print("run:", r)
print("captured install copies: %d" % len(CAPS))
for cap in CAPS:
    m = match_file(cap)
    print("attempt %d: si=cs:%04X(file %04X) cx=0x%X(%d) hookseg=%04X head=%s  head_at_file=%s"
          % (cap["n"], cap["si"], cap["si"] - 0x100, cap["cx"], cap["cx"],
             cap["hookseg"], cap["first16"], m[0] if m else "-"))
    if m:
        pos, si_file, ext, n = m
        print("   file match: search hit file %04X; si-derived file start %04X; "
              "extent verified %d/%d bytes identical (si+ext=%04X)" % (pos, si_file, ext, n, pos+ext))
# which install attempts got how far?  dump messages
print("int13 magic-cmd trace tail:")
for i, (n, ax, bx, cx, dx, si, di, cs, ip) in enumerate(p.bios.int_trace[-40:]):
    print("  int %02X from %04X:%04X ax=%04X bx=%04X cx=%04X dx=%04X" % (n, cs, ip, ax, bx, cx, dx))
