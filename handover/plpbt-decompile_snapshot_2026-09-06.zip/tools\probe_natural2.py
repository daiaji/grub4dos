#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Natural-entry hunt v2: row-ENTER popup menu tree crawl.

probe_setup4 found rows 2-8 pop a window (0xBC18) on ENTER that was never
explored.  This probe crawls that popup: for each candidate action key
(DOWN/ENTER/letters), watches for the Setup partition-screen opener
(runtime 0x6BA3 / window 0xB7A4) or any new window, and records the path.
Boot hijacks are recovered to the menu loop.
"""
import os, sys, struct
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bootlab
from bootlab import Plop

GOAL = 0x6BA3            # runtime: Setup partition-screen opener (0x6AA3 file)
W_SETUP = 0xB7A4

goal_hits = []
def extra(uc, cs_off):
    if cs_off == GOAL:
        goal_hits.append(p.ticks_fired)
        print('>>> [GOAL] 0x6BA3 hit @tick %d' % p.ticks_fired, flush=True)

def d8(o):  return p.uc.mem_read(p.base + o, 1)[0]
def w8(o, v): p.uc.mem_write(p.base + o, bytes([v]))
def push(w): p.bios.key_push(w)

def vis():
    out = {}
    for i in range(26):
        desc = struct.unpack('<H', bytes(p.uc.mem_read(p.base + 0xA825 + i*2, 2)))[0]
        if 0x1000 < desc < 0xC000:
            f = d8(desc)
            if f & 1:
                out[desc] = f
    return out

BASE_WIN = {0xB732, 0xB76B}
LETTERS = {'b': 0x30, 'i': 0x17, 'c': 0x2E, 's': 0x1F, 'l': 0x26,
           'd': 0x20, 'e': 0x12, 'r': 0x13, 'p': 0x19, 'o': 0x18,
           'w': 0x11, 'q': 0x10, 'u': 0x16, 't': 0x14, 'h': 0x23}

# state machine -----------------------------------------------------------
st = ['idle']
row = [1]
phase = ['enter-row']       # enter-row -> popup? -> popup-crawl
popup_seen = [False]
step = [0]
wait = [0]
path = []                    # [(desc, action) ...]
crawl_state = ['at-top']     # at-top: press ENTER; after: press DOWN
letters_tried = [0]
done = [False]

def sample():
    step[0] += 1
    if done[0]:
        return
    cs = p.uc.reg_read(bootlab.X86_REG_CS)
    v = vis()
    vset = set(v)
    # boot / left image?
    if cs != 0x3000:
        print('[recover] cs=%04X at path %s' % (cs, path[-4:]), flush=True)
        p.uc.reg_write(bootlab.X86_REG_CS, 0x3000)
        p.uc.reg_write(bootlab.X86_REG_IP, 0x0DA2)
        p.uc.reg_write(bootlab.X86_REG_SP, 0xFFFE)
        path.append(('boot', None))
        row[0] += 1
        st[0] = 'reset'
        phase[0] = 'enter-row'
        return
    if phase[0] == 'enter-row':
        if row[0] > 8:
            print('=== crawl exhausted, goal hits:', goal_hits, flush=True)
            done[0] = True
            return
        w8(0xC126, row[0])
        push(0x1C0D)
        path.append(('row%d-ENTER' % row[0], None))
        phase[0] = 'watch-popup'
        wait[0] = 0
        return
    if phase[0] == 'watch-popup':
        wait[0] += 1
        new = vset - BASE_WIN
        if new:
            print('row %d popup: %s' % (row[0], sorted(hex(x) for x in new)), flush=True)
            popup_seen[0] = True
            path.append(('popup:%s' % hex(sorted(new)[0]), None))
            crawl_state[0] = 'letters'
            letters_tried[0] = 0
            phase[0] = 'popup-crawl'
            wait[0] = 0
            return
        if wait[0] > 12:                       # nothing popped
            print('row %d: no popup' % row[0], flush=True)
            path.append(('none', None))
            row[0] += 1
            phase[0] = 'enter-row'
        return
    if phase[0] == 'popup-crawl':
        wait[0] += 1
        if W_SETUP in vset or goal_hits:
            print('=== NATURAL ENTRY FOUND === path:', path, flush=True)
            done[0] = True
            return
        if wait[0] < 8:
            return
        wait[0] = 0
        # try: letters first, then arrows/enter combos
        if crawl_state[0] == 'letters':
            if letters_tried[0] < len(LETTERS):
                k = list(LETTERS.values())[letters_tried[0]]
                ch = list(LETTERS.keys())[letters_tried[0]]
                letters_tried[0] += 1
                push(k)
                path.append(("'%s'" % ch, None))
                return
            crawl_state[0] = 'down-enter'
            return
        if crawl_state[0] == 'down-enter':
            # move down one and ENTER; watch for new sub-windows
            push(0x5000)
            path.append(('down', None))
            crawl_state[0] = 'enter-watch'
            return
        if crawl_state[0] == 'enter-watch':
            push(0x1C0D)
            path.append(('enter', None))
            crawl_state[0] = 'subcheck'
            return
        if crawl_state[0] == 'subcheck':
            sub = vset - BASE_WIN
            if len(sub) > 1:                    # a second window opened
                print('sub-window from popup:', sorted(hex(x) for x in sub), flush=True)
                path.append(('sub:%s' % hex(sorted(sub)[0]), None))
                push(0x011B)
                crawl_state[0] = 'down-enter'
                return
            if W_SETUP in vset or goal_hits:
                done[0] = True
                return
            # popup still there: keep crawling (bounded)
            if len(path) > 60:
                print('crawl too deep, giving up this popup', flush=True)
                for _ in range(4):
                    push(0x011B)
                phase[0] = 'enter-row'
                row[0] += 1
                popup_seen[0] = False
                return
            crawl_state[0] = 'down-enter'
            return
    if phase[0] == 'reset':
        st[0] = 'idle'
        phase[0] = 'enter-row'
        return

_n = [0]
def extra2(uc, cs_off):
    extra(uc, cs_off)
    _n[0] += 1
    if _n[0] >= 500_000:
        _n[0] = 0
        if p.ticks_fired > 350:
            sample()

p = Plop(tick_insns=200_000, feed_watchdog=True, hook_extra=extra2,
         max_insns=400_000_000)
p.bios.disk_attach(bootlab.default_disk())
r = p.run()
print('run:', r)
print('goal hits:', goal_hits)
print('final windows:', sorted(hex(x) for x in vis()))
