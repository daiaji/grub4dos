#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
plpbt.bin static analyzer v3 (2026-09-02, +0x100 model)

Addressing model (VERIFIED dynamically, see DYNAMIC_FINDINGS.md s6.1):
  * the image loads at CS:0x100  =>  CS offset X == file offset X-0x100
  * raw entry CS:0x9BE == file 0x8BE;  loader CS = 0x3000 (self-check file 0x0D39)
  * every data displacement the CODE emits is a RUNTIME-CS offset;
    to map to a file offset subtract 0x100.
  * BSS: runtime CS 0xAB3B..0xF8CF (zeroed at entry, 4D94 bytes) == file 0xAA3B..0xF7CF
    (image ends at file 0xAA37 == runtime CS 0xAB37, leaving the 4-byte SS:SP save
     slot at CS 0xAB37..0xAB3A right at the image tail - fully consistent).
  * int13 handler blobs are position-independent: each blob starts with
    EB <skip> <len16>, is copied to hookseg:0x100 by sub_8442 (cx=[si+2]), and its
    internal displacements are blob-local == file-local for the blob region.
  * v3 adds: dual-coordinate comments (FILE/cs), blob table, per-region sweep
    attribution, corrected string/BSS/IVT annotation.

Outputs: out/disasm_full.asm, out/ports.txt, out/strings.txt, out/functions.txt,
         out/stats.txt  (old addressing-model copies kept in out/old_model/)
"""
import os, re, struct, collections
from capstone import Cs, CS_ARCH_X86, CS_MODE_16
from capstone.x86 import X86_OP_IMM, X86_OP_MEM, X86_OP_REG

HERE   = os.path.dirname(os.path.abspath(__file__))
ROOT   = os.path.dirname(HERE)
OUT    = os.path.join(ROOT, "out")
BIN    = os.path.join(ROOT, "plpbt.bin")

data = open(BIN, "rb").read()
END  = len(data)                 # file length 0xAA37
CS_RUNTIME_TOP = END + 0x100     # runtime CS 0xAB37 == file end
BSS_CS_LO, BSS_CS_HI = 0xAB3B, 0xF8CF   # runtime CS coords of cleared BSS

md = Cs(CS_ARCH_X86, CS_MODE_16)
md.detail = True

# ------------------------------------------------------------------ blobs
# Module starts (file coords; runtime CS = +0x100).  VERIFIED live (2026-09-02):
# the 'u' handler calls sub_8442 with si = cs 0x479D/0x2453/0x34E9 (= file
# 0x469D/0x2353/0x33E9); sub_8442 copies cx=[si+2] bytes from the module start
# to hookseg:0x100 (hookseg from the EBDA shrink, live value 0x9A70), and the
# copy is byte-identical to file[si-0x100 .. +cx].  The three USB modules
# OVERLAP in file space: each region shares the common driver-tail bytes that
# follow the earliest region end; their unique (controller-specific) code is
# at the region heads.  The redirector (140B) is a separate small region.
BLOB_DEFS = [   # (file_off, len16, role)
    (0x2353, 0x4F86, "UHCI usb module (20358B; install si=cs:0x2453)"),
    (0x33E9, 0x2DEF, "OHCI usb module (11759B; install si=cs:0x34E9)"),
    (0x469D, 0x4C6A, "EHCI usb module (19562B; install si=cs:0x479D)"),
    (0x5841, 0x008C, "redirector (140B; int13 0x80<->[0x104] swap, install si=cs:0x5941)"),
]
BLOBS = []
for off, ln, role in BLOB_DEFS:
    BLOBS.append((off, off+ln, role))
def blob_of(f):
    for lo, hi, role in BLOBS:
        if lo <= f < hi:
            return role
    return None

# 'DHKC'-class companion module (another installed int13 driver, see DF s6.3)
dhkc = data.find(b"DHKC")
DHKC_MOD = dhkc if dhkc > 0 else None

def blob_of(f):
    for lo, hi, role in BLOBS:
        if lo <= f < hi:
            return role
    return None

# ------------------------------------------------------------------ strings
def find_strings(minlen=4):
    res, cur, start = [], [], 0
    for i, b in enumerate(data):
        if 32 <= b < 127:
            if not cur: start = i
            cur.append(chr(b))
        else:
            if len(cur) >= minlen: res.append((start, "".join(cur)))
            cur = []
    if len(cur) >= minlen: res.append((start, "".join(cur)))
    return res

strings = find_strings()
string_by_start = {s: t for s, t in strings}
string_ranges = [(s, s+len(t), t) for s, t in strings]

def string_at_file(f):
    for lo, hi, t in string_ranges:
        if lo <= f < hi:
            return (f-lo, t)
    return None

# ------------------------------------------------------------------ roots
# real mode entry + runtime-reachable roots; blobs entered via their own code
# once copied (their internal offsets are file-local, so file-space descent
# applies); PoLP cmp-sites seed the blob dispatchers.
roots = [0x8BE]                     # raw entry (the e9 at 0 jumps here)
for m in re.finditer(b"PoLP", data):
    o = m.start() - 2
    if o < 0x8000:
        roots.append(o)
for off, _, _ in BLOBS:
    roots.append(off)
if DHKC_MOD:
    roots.append(DHKC_MOD)
roots = sorted(set(roots))

INT_NAMES = {
    0x10: "BIOS video", 0x13: "BIOS disk", 0x14: "serial", 0x15: "BIOS sys/services",
    0x16: "BIOS keyboard", 0x17: "printer", 0x1A: "BIOS time/RTC", 0x19: "int19 reboot",
    0x20: "DOS term", 0x21: "DOS", 0x29: "DOS fastout", 0x40: "BIOS disk (fd)",
    0x08: "PIC IRQ0 timer", 0x09: "PIC IRQ1 kbd", 0x0E: "PIC IRQ6 fdc", 0x0D: "PIC IRQ5",
    0x70: "PIC IRQ8 RTC", 0x76: "PIC IRQ14 IDE0", 0x77: "PIC IRQ15 IDE1",
}
PORT_NAMES = {
    0x60: "kbd data", 0x64: "kbd cmd/status", 0x92: "A20/fast reset (port 92)",
    0x70: "CMOS addr", 0x71: "CMOS data", 0xA0: "PIC2", 0xA1: "PIC2 data",
    0x20: "PIC1", 0x21: "PIC1 data", 0x40: "PIT ch0", 0x43: "PIT cmd",
    0x1F0: "IDE0 data", 0x1F7: "IDE0 cmd/status", 0x3F6: "IDE0 dev ctrl",
    0x170: "IDE1 data", 0x177: "IDE1 cmd/status", 0x376: "IDE1 dev ctrl",
    0x3F0: "FDC", 0x3F2: "FDC digout", 0x3F4: "FDC status", 0x3F5: "FDC data",
    0x3C0: "VGA attr", 0x3C4: "VGA seq", 0x3C8: "VGA DAC w", 0x3C9: "VGA DAC d",
    0x3CE: "VGA gfx", 0x3B4: "VGA CRTC", 0x3BA: "VGA mono status", 0x3DA: "VGA status",
    0xCF8: "PCI addr", 0xCFC: "PCI data", 0x2F8: "COM2", 0x3F8: "COM1", 0x378: "LPT1",
    0x84: "port 0x84 (pos)", 0x88: "port 0x88 (pos)",
}
# known USB controller MMIO/IO windows that the modules program (discovery in v3 run)
CONTROLLER_REGS = {
    0x20: "PIT ch0", 0x43: "PIT cmd",
}
# +0x100 model:  known runtime-CS landmarks (from dynamic phase), file = cs-0x100
KNOWN_RUNTIME = {
    0x100:  "int13 handler blob install base (hookseg:0x100, IVT 0:0x4C)",
    0x104:  "virtual drive number slot cs:[0x104] (blob data)",
    0x107:  "saved old int13 vector (blob data, patched by TINI)",
    0x9BE:  "raw entry (loader jmp here)",
    0xAA37: "image end == SS:SP save slot [cs:0xAB37..AB3A] starts here",
    0xAB3B: "BSS start (cleared at entry)",
    0xF8CF: "BSS end",
    0xB6E9: "hook-active flag [B6E9] (0 during install)",
    0xB6E8: "watchdog counter [B6E8] (3->dec; 0 => ljmp 0:0 into BIOS sled)",
    0x66FB: "int8 IRQ0 handler (file 0x65FB)",
    0xB061: "busy-wait timer flag [B061]",
    0xB07C: "resident-flag [B07C] (set by external MBR bootstrap, CTRL-A polling)",
    0xB075: "disk bitmap [B075]",
    0xB6F8: "last booted drive [B6F8]=dl",
    0xCF43: "disk count [CF43]",
    0xCF44: "usb count [CF44]",
    0xCF5B: "current hook segment [CF5B]",
    0xB242: "boot-config table (per-device, from disk profile)",
    0xC126: "menu selection [C126]",
    0xC128: "navigator jumptable [C128]",
    0xC133: "menu action fn [C133]",
    0xC12C: "menu-bar current item record ptr [C12C] (0xC32B + 9k records)",
    0x6B64: "menu-bar SETUP item handler (file 0x6A64; 0x6A4A dispatches ABOUT/SHUTDOWN)",
    0x8517: "do_boot_device (dl) - boots via blob/0x80",
    # ---- UHCI module (runtime ip = file - 0x2253; installed hookseg:0x100)
    0x25C4: "UHCI AL dispatcher (int13 hook file 0x2483, AH=0x99)",
    0x2BF4: "UHCI AL2 gate: PCI BIOS presence B101h (file 0x2AF4)",
    0x280E: "UHCI find-by-class 0x0C0300 (file 0x270E)",
    0x2824: "UHCI controller init: BAR0@cfg20 -> I/O base (file 0x2724)",
    0x2CC8: "UHCI reg-pointer table {00,02,04,06,08,10,12} (file 0x2BC8)",
    0x2E02: "UHCI HC reset + HCHalted wait (file 0x2D02)",
    0x2863: "UHCI frame list init: 1024x QH|2 (file 0x2763)",
    0x2F95: "UHCI submit+wait: frame[0]=QH|2, poll USBSTS.USBINT (file 0x2E95)",
    0x303C: "UHCI TD build 32B/step (file 0x2F3C)",
    0x2927: "UHCI enumeration SET_ADDRESS/GET_DESCRIPTOR (file 0x2827)",
    # ---- OHCI module (runtime ip = file - 0x32E9)
    0x364C: "OHCI AL dispatcher (int13 hook file 0x3507, AH=0x99)",
    0x3BB6: "OHCI AL2 gate: PCI BIOS presence B101h (file 0x3AB6)",
    0x382E: "OHCI find-by-class 0x0C0310 (file 0x372E)",
    0x3CE5: "OHCI controller init: BAR0@cfg10 -> op regs + HCCA (file 0x3BE5)",
    0x4264: "OHCI doorbell: HcControl|=CLE, CLF/BLF, poll WDH (file 0x4164)",
    0x4066: "OHCI TD build 16B CC=0xF (file 0x3F66)",
    0x42F0: "OHCI port power/reset (file 0x41F0)",
    0x436D: "OHCI CCS check (file 0x426D)",
}

# ------------------------------------------------------------------ recursive descent
code = {}
funcs = set(roots)
indirect_sites = []
bad_disasm = []
seen = set()
queue = list(roots)
while queue:
    a = queue.pop()
    if a in seen or not (0 <= a < END):
        continue
    seen.add(a)
    addr = a
    while 0 <= addr < END and addr not in code:
        try:
            ins = next(md.disasm(data[addr:addr+16], addr))
        except StopIteration:
            bad_disasm.append(addr); code[addr] = None; break
        code[addr] = ins
        m = ins.mnemonic
        ops = ins.operands
        first_imm = ops[0].imm if (ops and ops[0].type == X86_OP_IMM) else None
        is_branch = m in ("jmp", "call") or m.startswith("j") or m.startswith("loop") or m == "jecxz"
        if is_branch:
            if first_imm is not None:
                t = first_imm
                if m == "call": funcs.add(t)
                if 0 <= t < END and t not in seen: queue.append(t)
                if m == "jmp": break
            else:
                indirect_sites.append(addr)
                if m == "jmp": break
        elif m in ("ret", "retf", "iret", "hlt", "ud2"):
            break
        addr += ins.size

# ------------------------------------------------------------------ linear sweep of gaps
covered = bytearray(len(data))
for va, ins in code.items():
    if ins:
        for k in range(ins.size):
            covered[va + k] = 1
swept = set()
sweep_regions = []
o = 0
while o < len(data):
    if not covered[o]:
        j = o
        while j < len(data) and not covered[j]: j += 1
        if j - o >= 16:
            sweep_regions.append((o, j))
            addr = o
            while addr < j:
                try:
                    ins = next(md.disasm(data[addr:j], addr))
                except StopIteration:
                    addr += 1; continue
                code[addr] = ins
                swept.add(addr)
                addr += ins.size
        o = j
    else:
        o += 1

# ------------------------------------------------------------------ xrefs
xrefs = collections.defaultdict(list)
for va, ins in code.items():
    if ins is None: continue
    m = ins.mnemonic
    is_branch = m in ("jmp", "call") or m.startswith("j") or m.startswith("loop") or m == "jecxz"
    for op in ins.operands:
        vals = []
        if op.type == X86_OP_IMM:
            vals.append(op.imm)
        elif op.type == X86_OP_MEM and op.mem.disp:
            vals.append(op.mem.disp)
        for v in vals:
            # immediate: file-coord target (code refs); mem disp: runtime-CS coord.
            is_disp = (op.type == X86_OP_MEM)
            target = v - 0x100 if is_disp and v >= 0x100 else v
            if not is_disp:
                target = v
            if 0 <= target < END:
                if target == 0 and not is_branch:
                    continue
                xrefs[target].append((va, m if is_branch else "data"))

int_sites = {}
port_sites = []
for va, ins in code.items():
    if ins is None: continue
    if ins.mnemonic == "int" and ins.operands and ins.operands[0].type == X86_OP_IMM:
        int_sites[va] = ins.operands[0].imm
    if ins.mnemonic in ("in", "out") or ins.mnemonic.startswith("ins") or ins.mnemonic.startswith("outs"):
        p = None
        for op in ins.operands:
            if op.type == X86_OP_IMM:
                p = op.imm
            elif op.type == X86_OP_REG:
                p = "DX"
        port_sites.append((va, ins.mnemonic, p, ins.op_str))

def annotate(ins):
    c = []
    m = ins.mnemonic
    for op in ins.operands:
        v = None
        if op.type == X86_OP_IMM: v = op.imm
        elif op.type == X86_OP_MEM: v = op.mem.disp or None
        if v is None: continue
        if m == "int" and op.type == X86_OP_IMM:
            c.append("-> " + INT_NAMES.get(v, "int %02Xh" % v))
            continue
        if op.type == X86_OP_IMM:
            f = v
            if f in KNOWN_RUNTIME:     # immediate = runtime-CS coord, e.g. pushed CS:0x66FB
                c.append("cs:" + KNOWN_RUNTIME[f])
            s = string_at_file(f)
            if s and s[0] < 4:
                c.append('"%s"' % s[1])
            continue
        # memory displacement: runtime CS coord -> file = v-0x100 (if in image)
        cs_v = v
        if cs_v in KNOWN_RUNTIME:
            c.append("[" + KNOWN_RUNTIME[cs_v].replace("cs:", "") + "]")
        f = cs_v - 0x100
        if BSS_CS_LO <= cs_v < BSS_CS_HI:
            c.append("bss+%04X(cs)/file%04X" % (cs_v, cs_v - 0x100))
            continue
        if 0 <= f < END:
            s = string_at_file(f)
            if s and s[0] < 4:
                c.append('"%s"' % s[1])
            elif cs_v >= 0x100 and cs_v < CS_RUNTIME_TOP:
                pass  # plain image data; keep listing lean
    return ("  ; " + "; ".join(dict.fromkeys(c))) if c else ""

def region_note(lo, hi):
    r = []
    for blo, bhi, role in BLOBS:
        if lo < bhi and hi > blo:
            r.append("blob:%04X-%04X(%s)" % (blo, bhi, role.split(" (")[0]))
    if DHKC_MOD and lo <= DHKC_MOD < hi:
        r.append("DHKC module (file %04X)" % DHKC_MOD)
    return ", ".join(r)

# ------------------------------------------------------------------ listing
LABEL = lambda va: ("sub_%04X" if va in funcs else "loc_%04X") % va

lines = []
add = lines.append
add("; plpbt.bin  -- 16-bit real-mode boot image.  Addressing model v3 (VERIFIED, DF s6.1):")
add(";   * image loads at CS:0x100  =>  CS offset X == file offset X-0x100")
add(";   * loader CS=0x3000 (self-check file 0x0D39);  raw entry file 0x8BE == CS:0x9BE")
add(";   * ALL memory displacements in the code below are RUNTIME-CS offsets.")
add(";     file offset = cs-offset - 0x100.  BSS cs 0xAB3B..0xF8CF (file 0xAA3B..)")
add(";   * int13 blob modules are position-independent: EB <skip> <len16> headers,")
add(";     copied to hookseg:0x100 by sub_8442 (cx=[si+2]); blob-local offsets == file")
add(";   * code from recursive descent (roots: entry + blobs + PoLP dispatchers);")
add(";     gap regions marked 'linear sweep'")
add("")
add("; blob modules in image:")
for blo, bhi, role in BLOBS:
    add(";   file %04X..%04X (%d bytes)  -- %s" % (blo, bhi-1, bhi-blo, role))
if DHKC_MOD:
    add(";   'DHKC' module magic at file %04X (companion installed driver)" % DHKC_MOD)
add("; image 0..0x%04X  runtime CS 0x100..0x%04X;  BSS CS 0xAB3B..0xF8CF" % (END-1, CS_RUNTIME_TOP-1))
add("")

sweep_starts = {o for o, _ in sweep_regions}
vas = sorted(a for a, ins in code.items() if ins is not None)
for va in vas:
    ins = code[va]
    if va in sweep_starts:
        region = next(r for r in sweep_regions if r[0] == va)
        note = region_note(*region)
        add("")
        add("; ============ linear sweep region: file 0x%04X..0x%04X (len %d, not statically reached)%s ============"
            % (region[0], region[1], region[1]-region[0], ("  ["+note+"]") if note else ""))
        add("")
    if va in funcs:
        xr = xrefs.get(va, [])
        add("")
        add("; ----------------------------------------------------------------")
        add("; %s (file 0x%04X, runtime cs 0x%04X):%s" % (LABEL(va), va, va+0x100,
            ("  (xrefs: %s)" % ", ".join("%04X" % s for s, _ in xr)) if xr else ""))
    b = data[va:va+ins.size]
    add("%04X  %-20s %-9s %-40s%s" % (va, b.hex(), ins.mnemonic, ins.op_str, annotate(ins)))

open(os.path.join(OUT, "disasm_full.asm"), "w", encoding="utf-8").write("\n".join(lines))

# ------------------------------------------------------------------ ports.txt
pl = ["port I/O sites (in/out), whole image (file offsets; runtime cs = +0x100):"]
by_port = collections.defaultdict(list)
for va, m, p, ops in port_sites:
    key = p if p is None or p == "DX" else ("0x%02X" % p)
    by_port[key].append((va, m))
for key in sorted(by_port, key=lambda k: (k == "DX", str(k))):
    sites = by_port[key]
    name = PORT_NAMES.get(int(key, 16), "") if key and key != "DX" else "(dynamic: dx register)"
    pl.append("  %-8s %-28s n=%-4d sites: %s" % (key, name, len(sites),
              ", ".join("%s@%04X" % (m, va) for va, m in sites)))
open(os.path.join(OUT, "ports.txt"), "w", encoding="utf-8").write("\n".join(pl))

# ------------------------------------------------------------------ strings.txt
sl = ["%-6s %-6s %s" % ("file", "cs", "string")]
for s, t in strings:
    xr = xrefs.get(s, [])
    sl.append("%06X  %06X %-52s xrefs:%s" % (s, s+0x100, t[:52],
              ",".join("%04X" % x for x, _ in xr)))
open(os.path.join(OUT, "strings.txt"), "w", encoding="utf-8").write("\n".join(sl))

# ------------------------------------------------------------------ functions.txt
order = sorted(f for f in funcs if f in code)
fl = ["call/entry targets (%d) - file coords (runtime cs = +0x%X):" % (len(order), 0x100)]
for f in order:
    xr = [s for s, k in xrefs.get(f, []) if k == "call"]
    a, end = f, None
    while 0 <= a < END and a in code and code[a] is not None:
        if a in funcs and a != f: break
        mm = code[a].mnemonic
        if mm in ("ret", "retf", "iret", "jmp", "hlt"):
            end = a; break
        a += code[a].size
    bl = blob_of(f)
    fl.append("sub_%04X (cs %04X)  end~%s  callsites=%d (%s)%s" % (
        f, f+0x100, ("%04X" % end) if end else "?", len(xr),
        ",".join("%04X" % x for x in xr[:12]), ("  [%s]" % bl.split(" (")[0]) if bl else ""))
fl.append("")
fl.append("indirect branch/call sites (%d): %s" % (len(indirect_sites),
          ", ".join("%04X" % a for a in indirect_sites)))
fl.append("")
fl.append("int sites:")
for va, v in sorted(int_sites.items()):
    fl.append("  %04X (cs %04X): int %02Xh  %s" % (va, va+0x100, v, INT_NAMES.get(v, "")))
open(os.path.join(OUT, "functions.txt"), "w", encoding="utf-8").write("\n".join(fl))

# ------------------------------------------------------------------ stats
ncode = sum(ins.size for ins in code.values() if ins)
st = []
st.append("image: %d bytes (file 0x%X); runtime CS 0x100..0x%X; BSS CS 0xAB3B..0xF8CF"
          % (len(data), len(data), CS_RUNTIME_TOP-1))
st.append("model: file offset + 0x100 == runtime CS offset (verified, DF s6.1)")
st.append("recursive-descent code: %d insns; +linear sweep regions: %d (bytes %d)" %
          (sum(1 for a, i in code.items() if i and a not in swept), len(sweep_regions),
           sum(j-o for o, j in sweep_regions)))
st.append("total code bytes after sweep: %d (%.1f%%)" % (ncode, 100.0*ncode/len(data)))
st.append("functions: %d, indirect sites: %d" % (len(order), len(indirect_sites)))
st.append("blob modules: " + "; ".join("%04X-%04X %dB %s" % (lo, hi-1, hi-lo, r.split(" (")[0]) for lo, hi, r in BLOBS))
st.append("")
st.append("sweep regions:")
for o, j in sweep_regions:
    note = region_note(o, j)
    st.append("  0x%04X..0x%04X len=%d%s head: %s" % (o, j, j-o,
              ("  [%s]" % note) if note else "", data[o:o+12].hex()))
st.append("")
st.append("port I/O summary -> out/ports.txt")
open(os.path.join(OUT, "stats.txt"), "w", encoding="utf-8").write("\n".join(st))
print("\n".join(st[:8]))
print("wrote out/disasm_full.asm, ports.txt, strings.txt, functions.txt, stats.txt")
