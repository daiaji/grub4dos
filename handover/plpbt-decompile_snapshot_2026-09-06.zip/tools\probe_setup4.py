#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Natural Setup-entry identification: the guest runs its normal menu loop;
at each sample the probe pokes [0xC126]=row and queues a genuine ENTER,
then watches the window flags for the Setup menu (0xB7A4) / editor (0xBA17).
Once the Setup row is found, a clean-key verification run walks DOWN to it
and ENTERs - no far_call anywhere."""
import os, sys, struct
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bootlab
from bootlab import Plop

M = {
    0x6BA3: "SETUP MENU OPENER",
    0x7B45: "EDITOR OPENER",
    0x7CC1: "bootflag 'b'",
    0x71B2: "CopyTo open 's'",
    0x71D4: "copy perform 'p'",
}
counts, phases = {}, []
def extra_milestones(uc, cs_off):
    if cs_off in M and cs_off not in counts:
        counts[cs_off] = 0
        phases.append((p.ticks_fired, M[cs_off]))
        print("[milestone] %s @tick %d" % (M[cs_off], p.ticks_fired), flush=True)

def d8(o):  return p.uc.mem_read(p.base + o, 1)[0]
def w8(o, v): p.uc.mem_write(p.base + o, bytes([v]))
def push(w): p.bios.key_push(w)

def vis():
    out = set()
    for i in range(26):
        desc = struct.unpack('<H', bytes(p.uc.mem_read(p.base + 0xA825 + i*2, 2)))[0]
        if 0x1000 < desc < 0xC000 and (d8(desc) & 1):
            out.add(desc)
    return out

step = [0]
st = ["settle"]        # settle -> probe(row) -> watch -> next -> verify
row = [1]
res = []
watch_n = [0]
ver = [os.environ.get("SETUP4_VERIFY") == "1"]
ver_row = [int(os.environ.get("SETUP4_ROW", "0"))]

def sample():
    step[0] += 1
    if st[0] == "done":
        return
    cs = p.uc.reg_read(bootlab.X86_REG_CS)
    if cs != 0x3000:
        print("!! cs left image (%04X) at row %d" % (cs, row[0]), flush=True)
        res.append((row[0], 'left-image'))
        st[0] = "done"
        return
    v = vis()
    if st[0] == "settle":
        if p.ticks_fired > 350 and d8(0xC127):
            row[0] = 1
            st[0] = "probe"
        return
    if st[0] == "probe":
        if row[0] > d8(0xC127):
            st[0] = "done"
            print("SCAN DONE:", res, flush=True)
            return
        w8(0xC126, row[0])
        push(0x1C0D)                       # genuine ENTER
        watch_n[0] = 0
        st[0] = "watch"
        return
    if st[0] == "watch":
        watch_n[0] += 1
        new = v - {0xB732, 0xB76B}
        if new:
            print("row %d OPENS windows: %s" %
                  (row[0], sorted(hex(x) for x in new)), flush=True)
            res.append((row[0], 'opens:%s' % sorted(hex(x) for x in new)))
            push(0x011B)
            row[0] += 1
            st[0] = "probe"
            return
        if watch_n[0] > 25:
            res.append((row[0], 'nothing'))
            row[0] += 1
            st[0] = "probe"
        return

_n2 = [0]
def extra2(uc, cs_off):
    extra_milestones(uc, cs_off)
    _n2[0] += 1
    if _n2[0] >= 400_000:
        _n2[0] = 0
        sample()

p = Plop(tick_insns=200_000, feed_watchdog=True, hook_extra=extra2,
         max_insns=400_000_000)
p.bios.disk_attach(bootlab.default_disk())
p.uc.hook_add(bootlab.UC_HOOK_CODE, lambda uc, a, s, ud: (
    uc.reg_write(bootlab.X86_REG_CS, 0x3000),
    uc.reg_write(bootlab.X86_REG_IP, 0x0DA2),
    uc.reg_write(bootlab.X86_REG_SP, 0xFFFE)) and None,
    begin=0, end=0x400)
r = p.run()
print("run:", r)
print("attempts:", res)
print("milestones:", phases)
print("counts:", {hex(k): v for k, v in counts.items()})
