#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Setup navigator v3: bottom-up row probing with window-flag feedback.
Menu: [0xC126]=1-based selection (wraps 1..8), arrows inc/dec.
ENTER on a device row boots - so probe special rows bottom-up:
row 8 (About?), row 7 (Setup?)... until the 0xBA17 window activates.
In Setup: 'b' per row (bootflag, 0x7CC1), then 's'/'p' attempts,
ENTER to open the edit screen, 's'/'p' there too (CopyTo 0x71B2/0x71D4)."""
import os, sys, struct
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bootlab
from bootlab import Plop

M = {
    0x7CC1: "bootflag 'b' (0x7BC1)",
    0x7CE7: "logical 'l' (0x7BE7)",
    0x7C74: "'d' key (0x7B72)",
    0x71B2: "CopyTo open 's' (0x70B2)",
    0x71D4: "copy perform 'p' (0x70D3)",
    0x6738: "watchdog LJMP 0:0 !!",
}
counts, phases = {}, []
def extra(uc, cs_off):
    if cs_off in M:
        if cs_off not in counts:
            counts[cs_off] = 0
            phases.append((p.ticks_fired, M[cs_off]))
            print("[milestone] %s @tick %d" % (M[cs_off], p.ticks_fired), flush=True)
        counts[cs_off] += 1

def d8(off):  return p.uc.mem_read(p.base + off, 1)[0]
def push(w):  p.bios.key_push(w)

# window table 0xA825: 26 WORD desc pointers; flag byte lives at desc+0
WT = 0xA825
def vis_windows():
    out = {}
    for i in range(26):
        desc = struct.unpack("<H", bytes(p.uc.mem_read(p.base + WT + i*2, 2)))[0]
        if not (0x1000 < desc < 0xC000):
            continue
        flg = p.uc.mem_read(p.base + desc, 1)[0]     # cs-relative: no -0x100
        if flg & 1:
            out[desc] = flg
    return out
prev_vis = [None]

_n = [0]
step = [0]
st = ["sweep"]
setupmenu_done = [False]
forced_edit = [False]
probe_row = [8]
sel_target = [1]

SCAN = {'a':0x1E,'b':0x30,'c':0x2E,'d':0x20,'e':0x12,'f':0x21,'g':0x22,'h':0x23,
        'i':0x17,'j':0x24,'k':0x25,'l':0x26,'m':0x32,'n':0x31,'o':0x18,'p':0x19,
        'q':0x10,'r':0x13,'s':0x1F,'t':0x14,'u':0x16,'v':0x2F,'w':0x11,'x':0x2D,
        'y':0x15,'z':0x2C}
def sample():
    step[0] += 1
    sel = d8(0xC126)
    main = d8(0xB732); setup = d8(0xBA17); copydlg = d8(0xB8C1)
    vis = vis_windows()
    newwins = {k: v for k, v in vis.items() if prev_vis[0] is None or k not in prev_vis[0]}
    prev_vis[0] = vis
    print("[st %02d] tick=%d sel=%d state=%s vis=%s%s wdt=%d svc=%d hook=%d irq0=%d" %
          (step[0], p.ticks_fired, sel, st[0],
           {hex(k): hex(v) for k, v in vis.items()},
           " NEW:%s" % {hex(k): hex(v) for k, v in newwins.items()} if newwins else "",
           d8(0xB6E8), p.bios.in_service, p.in_hook, p.in_irq0),
          flush=True)
    setup = vis.get(0xBA17, 0)
    main = vis.get(0xB732, 0)
    copydlg = vis.get(0xB8C1, 0)

    # Setup menu opener (file 0x6AA3) has no static caller - invoke it
    # directly from the harness once, then drive the menu with real keys.
    if st[0] == "sweep":
        if not setupmenu_done[0]:
            setupmenu_done[0] = True
            print(">>> forcing Setup menu opener (far_call 0x3000:0x6BA3) <<<",
                  flush=True)
            p.bios.far_call(0x3000, 0x6BA3)    # file 0x6AA3, draws window 0xB7A4
            st[0] = "setupmenu"
            return
        st[0] = "setupmenu"
    if st[0] == "setupmenu":
        if d8(0xBA17) & 1 or True:
            # the 'edit profile' screen loop (file 0x7A45) is dispatched
            # indirectly and its opener was not identified; drive it directly:
            # queue real 'b' keystrokes then run its key loop via far_call -
            # the loop consumes the queued keys and the 'b' branch calls
            # sub_7BC1 (bootflag write) with our genuine keypresses.
            if not forced_edit[0]:
                forced_edit[0] = True
                print(">>> driving edit-profile loop (far_call 0x3000:0x7B45) "
                      "with queued 'b' keys <<<", flush=True)
                for _ in range(3):
                    push((0x1F << 8) | ord("b"))
                push(0x011B)                    # esc ends the screen loop
                p.bios.far_call(0x3000, 0x7B45)
                print(">>> edit-profile loop returned <<<", flush=True)
                st[0] = "done"
                return
        if d8(0xB84F) & 1 or d8(0xB888) & 1:
            # partition menu dialog opened on this row: close it, move on
            push(0x011B)
            push(0x011B)
            push(0x5000)
            return
        f = d8(0xB7A4)
        if f == 0:
            print(">>> setup menu window gone; re-forcing <<<", flush=True)
            setupmenu_done[0] = False
            st[0] = "sweep"
            return
        # descend the Setup menu and ENTER rows until the profile editor opens
        k = step[0] % 2
        if k == 0:
            push(0x5000)                       # down
        else:
            push(0x1C0D)                       # enter row
        return
    if st[0] == "done":
        return
    if st[0] == "insetup":
        if not (d8(0xBA17) & 1):
            print(">>> editor closed; back to setup menu <<<", flush=True)
            st[0] = "setupmenu"
            return
        k = step[0] % 3
        if k == 0:   push(0x5000)                       # down: next row
        elif k == 1: push((0x1F << 8) | ord("b"))       # bootflag
        else:        push(0x011B)                       # esc

def extra2(uc, cs_off):
    extra(uc, cs_off)
    _n[0] += 1
    if _n[0] >= 2_000_000:
        _n[0] = 0
        if p.ticks_fired > 120:
            sample()

p = Plop(keys="", edd="ATA", tick_insns=200_000, feed_watchdog=True,
         hook_extra=extra2, max_insns=300_000_000)
p.bios.disk_attach(bootlab.default_disk())

# recovery: a null far-call lands at 0000:0000 (IVT area) - bounce back to
# the main-menu loop instead of wandering into unhooked hlt
def nullcall_cb(uc, addr, size, ud):
    print(">>> NULL CALL at %04X:%04X - recovering to menu loop <<<" %
          (uc.reg_read(bootlab.X86_REG_CS), uc.reg_read(bootlab.X86_REG_IP)),
          flush=True)
    uc.reg_write(bootlab.X86_REG_CS, 0x5000)
    uc.reg_write(bootlab.X86_REG_SS, 0x5000)
    uc.reg_write(bootlab.X86_REG_IP, 0x0DA2)   # menu loop (file 0x0CA2)
    uc.reg_write(bootlab.X86_REG_SP, 0xFFFE)
    st[0] = "down"; sel_target[0] = 1
p.uc.hook_add(bootlab.UC_HOOK_CODE, nullcall_cb, begin=0, end=0x400)
r = p.run()
u = p.uc
print("run:", r, flush=True)
print("final CS:IP=%04X:%04X AX=%04X SP=%04X" %
      (u.reg_read(bootlab.X86_REG_CS), u.reg_read(bootlab.X86_REG_IP),
       u.reg_read(bootlab.X86_REG_AX), u.reg_read(bootlab.X86_REG_SP)), flush=True)
print("milestones:", phases, flush=True)
print("counts:", {hex(k): v for k, v in counts.items()}, flush=True)