#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Dump the EHCI async-list QH/qTD structures the Plop EHCI module builds
after the PCI/register stubs light up the 0x9902 path.  ASYNCLISTADDR is
read back from the virtual EHCI op registers (BAR 0x10000000 + 0x10 + 0x18)."""
import os, sys, struct
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bootlab
from bootlab import Plop

BAR = 0x10000000
p = Plop(keys='u', edd='USBD', tick_insns=200_000, feed_watchdog=True,
         max_insns=400_000_000)
p.bios.disk_attach(bootlab.default_disk())
r = p.run()
print('run:', r)
ints = p.bios.int_trace
print('MAGIC:', [hex(t[1]) for t in ints if t[0] == 0x13 and (t[1] & 0xFF00) in (0x9900, 0x6F00, 0x4954)])

reg = bytes(p.uc.mem_read(BAR + 0x10, 0x30))
print('EHCI op regs:', reg.hex(' '))
asynclist = struct.unpack('<I', reg[0x18:0x1C])[0]   # ASYNCLISTADDR @ op+0x18
print('ASYNCLISTADDR = %08X' % asynclist)
if asynclist:
    print('--- QH chain (async list) ---')
    q = asynclist
    for depth in range(8):
        d = struct.unpack('<8I', bytes(p.uc.mem_read(q, 0x20)))
        print('QH@%08X h=%08X ep=%08X cap=%08X cur=%08X n=%08X alt=%08X tok=%08X b0=%08X'
              % (q, d[0], d[1], d[2], d[3], d[4], d[5], d[6], d[7]))
        t = d[4]
        if t:
            td = struct.unpack('<8I', bytes(p.uc.mem_read(t, 0x20)))
            print('  qTD@%08X n=%08X alt=%08X tok=%08X b0=%08X b1=%08X b2=%08X b3=%08X b4=%08X'
                  % (t, td[0], td[1], td[2], td[3], td[4], td[5], td[6], td[7]))
        q = d[0] & ~0x1F
        if q == asynclist or q == 0:
            break

# driver data segment es=[0x2b9a] (hookseg-relative), base [0x2b96]
es = int.from_bytes(bytes(p.uc.mem_read(p.base + 0x2B9A, 2)), 'little')
print('driver ES=%04X' % es)
print('ES:0000..:', bytes(p.uc.mem_read(es * 16, 0x20)).hex(' '))
print('ES:0080..:', bytes(p.uc.mem_read(es * 16 + 0x80, 0x40)).hex(' '))
print('[CF43]=%d [CF44]=%d' % (
    int.from_bytes(bytes(p.uc.mem_read(p.base + 0xCF43, 2)), 'little'),
    int.from_bytes(bytes(p.uc.mem_read(p.base + 0xCF44, 2)), 'little')))
