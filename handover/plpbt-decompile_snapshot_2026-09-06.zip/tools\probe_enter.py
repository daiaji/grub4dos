import sys, struct
import bootlab, unicorn
from unicorn.x86_const import *
_xc = __import__('unicorn.x86_const', fromlist=['x'])
for _n in dir(_xc):
    if _n.startswith('UC_X86_REG_'):
        globals()[_n[3:]] = getattr(_xc, _n)

p = bootlab.Plop(load_seg=0x7C00, entry=0x8BE)
disk = bytearray(8 * 1024 * 1024)
mbr = bytearray(512); mbr[446] = 0x80; mbr[450] = 0x06
mbr[454:458] = struct.pack('<I', 63); mbr[458:462] = struct.pack('<I', 1022)
mbr[510:512] = b'\x55\xaa'
disk[0:512] = mbr
pbs = bytearray(512); pbs[0] = 0xEA; pbs[510:512] = b'\x55\xaa'
disk[63*512:63*512+512] = pbs
p.bios.disk_attach(bytes(disk))

uc = p.uc
base = 0x7C000
log = []
def at663e(u, addr, size, ud):
    edi = u.reg_read(X86_REG_EDI)
    eax = u.reg_read(X86_REG_EAX)
    # return address: the call pushed CS:IP -> top of stack (16-bit: ip then cs)
    sp = u.reg_read(X86_REG_SP)
    ss = u.reg_read(X86_REG_SS)
    ipr, csr = struct.unpack('<HH', bytes(u.mem_read((ss << 4) + sp, 4)))
    log.append(('enter663e', edi, eax, csr, ipr))
def at6621(u, addr, size, ud):
    # call bp : log target and args
    bp = u.reg_read(X86_REG_BP)
    sp = u.reg_read(X86_REG_SP)
    ss = u.reg_read(X86_REG_SS)
    log.append(('call_bp', u.reg_read(X86_REG_EDI), u.reg_read(X86_REG_EAX), u.reg_read(X86_REG_CS), bp))
uc.hook_add(unicorn.UC_HOOK_CODE, at663e, begin=base + 0x663E, end=base + 0x663E)
uc.hook_add(unicorn.UC_HOOK_CODE, at6621, begin=base + 0x6621, end=base + 0x6621)
r = p.run()
print('run:', r[:60])
print('--- events:')
for e in log:
    if e[0] == 'enter663e':
        print('  enter 0x663E: edi=%08X eax=%08X  caller=%04X:%04X' % (e[1], e[2], e[3], e[4]))
    else:
        print('  call bp (in int hndlr): edi=%08X eax=%08X  bp target=%04X' % (e[1], e[2], e[4]))