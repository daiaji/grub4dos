#!/usr/bin/env python3
"""With loader-preset: does boot reach a stable menu poll (repeated int16h)?
Dump the offscreen framebuffer the menu draws to (fs:[edi], [0xab6a]..)."""
import sys, os, struct
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from unicorn import *
from unicorn.x86_const import *
from bootlab import Plop
_xc = sys.modules['unicorn.x86_const']
for _n in dir(_xc):
    if _n.startswith('UC_X86_REG_'):
        globals()[_n[3:]] = getattr(_xc, _n)

def build_disk():
    disk = bytearray(8*1024*1024)
    mbr = bytearray(512); mbr[446]=0x80; mbr[447:450]=bytes([0,1,1]); mbr[450]=0x06
    mbr[451:454]=bytes([15,63,63]); mbr[454:458]=struct.pack('<I',63); mbr[458:462]=struct.pack('<I',1022)
    mbr[510:512]=b'\x55\xAA'; disk[0:512]=mbr
    pbs=bytearray(512); pbs[510:512]=b'\x55\xAA'; disk[63*512:64*512]=pbs
    return bytes(disk)

p = Plop(load_seg=0x7C00, entry=0x8BE, edd_type='ATA', max_insns=80_000_000)
p.bios.disk_attach(build_disk())
base = 0x7C00<<4
W,H = 80*8, 25*8
desc = bytearray(0x25)
struct.pack_into('<I', desc, 0x00, 0x2320)
struct.pack_into('<H', desc, 0x14, W)
desc[0x18]=1
struct.pack_into('<H', desc, 0x19, W)
struct.pack_into('<H', desc, 0x1D, H)
struct.pack_into('<H', desc, 0x1F, W)
struct.pack_into('<H', desc, 0x21, H)
p.uc.mem_write(base+0x9A26, bytes(desc))
p.uc.mem_write(base+0xB732, bytes(bytearray(0x39)))
desc2 = bytearray(0x25)
struct.pack_into('<I', desc2, 0x00, 0x1000)
struct.pack_into('<H', desc2, 0x14, W)
desc2[0x18]=1
struct.pack_into('<H', desc2, 0x19, W)
struct.pack_into('<H', desc2, 0x1D, H)
struct.pack_into('<H', desc2, 0x1F, W)
struct.pack_into('<H', desc2, 0x21, H)
p.uc.mem_write(base+0x9A4B, bytes(desc2))
p.uc.mem_write(base+0xB76B, bytes(bytearray(0x39)))

int16s=[0]
def code(uc, addr, size, ud):
    off=addr-base
    if off in (0x172E,0x6317,0x833D,0x12C0,0x1278,0x1271):
        int16s[0]+=1
p.uc.hook_add(UC_HOOK_CODE, code)
r=p.run()
print('run:', r[:120])
print('menu-key-poll hits at known poll sites:', int16s[0])
# dump offscreen buffer: menu drawn at [0xab6a] linear (fs base 0 -> linear == edi)
ab6a = struct.unpack('<I', bytes(p.uc.mem_read(base+0xAB6A,4)))[0]
print('[0xab6a] offscreen base = 0x%X' % ab6a)
if ab6a and ab6a < 0x8000000:
    fb = bytes(p.uc.mem_read(ab6a, 80*25*2))
    # render 80x25 (each cell: 2 bytes char+attr in text canvas, but here offscreen may be char only)
    lines=[]
    for r0 in range(25):
        row=fb[r0*160:(r0+1)*160]
        txt=''.join(chr(c) if 32<=c<127 else '.' for c in row[0::2])
        lines.append(txt.rstrip('.'))
    print('--- offscreen buffer as text (80x25) ---')
    print('\n'.join(lines).rstrip())
print()
print('int16 trace tail:')
n16=[(n,ax) for (n,ax,bx,cx,dx,si,di,cs,ip) in p.bios.int_trace if n==0x16]
print('  count', len(n16), 'tail', n16[-10:])
