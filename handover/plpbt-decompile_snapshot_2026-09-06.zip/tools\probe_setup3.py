#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Natural Setup-entry probe: find the key path that opens the Setup menu
and the 'edit profile' screen WITHOUT any far_call forcing.

Key facts from the static decode (runtime cs = file+0x100):
- menu keys: UP 0x4800 ([C126]--), DOWN 0x5000 ([C126]++, wraps 1..[C127]),
  ENTER 0x1C0D dispatches table[[C128] + 2*([C126]-1)] -> call [C133].
- window flag bytes (vis bits): 0xB732 main list, 0xB7A4 Setup menu,
  0xBA17 edit-profile screen, 0xB8C1 copy dialog, 0xB84F/0xB888 dialogs.

Strategy: first try a plain 's' keystroke; then adaptive row probing -
walk [C126] to the target row (last rows first, they are the menu rows),
ENTER, and watch the window flags.  A boot hijack (row was a device) is
recovered and the next row down-count is tried.  When the Setup menu
appears, descend it with DOWN/ENTER until the editor opens, then run the
'b'/'s'/'p' tool chain with genuine keys only.
"""
import os, sys, struct
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bootlab
from bootlab import Plop

M = {
    0x6BA3: "SETUP MENU OPENER (0x6AA3)",
    0x7B45: "EDITOR OPENER (0x7A45)",
    0x7CC1: "bootflag 'b'",
    0x71B2: "CopyTo open 's'",
    0x71D4: "copy perform 'p'",
}
counts, phases = {}, []
def extra(uc, cs_off):
    if cs_off in M:
        if cs_off not in counts:
            counts[cs_off] = 0
            phases.append((p.ticks_fired, M[cs_off]))
            print("[milestone] %s @tick %d" % (M[cs_off], p.ticks_fired), flush=True)
        counts[cs_off] += 1

def d8(off):  return p.uc.mem_read(p.base + off, 1)[0]
def push(w):  p.bios.key_push(w)

WT = 0xA825
def vis_windows():
    out = {}
    for i in range(26):
        desc = struct.unpack("<H", bytes(p.uc.mem_read(p.base + WT + i*2, 2)))[0]
        if not (0x1000 < desc < 0xC000):
            continue
        flg = p.uc.mem_read(p.base + desc, 1)[0]
        if flg & 1:
            out[desc] = flg
    return out

step = [0]
st = ["s"]                 # 's' -> 'rows' -> 'enter' -> 'watch' -> 'menu' -> 'editor' -> 'done'
target = [None]            # row being probed (None = try 's' first)
booted = [0]
tried = []
boot_flag = [False]

def recover(cs, ip, why):
    print(">>> RECOVER (%s) from %04X:%04X <<<" % (why, cs, ip), flush=True)
    booted[0] += 1
    p.bios.far_call_ready = True
    uc = p.uc
    uc.reg_write(bootlab.X86_REG_CS, 0x3000)
    uc.reg_write(bootlab.X86_REG_SS, 0x3000)
    uc.reg_write(bootlab.X86_REG_IP, 0x0DA2)   # main menu loop (file 0x0CA2)
    uc.reg_write(bootlab.X86_REG_SP, 0xFFFE)
    if st[0] in ("watch", "enter"):
        print(">>> row %d boots - marking, next target <<<" % target[0], flush=True)
        tried.append((target[0], 'boot'))
        target[0] = target[0] - 1 if target[0] and target[0] > 4 else None
        st[0] = "rows" if target[0] else "done"
    else:
        st[0] = "done"

def nullcall_cb(uc, addr, size, ud):
    recover(uc.reg_read(bootlab.X86_REG_CS), uc.reg_read(bootlab.X86_REG_IP),
            "null-call/boot stub")

def sample():
    step[0] += 1
    sel = d8(0xC126); cnt = d8(0xC127)
    vis = vis_windows()
    setup = vis.get(0xB7A4, 0); editor = vis.get(0xBA17, 0)
    copydlg = vis.get(0xB8C1, 0)
    print("[st %02d %s] tick=%d sel=%d/%d vis=%s" %
          (step[0], st[0], p.ticks_fired, sel, cnt,
           {hex(k): hex(v) for k, v in vis.items()}), flush=True)

    if st[0] == "done":
        return
    # boot hijack signature: CS left the image (0x3000) or main window gone
    cs = p.uc.reg_read(bootlab.X86_REG_CS)
    if cs != 0x3000 and st[0] != "s":
        recover(cs, p.uc.reg_read(bootlab.X86_REG_IP), "cs left image")
        return
    if copydlg:
        push(0x011B); push(0x011B)
        return
    if st[0] == "s":
        # one 's' keystroke attempt was queued via constructor; if the setup
        # menu did not appear, move on to row probing
        if p.ticks_fired > 400 and not setup:
            print(">>> 's' did not open Setup; switching to row probing <<<", flush=True)
            tried.append(('key s', 'no'))
            target[0] = None
            st[0] = "rows"
        return
    if st[0] == "rows":
        cnt2 = d8(0xC127)
        if not target[0]:
            target[0] = cnt2                      # last row first
            print(">>> probing last row %d <<<" % cnt2, flush=True)
        if sel != target[0]:
            push(0x5000)                          # down towards target
        else:
            print(">>> ENTER on row %d <<<" % sel, flush=True)
            push(0x1C0D)
            st[0] = "watch"
        return
    if st[0] == "watch":
        if setup or editor:
            print(">>> NATURAL ENTRY FOUND via row %d <<<" % target[0], flush=True)
            tried.append((target[0], 'opens'))
            st[0] = "menu"
            return
        if p.ticks_fired > 900 and not (setup or editor):
            # nothing opened: either a dialog consumed it or dead row
            print(">>> row %d: nothing opened <<<" % target[0], flush=True)
            tried.append((target[0], 'nothing'))
            push(0x011B)
            target[0] = target[0] - 1 if target[0] > 4 else None
            st[0] = "rows" if target[0] else "done"
        return
    if st[0] == "menu":
        if editor:
            st[0] = "editor"
            return
        if not setup:
            st[0] = "done"
            return
        k = step[0] % 2
        if k == 0: push(0x5000)                   # down the Setup menu
        else:      push(0x1C0D)                   # enter row
        return
    if st[0] == "editor":
        if not editor:
            print(">>> editor closed; setup tools done <<<", flush=True)
            st[0] = "menu"
            return
        k = step[0] % 4
        if k == 0:   push(0x5000)                     # next row
        elif k == 1: push((0x1F << 8) | ord("b"))     # bootflag
        elif k == 2: push((0x1F << 8) | ord("s"))     # CopyTo open
        else:        push((0x1F << 8) | ord("p"))     # copy perform

_n2 = [0]
def extra2(uc, cs_off):
    extra(uc, cs_off)
    _n2[0] += 1
    if p.ticks_fired > 120 and _n2[0] >= 500_000:
        _n2[0] = 0
        sample()

p = Plop(keys="s", edd="ATA", tick_insns=200_000, feed_watchdog=True,
         hook_extra=extra2, max_insns=300_000_000)
p.bios.disk_attach(bootlab.default_disk())
p.uc.hook_add(bootlab.UC_HOOK_CODE, nullcall_cb, begin=0, end=0x400)

r = p.run()
u = p.uc
print("run:", r, flush=True)
print("final CS:IP=%04X:%04X" %
      (u.reg_read(bootlab.X86_REG_CS), u.reg_read(bootlab.X86_REG_IP)), flush=True)
print("attempts:", tried, flush=True)
print("milestones:", phases, flush=True)
print("counts:", {hex(k): v for k, v in counts.items()}, flush=True)
