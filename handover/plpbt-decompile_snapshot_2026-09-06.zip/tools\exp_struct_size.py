import sys, struct
import bootlab

SIZE = int(sys.argv[1], 0) if len(sys.argv) > 1 else 0x2320
p = bootlab.Plop(load_seg=0x7C00, entry=0x8BE, alloc_size=SIZE)

disk = bytearray(8 * 1024 * 1024)
mbr = bytearray(512); mbr[446] = 0x80; mbr[450] = 0x06
mbr[454:458] = struct.pack('<I', 63); mbr[458:462] = struct.pack('<I', 1022)
mbr[510:512] = b'\x55\xaa'
disk[0:512] = mbr
pbs = bytearray(512); pbs[0] = 0xEA; pbs[510:512] = b'\x55\xaa'
disk[63*512:63*512+512] = pbs
p.bios.disk_attach(bytes(disk))

r = p.run()
print('run:', r[:110])
print('screen:', repr(p.dump_screen()[:300]))
print('ints:', len(p.bios.int_trace))
for i, e in enumerate(p.bios.int_trace[-12:]):
    print('  %d int %02Xh from %04X:%04X ax=%04X dx=%04X' % (len(p.bios.int_trace)-12+i, e[0], e[7], e[8], e[1], e[4]))