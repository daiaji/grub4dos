#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Digital-boot probe: press '1' and trace the profile path.
Milestones are RUNTIME-CS offsets (file = cs - 0x100; raw mode, base CS=0x3000
=> linear = img_base + cs_off ... bootlab hook passes cs_off already).
Hooks:
  0x0CE7 '1'-'9' dispatch in main loop
  0x1839 sub_1839 (digit boot entry)
  0x7CB2 sub_7CB2 (load per-device profile records)
  0x1A5A profile sector read (AH=02 LBA1) / 0x1A76 boot jump
Then dump the profile tables + screen."""
import os, sys, struct
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bootlab
from bootlab import Plop

M = {   # runtime cs offsets (file + 0x100)
    0x0DE7: 'mainloop digit key',
    0x1939: 'sub_1839 digit-boot',
    0x18DD: 'sub_17DD (inside 1839)',
    0x0F0A: 'sub_0E0A build devlist',
    0x0F2B: '0E0A: entry present?',
    0x0F80: '0E0A: name-copy branch',
    0x668D: 'sub_658D (inside 1839)',
    0x1759: 'sub_1659 (inside 1839)',
    0x175F: 'sub_1659 call 6481',
    0x1777: 'sub_1659 call 612B',
    0x177A: 'sub_1659 call 644E',
    0x177E: 'sub_1659 call 5EC2',
    0x1785: 'sub_1659 pump iter',
    0x1795: 'sub_1659 exit',
    0x6738: 'watchdog LJMP 0:0 !!',
    0x6732: 'timer re-arm',
    0x17B6: 'sub_16B6 print',
    0x7DB2: 'sub_7CB2 load-profile-records',
    0x1972: 'no-entry error path',
    0x197B: 'B71D==0 error path',
    0x1ADA: 'sub_19DA scan blocks',
    0x1AEE: 'sub_19DA FOUND block',
    0x1AEB: 'sub_19DA none-found',
    0x1B0D: 'sub_1A0D parse entry',
    0x1A21: 'after sub_1A0D ret',
    0x1A2B: 'sig check 0xC8E9',
    0x1A49: 'call sub_1A76 site',
    0x1B5A: 'profile READ AH02',
    0x1B76: 'sub_1A76 boot-to-7C00',
}

seen = []
counts = {}
spin = {}
_spin_n = [0]
def extra(uc, cs_off):
    if cs_off in M:
        counts[cs_off] = counts.get(cs_off, 0) + 1
        if cs_off not in seen:
            seen.append(cs_off)
            print('[hit] cs_off=%04X %s  ticks=%d'
                  % (cs_off, M[cs_off], p.ticks_fired), flush=True)
        if cs_off == 0x1A2B and 'sigctx' not in globals():
            ds = uc.reg_read(bootlab.X86_REG_DS)
            es = uc.reg_read(bootlab.X86_REG_ES)
            print('[ctx] at sig check: DS=%04X ES=%04X  DS:C6EB sig=%s  '
                  'DS:0 CEED pkt=%s'
                  % (ds, es,
                     bytes(uc.mem_read(((ds << 4) + 0xC6EB + 0x1FE) & 0xFFFFF, 2)).hex(),
                     bytes(uc.mem_read(((ds << 4) + 0x0CEED) & 0xFFFFF, 16)).hex()),
                  flush=True)
            globals()['sigctx'] = True
    _spin_n[0] += 1
    if _spin_n[0] >= 500_000:
        _spin_n[0] = 0
        cs = uc.reg_read(bootlab.X86_REG_CS)
        ip = uc.reg_read(bootlab.X86_REG_IP)
        spin[(cs, ip)] = spin.get((cs, ip), 0) + 1
        sp = uc.reg_read(bootlab.X86_REG_SP)
        try:
            ss = uc.reg_read(bootlab.X86_REG_SS)
            stk = bytes(uc.mem_read(((ss << 4) + sp) & 0xFFFFF, 64))
            words = struct.unpack('<32H', stk)
            rets = [w for w in words if 0x0100 < w < 0xAA38]
            globals()['last_stack'] = (cs, ip, sp, ' '.join('%04X' % w for w in rets[:10]))
        except Exception:
            pass

p = Plop(keys="1 1 1 1 1 1 1 1", edd='ATA', tick_insns=200_000, feed_watchdog=True,
         hook_extra=extra, max_insns=300_000_000)
p.bios.disk_attach(bootlab.default_disk())
# inject a configured boot-entry record into profile slot 0 at sub_7CB2
# entry (the boot's BSS restore would wipe a pre-run write):
# [0xB562+slot*0x10]: dev id byte @+0, LBA u32 @+8 - partition 1 @ LBA 63
_injected = [False]
_base_hook_extra = extra
def extra(uc, cs_off):
    if cs_off == 0x7DB2 and not _injected[0]:
        _injected[0] = True
        rec = bytearray(0x10)
        rec[0] = 0x80                       # device: first hard disk
        struct.pack_into("<I", rec, 8, 63)  # boot sector LBA
        rec[13] = 0x01                      # partition id / slot marker
        uc.mem_write(p.base + 0xB562, bytes(rec))
    _base_hook_extra(uc, cs_off)
r = p.run()
print('run:', r, flush=True)

base = p.base
def d8(a):  return p.uc.mem_read(a, 1)[0]
def d16(a): return struct.unpack('<H', bytes(p.uc.mem_read(a, 2)))[0]
def db(a, n): return bytes(p.uc.mem_read(a, n))
print('--- profile tables ---', flush=True)
for off in (0xB232, 0xB242, 0xB252):
    row = db(base + off, 16)
    print('%04X: %s' % (off, row.hex(' ')), flush=True)
print('B562 0x10-stride records:', flush=True)
for i in range(4):
    print('  [%d] %s' % (i, db(base + 0xB562 + i*0x10, 0x10).hex(' ')), flush=True)
print('C32C 0x13-stride profile:', flush=True)
for i in range(4):
    print('  [%d] %s' % (i, db(base + 0xC32C + i*0x13, 0x13).hex(' ')), flush=True)
print('B70D/B6F9 scratch:', db(base + 0xB70D, 0x10).hex(' '), '/',
      db(base + 0xB6F9, 0x10).hex(' '), flush=True)
sig = db(base + 0xC6EB + 0x1FE, 2).hex(' ')
print('boot sector sig at C6EB+1FE =', sig, flush=True)
print('int13 ah42 notes:', p.bios.notes, flush=True)
print('C6A9 boot blocks:', flush=True)
for i in range(4):
    print('  [%d] %s' % (i, db(base + 0xC6A9 + i*0x10, 0x10).hex(' ')), flush=True)
print('B71D=%02X B71E=%02X B71F=%02X' %
      (d8(base+0xB71D), d8(base+0xB71E), d8(base+0xB71F)), flush=True)
print('B6F8=%d B6F7=%d B063=%d DF33=%d' %
      (d8(base+0xB6F8), d8(base+0xB6F7), d8(base+0xB063),
       d8(base+0xDF33)), flush=True)
print('BC20 (dev status) = %04X  BC18 dev struct: %s' %
      (d16(base+0xBC20), db(base+0xBC18, 0x10).hex(' ')), flush=True)
print('milestone counts:', {hex(k): v for k, v in counts.items()}, flush=True)
print('spin samples (cs,ip)->count:', {(hex(c), hex(i)): n for (c, i), n
      in sorted(spin.items(), key=lambda kv: -kv[1])[:12]}, flush=True)
cs, ip, sp, stk = globals().get('last_stack', (0, 0, 0, ''))
print('last sample stack CS=%04X IP=%04X SP=%04X: %s' % (cs, ip, sp, stk),
      flush=True)
print('--- screen ---', flush=True)
print(p.dump_screen(), flush=True)