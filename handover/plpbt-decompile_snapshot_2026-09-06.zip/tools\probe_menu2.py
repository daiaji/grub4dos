#!/usr/bin/env python3
"""Preset full geometry incl [0xAB64] row count; does draw terminate -> menu poll/int19?"""
import sys, os, struct
from collections import Counter
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from unicorn import *
from unicorn.x86_const import *
from bootlab import Plop
_xc = sys.modules['unicorn.x86_const']
for _n in dir(_xc):
    if _n.startswith('UC_X86_REG_'):
        globals()[_n[3:]] = getattr(_xc, _n)

def build_disk():
    disk = bytearray(8*1024*1024)
    mbr = bytearray(512); mbr[446]=0x80; mbr[447:450]=bytes([0,1,1]); mbr[450]=0x06
    mbr[451:454]=bytes([15,63,63]); mbr[454:458]=struct.pack('<I',63); mbr[458:462]=struct.pack('<I',1022)
    mbr[510:512]=b'\x55\xAA'; disk[0:512]=mbr
    pbs=bytearray(512); pbs[510:512]=b'\x55\xAA'; disk[63*512:64*512]=pbs
    return bytes(disk)

p = Plop(load_seg=0x7C00, entry=0x8BE, edd_type='ATA', max_insns=80_000_000)
p.bios.disk_attach(build_disk())
base = 0x7C00<<4
W,H = 80*8, 25*8
def mkdesc(size):
    d = bytearray(0x25)
    struct.pack_into('<I', d, 0x00, size)
    struct.pack_into('<H', d, 0x14, W)   # ab62 width
    struct.pack_into('<H', d, 0x16, H)   # ab64 rows (text frame height)
    d[0x18]=1                            # ab7a border flag
    struct.pack_into('<H', d, 0x19, W)   # ab7b box width
    struct.pack_into('<H', d, 0x1B, 0)   # ab72
    struct.pack_into('<H', d, 0x1D, H)   # ab74 height
    struct.pack_into('<H', d, 0x1F, W)   # ab76 row stride
    struct.pack_into('<H', d, 0x21, H)   # ab78 box height
    struct.pack_into('<H', d, 0x23, 0)   # ab81
    return bytes(d)
p.uc.mem_write(base+0x9A26, mkdesc(0x2320))
p.uc.mem_write(base+0x9A4B, mkdesc(0x1000))
p.uc.mem_write(base+0xB732, bytes(bytearray(0x39)))
p.uc.mem_write(base+0xB76B, bytes(bytearray(0x39)))

# count int16 polls, int19, and trace hot loop
polls=[0]; last=[]
def code(uc, addr, size, ud):
    off=addr-base
    if off in (0x172E,0x6317,0x833D):
        polls[0]+=1
        if len(last)<30: last.append(('poll', hex(off), hex(uc.reg_read(X86_REG_AX)&0xFFFF)))
p.uc.hook_add(UC_HOOK_CODE, code)
r=p.run()
print('run:', r[:140])
print('menu polls:', polls[0])
print('int16 count:', sum(1 for t in p.bios.int_trace if t[0]==0x16))
print('int19 count:', sum(1 for t in p.bios.int_trace if t[0]==0x19))
print('int trace tail (all ints):')
for t in p.bios.int_trace[-20:]:
    n,ax,bx,cx,dx,si,di,cs,ip=t
    print('  int %02X ax=%04X from %04X:%04X'%(n,ax,cs,ip))
ab6a = struct.unpack('<I', bytes(p.uc.mem_read(base+0xAB6A,4)))[0]
print('[0xab6a]=0x%X'%ab6a)
fb = bytes(p.uc.mem_read(ab6a, 80*25*2))
lines=[]
for r0 in range(25):
    row=fb[r0*160:(r0+1)*160]
    txt=''.join(chr(c) if 32<=c<127 else '.' for c in row[0::2])
    lines.append(txt)
print('--- offscreen 80x25 ---')
print('\n'.join(lines).rstrip('.') )
