#!/usr/bin/env python3
"""Reproduce alloc_size=0x2320 (findings §3.2): does boot get to menu draw?
Then record the geometry vars the draw code reads at 0x5EC2/0x6029."""
import sys, os, struct
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from unicorn import *
from unicorn.x86_const import *
from bootlab import Plop
_xc = sys.modules['unicorn.x86_const']
for _n in dir(_xc):
    if _n.startswith('UC_X86_REG_'):
        globals()[_n[3:]] = getattr(_xc, _n)

def build_disk():
    disk = bytearray(8*1024*1024)
    mbr = bytearray(512); mbr[446]=0x80; mbr[447:450]=bytes([0,1,1]); mbr[450]=0x06
    mbr[451:454]=bytes([15,63,63]); mbr[454:458]=struct.pack('<I',63); mbr[458:462]=struct.pack('<I',1022)
    mbr[510:512]=b'\x55\xAA'; disk[0:512]=mbr
    pbs=bytearray(512); pbs[510:512]=b'\x55\xAA'; disk[63*512:64*512]=pbs
    return bytes(disk)

base = 0x7C00<<4
p = Plop(load_seg=0x7C00, entry=0x8BE, edd_type='ATA', alloc_size=0x2320)
p.bios.disk_attach(build_disk())

geo = {}
def code(uc, addr, size, ud):
    if addr == base+0x5EC2:
        for off in (0xab6a,0xab62,0xab74,0xab72,0xab78,0xab7b,0xab76,0xab7a):
            geo[off] = struct.unpack('<H', bytes(uc.mem_read(base+off,2)))[0]
        # also edi start
        geo['edi'] = uc.reg_read(X86_REG_EDI)
        geo.setdefault('hits', 0)
        geo['hits'] += 1
        if geo['hits'] == 1:
            print('first 5EC2 entry: edi=%08X' % geo['edi'])
p.uc.hook_add(UC_HOOK_CODE, code)
r = p.run()
print('run:', r[:120])
print('geometry at 5EC2 (hits=%d):' % geo.get('hits',0))
for k,v in geo.items():
    if isinstance(k, int): print('  [%04X] = 0x%04X' % (k, v))
# screen?
print('--- screen ---')
print(p.dump_screen())
print(p.bss_report())
