#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""UHCI transport probe: run 'u' (all three modules) and watch the UHCI round.

Milestone hooks live at UHCI-module runtime addresses
(ip = file - 0x2253, linear = 0x9A700 + ip), so they only fire while the
UHCI copy is installed.  The AH=0x99 dispatcher (sub_25C4) records the AL
command sequence: AL=1 init / AL=2 gate (PCI presence) / AL=3 find-by-class /
AL=4 controller init / AL=6 CCS check / AL=7 enumeration (SET_ADDRESS +
GET_DESCRIPTOR over the UHCI transport).

The virtual controller (port I/O at 0xC000) advances one frame per USBSTS
poll (uhci_read), running the QH element chain and raising USBINT - the
driver's sub_2F95 wait loop is the UHCI doorbell equivalent.
"""
import os, sys, struct
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bootlab
from bootlab import Plop

HSEG, GAP, BASE = 0x9A700, 0x100, 0x2353
# module installs at hookseg:0x100 -> ip = file - BASE + 0x100,
# linear = HSEG + ip (same model as the EHCI probes)
def ip_of(foff): return (foff - BASE) + 0x100
def lin(foff): return HSEG + ip_of(foff)

M = {
    0x2483: 'int13 hook AH=99',      # module int13 entry
    0x2BF4: 'AL2 PCI presence',      # the 0x9902 gate
    0x280E: 'AL3 find-by-class',
    0x2824: 'AL4 controller init',
    0x2CC8: 'io slot table build',
    0x2E02: 'HC reset/HCHalt wait',
    0x2863: 'frame list init',
    0x2E4B: 'RUN set',
    0x2F95: 'exec+wait (doorbell)',
    0x303C: 'TD build',
    0x313F: 'IN TD build',
    0x2927: 'AL7 enumeration',
    0x28F6: 'AL6 CCS check',
}
hits, ticks_at = {}, {}
al_log = []
def mk(name):
    def cb(uc, addr, size, ud):
        hits[name] = hits.get(name, 0) + 1
        if name not in ticks_at:
            ticks_at[name] = p.ticks_fired
    return cb

hot = {}
_n = [0]
def sampler(uc, cs_off):
    _n[0] += 1
    if _n[0] >= 2_000_000:
        _n[0] = 0
        cs = uc.reg_read(bootlab.X86_REG_CS)
        ip = uc.reg_read(bootlab.X86_REG_IP)
        hot[(cs, ip)] = hot.get((cs, ip), 0) + 1

p = Plop(keys='u', edd='USBD', tick_insns=200_000, feed_watchdog=True,
         hook_extra=sampler, max_insns=400_000_000)
p.bios.disk_attach(bootlab.default_disk())
u = p.uc
for foff, name in M.items():
    u.hook_add(bootlab.UC_HOOK_CODE, mk(name), begin=lin(foff), end=lin(foff))

def al_cb(uc, addr, size, ud):
    al = uc.reg_read(bootlab.X86_REG_AX) & 0xFF
    al_log.append(al)
    hits['AL dispatcher'] = hits.get('AL dispatcher', 0) + 1
    if 'AL dispatcher' not in ticks_at:
        ticks_at['AL dispatcher'] = p.ticks_fired
u.hook_add(bootlab.UC_HOOK_CODE, al_cb, begin=lin(0x25C4), end=lin(0x25C4))

r = p.run()
print('run:', r, flush=True)
print('milestones:', {k: (v, ticks_at.get(k)) for k, v in hits.items()}, flush=True)
print('AL sequence:', al_log, flush=True)
print('pci_log:', p.bios.pci_log, flush=True)
print('uhci engine: frames=%d tds_done=%d frbase=%08X cmd=%04X sts_resid=%04X'
      % (p.bios.uhci_frames, p.bios.uhci_tds_done, p.bios.uhci_frbase,
         p.bios.uhci_cmd, p.bios.uhci_sts_resid), flush=True)
print('usb state: cbw=%s write=%s notes=%s'
      % (p.bios.usb_cbw, p.bios.usb_write, p.bios.notes[-5:]), flush=True)
print('disk writes:', p.bios.disk_writes, flush=True)
print('hot (cs,ip):', {(hex(c), hex(i)): n for (c, i), n in
      sorted(hot.items(), key=lambda kv: -kv[1])[:12]}, flush=True)
print('--- screen (last rows) ---')
print(p.dump_screen()[-600:], flush=True)
