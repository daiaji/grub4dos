#!/usr/bin/env python3
"""With loader-preset: find the hot loop (top executed instructions) and check canvas."""
import sys, os, struct
from collections import Counter
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from unicorn import *
from unicorn.x86_const import *
from bootlab import Plop
_xc = sys.modules['unicorn.x86_const']
for _n in dir(_xc):
    if _n.startswith('UC_X86_REG_'):
        globals()[_n[3:]] = getattr(_xc, _n)

def build_disk():
    disk = bytearray(8*1024*1024)
    mbr = bytearray(512); mbr[446]=0x80; mbr[447:450]=bytes([0,1,1]); mbr[450]=0x06
    mbr[451:454]=bytes([15,63,63]); mbr[454:458]=struct.pack('<I',63); mbr[458:462]=struct.pack('<I',1022)
    mbr[510:512]=b'\x55\xAA'; disk[0:512]=mbr
    pbs=bytearray(512); pbs[510:512]=b'\x55\xAA'; disk[63*512:64*512]=pbs
    return bytes(disk)

p = Plop(load_seg=0x7C00, entry=0x8BE, edd_type='ATA', max_insns=50_000_000)
p.bios.disk_attach(build_disk())
base = 0x7C00<<4
W,H = 80*8, 25*8
desc = bytearray(0x25)
struct.pack_into('<I', desc, 0x00, 0x2320)
struct.pack_into('<H', desc, 0x14, W)
desc[0x18]=1
struct.pack_into('<H', desc, 0x19, W)
struct.pack_into('<H', desc, 0x1D, H)
struct.pack_into('<H', desc, 0x1F, W)
struct.pack_into('<H', desc, 0x21, H)
p.uc.mem_write(base+0x9A26, bytes(desc))
p.uc.mem_write(base+0xB732, bytes(bytearray(0x39)))
desc2 = bytearray(0x25)
struct.pack_into('<I', desc2, 0x00, 0x1000)
struct.pack_into('<H', desc2, 0x14, W)
desc2[0x18]=1
struct.pack_into('<H', desc2, 0x19, W)
struct.pack_into('<H', desc2, 0x1D, H)
struct.pack_into('<H', desc2, 0x1F, W)
struct.pack_into('<H', desc2, 0x21, H)
p.uc.mem_write(base+0x9A4B, bytes(desc2))
p.uc.mem_write(base+0xB76B, bytes(bytearray(0x39)))

hits=Counter()
def code(uc, addr, size, ud):
    off=addr-base
    if 0<=off<0xAA37:
        hits[off]+=1
p.uc.hook_add(UC_HOOK_CODE, code)
r=p.run()
print('run:', r[:120])
print('total instr (sampled):', sum(hits.values()))
print('top 25 executed offsets:')
for off,cnt in hits.most_common(25):
    print('  %04X  x%d' % (off, cnt))
print('canvas non-space count:', sum(1 for ch in p.bios.screen if ch not in (0x20,0)))
print('canvas head:', bytes(p.bios.screen[:200]).hex(' '))
print('int trace count:', len(p.bios.int_trace))
for i,(n,ax,bx,cx,dx,si,di,cs,ip) in enumerate(p.bios.int_trace[-15:]):
    print('  last int: int %02Xh ax=%04X from %04X:%04X'%(n,ax,cs,ip))
