#!/usr/bin/env python3
"""Log every sub_6481 call (bp/si) and the geometry it writes; find who corrupts 0xAB62."""
import sys, os, struct
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from unicorn import *
from unicorn.x86_const import *
from bootlab import Plop
_xc = sys.modules['unicorn.x86_const']
for _n in dir(_xc):
    if _n.startswith('UC_X86_REG_'):
        globals()[_n[3:]] = getattr(_xc, _n)

def build_disk():
    disk = bytearray(8*1024*1024)
    mbr = bytearray(512); mbr[446]=0x80; mbr[447:450]=bytes([0,1,1]); mbr[450]=0x06
    mbr[451:454]=bytes([15,63,63]); mbr[454:458]=struct.pack('<I',63); mbr[458:462]=struct.pack('<I',1022)
    mbr[510:512]=b'\x55\xAA'; disk[0:512]=mbr
    pbs=bytearray(512); pbs[510:512]=b'\x55\xAA'; disk[63*512:64*512]=pbs
    return bytes(disk)

p = Plop(load_seg=0x7C00, entry=0x8BE, edd_type='ATA', max_insns=15_000_000)
p.bios.disk_attach(build_disk())
base = 0x7C00<<4
W,H = 80*8, 25*8
def mkdesc(size):
    d = bytearray(0x25)
    struct.pack_into('<I', d, 0x00, size)
    struct.pack_into('<H', d, 0x14, W)
    struct.pack_into('<H', d, 0x16, H)
    d[0x18]=1
    struct.pack_into('<H', d, 0x19, W)
    struct.pack_into('<H', d, 0x1B, 0)
    struct.pack_into('<H', d, 0x1D, H)
    struct.pack_into('<H', d, 0x1F, W)
    struct.pack_into('<H', d, 0x21, H)
    struct.pack_into('<H', d, 0x23, 0)
    return bytes(d)
p.uc.mem_write(base+0x9A26, mkdesc(0x2320))
p.uc.mem_write(base+0x9A4B, mkdesc(0x1000))
p.uc.mem_write(base+0xB732, bytes(bytearray(0x39)))
p.uc.mem_write(base+0xB76B, bytes(bytearray(0x39)))

n=[0]
def code(uc, addr, size, ud):
    off=addr-base
    if off==0x6481:
        bp=uc.reg_read(X86_REG_BP)&0xFFFF; si=uc.reg_read(X86_REG_SI)&0xFFFF
        desc=bytes(uc.mem_read(base+bp, 0x25))
        # decode what this descriptor writes to ab62 (offset 0x14) and ab64(0x16)
        w14=struct.unpack('<H',desc[0x14:0x16])[0]
        w16=struct.unpack('<H',desc[0x16:0x18])[0]
        w1d=struct.unpack('<H',desc[0x1d:0x1f])[0]
        n[0]+=1
        print('ALLOC#%d bp=%04X si=%04X  desc[14]=%04X desc[16]=%04X desc[1d]=%04X  desc_head=%s'%
              (n[0],bp,si,w14,w16,w1d,desc[:8].hex()))
p.uc.hook_add(UC_HOOK_CODE, code)
r=p.run()
print('run:', r[:120])
print('total alloc calls:', n[0])
