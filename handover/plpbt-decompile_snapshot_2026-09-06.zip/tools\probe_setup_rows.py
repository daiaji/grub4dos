#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Diagnose the SETUP screen (0xB7A4) row table to find the edit-profile row.
Open SETUP naturally (DOWN x5 + ENTER + ENTER), then dump [0xC128] table,
row count, and each row record's label + handler to locate 0x7B45 (runtime
edit-profile loop, = 0x7A45 file)."""
import os, sys, struct
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bootlab
from bootlab import Plop

p = Plop(tick_insns=200_000, feed_watchdog=True, max_insns=400_000_000)
p.bios.disk_attach(bootlab.default_disk())
u = p.uc
def d8(o): return u.mem_read(p.base + o, 1)[0]
def d16(o): return struct.unpack('<H', bytes(u.mem_read(p.base + o, 2)))[0]
def vis():
    out = set()
    for i in range(26):
        d = struct.unpack('<H', bytes(u.mem_read(p.base + 0xA825 + i*2, 2)))[0]
        if 0x1000 < d < 0xC000 and d8(d) & 1:
            out.add(d)
    return out

seq = ['down']*5 + ['enter', 'enter']
sent, last, n = [0], [0], [0]
st = ['nav']
def extra(uc, cs_off):
    n[0] += 1
    if n[0] < 400_000: return
    n[0] = 0
    v = vis()
    if 0xBC18 in v:
        p.bios.key_push(0x011B); return
    if st[0] == 'nav':
        if p.ticks_fired > 560 and sent[0] < len(seq) and p.ticks_fired - last[0] >= 40:
            k = seq[sent[0]]; sent[0] += 1; last[0] = p.ticks_fired
            p.bios.key_push(0x5000 if k == 'down' else 0x1C0D)
        elif sent[0] == len(seq):
            st[0] = 'dump'
            print('== SETUP open, C133=%04X rows=%d sel=%d ==' %
                  (d16(0xC133), d8(0xC127), d8(0xC126)), flush=True)
            t = d16(0xC128)
            print('C128=%04X' % t)
            rows = d8(0xC127)
            for i in range(min(rows, 16)):
                ent = d16(t + 2*i)          # runtime record addr
                rec = bytes(u.mem_read(p.base + ent, 9))
                w0 = struct.unpack('<H', rec[0:2])[0]
                hw = (rec[8] << 8) | rec[7]
                label = b'?'
                if 0x1000 < w0 < 0xD000:
                    try:
                        label = bytes(u.mem_read(p.base + w0, 20)).split(b'\0')[0]
                    except Exception:
                        pass
                print('  row%d: ent=%04X label=%r hw=%04X' % (i, ent, label, hw), flush=True)
            # find a row whose handler is edit-profile (0x7B45 runtime) or
            # label mentions start/select
            st[0] = 'done'
    elif st[0] == 'done':
        raise SystemExit
p.hook_extra = extra
try:
    r = p.run()
except SystemExit:
    r = 'exit'
print('run:', r)