#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""EHCI async-list evidence probe (3rd gen, fast):
- exact-address hooks on the two known wait loops (async-advance gate at
  file 0x54B0, USBINT wait at file 0x54F8) + doorbell (0x54E7) so the run
  stays near-native speed and still records whether/where the driver parks.
- after the run: decode the QH chain, the qTD pool (segment [0x2BA0], 0x20
  stride), buffer/staging pointers, and the module data slots (hookseg is
  cs 0x9A70 linear 0x9A700 in raw mode; module offset X -> 0x9A700+X).
Module internal offsets: file - 0x469D (EHCI blob install si=cs:0x479D)."""
import os, sys, struct
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bootlab
from bootlab import Plop

HSEG = 0x9A700                    # cs 0x9A70 << 4
M0   = 0x469D                     # EHCI module file base (= hookseg+0)
def mod_ip(file_off): return HSEG + (file_off - M0)

hits = {'async_gate': 0, 'doorbell': 0, 'usbint_wait': 0, 'usbint_loop': 0}
ticks_at = {}

def mk(name, file_off):
    def cb(uc, addr, size, ud):
        hits[name] += 1
        t = p.ticks_fired if hasattr(p, 'ticks_fired') else -1
        if name not in ticks_at:
            ticks_at[name] = t
    return cb

p = Plop(keys='u', edd='USBD', tick_insns=200_000, feed_watchdog=True,
         max_insns=400_000_000)
p.bios.disk_attach(bootlab.default_disk())
u = p.uc
hooks = [
    ('async_gate', 0x54B0),      # sub_54A9: jne . wait bit0x2000 clear
    ('doorbell',   0x54E7),      # sub_54A9: or fs:[esi],0x20 (IAAD ring)
    ('usbint_wait', 0x54F6),     # sub_54F6 entry
    ('usbint_loop', 0x54F8),     # sub_54F6: je back on USBSTS bit0
]
for name, foff in hooks:
    u.hook_add(bootlab.UC_HOOK_CODE, mk(name, foff),
               begin=mod_ip(foff), end=mod_ip(foff))

r = p.run()
print('run:', r, flush=True)
print('hook hits:', hits, flush=True)
print('ticks at first hit:', {k: v for k, v in ticks_at.items()}, flush=True)

def d16(a):  return struct.unpack('<H', bytes(u.mem_read(a, 2)))[0]
def d32(a):  return struct.unpack('<I', bytes(u.mem_read(a, 4)))[0]
def d8(a):   return u.mem_read(a, 1)[0]

# module data slots (hookseg-relative)
print('--- module data slots (hookseg 0x9A70 + off) ---', flush=True)
for off in (0x2B37, 0x2B3B, 0x2B96, 0x2B9A, 0x2B9C, 0x2BA0, 0x2BA2, 0x2BA6,
            0x2BA8, 0x2B94, 0x2B95, 0x2B2A, 0x2B53, 0x2A):
    if off in (0x2B37, 0x2B3B, 0x2B96, 0x2B9C, 0x2BA2, 0x2B53):
        v = d32(HSEG + off)
        print('%04X dword = %08X  (linear %08X)' % (off, v, v), flush=True)
    elif off == 0x2A:
        continue
    else:
        v = d16(HSEG + off)
        print('%04X word  = %04X' % (off, v), flush=True)
print('2B94=%02X 2B95=%02X 2BA8=%02X 2B2A=%02X' %
      (d8(HSEG+0x2B94), d8(HSEG+0x2B95), d8(HSEG+0x2BA8), d8(HSEG+0x2B2A)),
      flush=True)

reg = bytes(u.mem_read(bootlab.Bios.PCI_EHCI_BAR + 0x10, 0x30))
print('EHCI op regs:', reg.hex(' '), flush=True)
asynclist = d32(bootlab.Bios.PCI_EHCI_BAR + 0x10 + 0x18)
print('ASYNCLISTADDR = %08X' % asynclist, flush=True)
if asynclist:
    print('--- QH chain ---', flush=True)
    q = asynclist
    for depth in range(8):
        d = [d32(q + 4*i) for i in range(0x20 // 4)]
        h, ep, cap, cur = d[0], d[1], d[2], d[3]
        ov = d[4:]
        spd = {0: 'full', 1: 'low', 2: 'high'}.get((ep >> 12) & 3, '?')
        mps = (ep >> 16) & 0x7FF
        print('QH@%08X h=%08X dev=%d ep=%d spd=%s mps=%d '
              'cur=%08X ov_n=%08X ov_a=%08X tok=%08X'
              % (q, h, ep & 0x7F, (ep >> 8) & 0xF, spd, mps,
                 cur, ov[0], ov[1], ov[2]), flush=True)
        if not (ov[0] & 1):
            t = ov[0] & ~0x1F
            td = [d32(t + 4*i) for i in range(0x20 // 4)]
            print('  qTD@%08X n=%08X alt=%08X tok=%08X b0=%08X'
                  % (t, td[0], td[1], td[2], td[3]), flush=True)
        q = h & ~0x1F
        if h & 1 or q == asynclist or q == 0:
            break
    base = asynclist & ~0xFF
    print('--- pool around %06X ---' % base, flush=True)
    for off in range(0, 0x200, 0x10):
        row = bytes(u.mem_read(base + off, 0x10))
        stars = ' <-QLIST' if base + off == asynclist else ''
        print('%06X  %s%s' % (base + off, row.hex(' '), stars), flush=True)

# qTD pool: seg [0x2BA0], stride 0x20
qseg = d16(HSEG + 0x2BA0)
buf0 = d32(HSEG + 0x2BA2)
stg  = d16(HSEG + 0x2BA6)
print('--- qTD pool seg=%04X buf0=%08X staging=%04X ---' % (qseg, buf0, stg),
      flush=True)
for slot in range(4):
    a = qseg * 16 + slot * 0x20
    td = [d32(a + 4*i) for i in range(8)]
    print('qTD[%d]@%05X: %s' % (slot, a, ' '.join('%08X' % x for x in td)),
          flush=True)
print('buf0 area:', bytes(u.mem_read(buf0, 0x20)).hex(' '), flush=True)
print('staging    :', bytes(u.mem_read(stg * 16, 0x20)).hex(' '), flush=True)
print('[CF43]=%d [CF44]=%d' % (d16(p.base + 0xCF43), d16(p.base + 0xCF44)),
      flush=True)