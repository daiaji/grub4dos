import sys, os, struct
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from unicorn import *
from unicorn.x86_const import *
from bootlab import Plop
_xc = sys.modules['unicorn.x86_const']
for _n in dir(_xc):
    if _n.startswith('UC_X86_REG_'):
        globals()[_n[3:]] = getattr(_xc, _n)

def build_disk():
    disk = bytearray(8*1024*1024)
    mbr = bytearray(512); mbr[446]=0x80; mbr[447:450]=bytes([0,1,1]); mbr[450]=0x06
    mbr[451:454]=bytes([15,63,63]); mbr[454:458]=struct.pack('<I',63); mbr[458:462]=struct.pack('<I',1022)
    mbr[510:512]=b'\x55\xAA'; disk[0:512]=mbr
    pbs=bytearray(512); pbs[510:512]=b'\x55\xAA'; disk[63*512:64*512]=pbs
    return bytes(disk)

p = Plop(load_seg=0x7C00, entry=0x8BE, edd_type='ATA', max_insns=150_000_000)
p.bios.disk_attach(build_disk())
base = 0x7C00<<4
W,H = 80*8, 25*8
def mkdesc(size):
    d = bytearray(0x25)
    struct.pack_into('<I', d, 0x00, size)
    struct.pack_into('<H', d, 0x14, W)
    struct.pack_into('<H', d, 0x16, H)
    d[0x18]=1
    struct.pack_into('<H', d, 0x19, W)
    struct.pack_into('<H', d, 0x1B, 0)
    struct.pack_into('<H', d, 0x1D, H)
    struct.pack_into('<H', d, 0x1F, W)
    struct.pack_into('<H', d, 0x21, H)
    struct.pack_into('<H', d, 0x23, 0)
    return bytes(d)
p.uc.mem_write(base+0x9A26, mkdesc(0x2320))
p.uc.mem_write(base+0x9A4B, mkdesc(0x1000))
p.uc.mem_write(base+0xB732, bytes(bytearray(0x39)))
p.uc.mem_write(base+0xB76B, bytes(bytearray(0x39)))
for i in range(0x1a):
    p.uc.mem_write(base+0xA825+2*i, b'\x00\x00')

state = {'forced':0, 'fired':0, 'in_h':0}
def code(uc, addr, size, ud):
    off = addr-base
    if off == 0x0B04 and state['forced']==0:
        state['forced']=1
        uc.mem_write(base+0xB018, b'\xff\xff')
    if off == 0x12E6 and state['fired'] < 6 and not state['in_h']:
        state['fired'] += 1
        ivt = struct.unpack('<HH', bytes(uc.mem_read(0x20,4)))
        seg, offv = ivt[1], ivt[0]
        state['in_h'] = 1
        print('fire IVT20 %04X:%04X  b061=%02X b6e6=%04X' % (seg, offv,
            uc.mem_read(base+0xb061,1)[0],
            struct.unpack('<H', bytes(uc.mem_read(base+0xb6e6,2)))[0]))
        p.bios.far_call(seg, offv)
        state['in_h'] = 0
p.uc.hook_add(UC_HOOK_CODE, code)
r = p.run()
print('run:', r[:140])
print('fired:', state['fired'])
print('b061 =', p.uc.mem_read(base+0xb061,1)[0])
print('b6e6 ticks =', struct.unpack('<H', bytes(p.uc.mem_read(base+0xb6e6,2)))[0])
