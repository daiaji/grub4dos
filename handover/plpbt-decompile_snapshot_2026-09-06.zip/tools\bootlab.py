#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
bootlab.py — unicorn-based dynamic analysis environment for plpbt.bin
(see DYNAMIC_PLAN.md route A).

Addressing model (corrected 2026-09-02, supersedes REPORT.md §2):
  The file is built to be loaded with FILE OFFSET 0 AT CS:0x100, i.e.
  CS_offset == file_offset + 0x100.  Official loader segment CS=0x3000
  (checked by the code itself at 0x0D39 "cmp ax, 0x3000"); raw entry is
  CS:0x9BE == file 0x8BE (the first sector's `e9 bb 08` relative jmp lands
  exactly there when file 0 is at CS:0x100).  Evidence: IVT int8 vector
  CS:0x66FB == file 0x65FB (the real EOI/iret handler), tick callback
  [0xb6eb]=0x1185 == file 0x1085 (full pushf/pushal routine), the 26-entry
  window table at CS:0xA825 == file 0xA725 (clean ascending 0xB732..0xBCC3
  pointers, 0x39 stride), window descriptors CS:0x9A26/0x9A4B == file
  0x9926/0x994B (real size/geometry data), string refs (mov si,0xA4D ->
  file 0x94D "Press CTRL-A...").  The old "loader-preset data" theory
  (DYNAMIC_FINDINGS §3.3) was an artifact of reading file offsets 0x100
  too low.  BSS 0xAB3B..0xF8CF is a CS-offset range (zeroed by the entry
  code at CS:0xAB3B..0xF8CF == file 0xAA3B.., i.e. right after the file
  end 0xAA37, leaving exactly 4 bytes CS:0xAB37..0xAB3A for the loader
  SS:SP save slot).

Raw mode: image loaded at CS=0x3000 with file 0 at CS:0x100, entry
CS:IP=0x3000:0x9BE.  SS=CS, SP=0xFFFE set during entry.

Unicorn real-mode `int n` semantics (measured, unicorn 2.1.4):
  * decodes `int n`, advances IP past the instruction, fires UC_HOOK_INTR
  * pushes NO trap frame, does NOT dispatch through the IVT
  * on hook return, execution continues at the advanced IP
So every int is serviced inside the hook.  When plpbt overwrites an IVT
entry (e.g. int 13h -> hook segment :0x100 during sub_8442 install) we
manually far-call the IVT target (pushf/push cs/push ip, set CS:IP) and
let its own `iret` return.

Virtual timer (added 2026-09-02): unicorn has no PIT/IRQ0.  sub_65BA
programs the PIT (divisor 0x5555) and stores the handler into IVT 0x20;
the menu main loops are sti/hlt/int16 polls.  We fire one IRQ0 tick per
executed `hlt` (plus optionally every --tick-insns instructions): read
IVT[8], far-call the handler, let its iret return.  hlt is detected in
the UC_HOOK_CODE hook (size==1 and byte 0xF4) and skipped by setting
EIP past it.  Known quirk: nothing in the image re-arms the handler's
watchdog byte [0xb6e8] (dec each tick; at 0 -> ljmp 0:0), so ticks past
2 will "reboot" unless --feed-watchdog re-arms it each tick.
"""
import os, sys, struct, argparse, zlib
from unicorn import *
from unicorn.x86_const import *

# ---- unicorn 2.x renamed X86_REG_* -> UC_X86_REG_* ----------------------
_xc = sys.modules["unicorn.x86_const"]
for _n in dir(_xc):
    if _n.startswith("UC_X86_REG_"):
        globals()[_n[3:]] = getattr(_xc, _n)

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
BIN  = os.path.join(ROOT, "plpbt.bin")
OUT  = os.path.join(ROOT, "out")

# VBE 'VBE2' magic
VBE2 = b"VBE2"
# virtual LFB for the VBE GUI (must stay inside the 128MB map, clear of
# everything plpbt uses: image/BSS at 0x30000-0x3F8CF, offscreen at 0x1100000)
LFB_BASE = 0x02000000
VBE_MODES = {0x101: (640, 480), 0x103: (800, 600),
             0x105: (1024, 768), 0x107: (1280, 1024)}

# ---------------------------------------------------------------------- BIOS
class Bios:
    """Minimal real-mode BIOS stubs + manual IVT dispatch for software ints."""

    def __init__(self, uc, edd_type="ATA", keys="", log=None):
        self.uc = uc
        self.edd_type = edd_type      # "ATA" | "USBD" -> [si+0x28] host bus type
        self.in_service = 0           # nest count of int/far-call dispatch (IRQ guard)
        self.kbd = []                              # BIOS key words (scan<<8|char)
        self.kbd_head, self.kbd_tail = 0, 0
        for tok in (keys or "").split():
            t = tok.lower()
            if t == "ctrl-a":      self.key_push(0x1E01)
            elif t == "esc":       self.key_push(0x011B)
            elif t == "enter":     self.key_push(0x1C0D)
            elif t == "ctrl-pgup": self.key_push(0x8400)
            elif t == "ctrl-pgdn": self.key_push(0x7600)
            elif t in ("up", "down", "left", "right"):
                self.key_push(self.SCAN[t] << 8 | 0xE0)
            elif len(t) == 1:
                self.key_push((self.SCAN.get(t, 0) << 8) | ord(t))
            else:
                raise ValueError("unknown key token %r" % tok)
        self.kbd_head, self.kbd_tail = 0, len(self.kbd)   # == pushed count
        # (was min(len(keys),32): the raw string length overcounts tokens
        # and a peek past the real queue crashed int16 - seen when the
        # digit-boot path re-enters int16 after the boot jump)
        self.b01b = False            # key-pending flag set by fire_irq0 (Plop [0xB01B])
        self.screen = bytearray(b" " * 2000)   # 80x25 text cells (attr 0x07)
        self.attr = 0x07
        self.cursor = (0, 0)                    # (row, col) 0-based
        self.ticks = 0
        self.last_int19 = None
        self.font_installed = False
        self.int_trace = []                    # (intno, ax, bx, cx, dx, si, di)
        self.notes = []                        # free-form observations
        self.log = log
        # ---- virtual USB mass-storage device (BOT over EHCI async list) ----
        self.usb_irq = 0            # raised USBSTS bits (W1C model)
        self.usb_setup = b""        # last 8-byte control SETUP (if any)
        self.usb_cbw = None         # pending BOT CBW dict
        self.usb_data_in = None     # queued data-in payload for the next IN
        self.usb_csw_pending = False
        self.usb_write = None       # pending WRITE(10): (lba, bytes_remaining)
        # ---- virtual UHCI controller (I/O ports at 0xC000, PIIX4-style) ----
        self.uhci_cmd = 0           # USBCMD (RUN bit0 kept, resets self-clear)
        self.uhci_sts_resid = 0     # USBSTS W1C residual (USBINT|ERRINT|...)
        self.uhci_frbase = 0        # FRBASEADD linear (1024x32b frame list)
        self.uhci_io = {}           # USBINTR/FRNUM raw storage (offset->value)
        self.uhci_pe = [0, 0]       # sticky PortEnable per port
        self.uhci_ports = [0, 0]    # W1C change-bit residual per port
        self.uhci_frames = 0        # engine stats: frame advances
        self.uhci_tds_done = 0
        # ---- virtual OHCI controller (MMIO at 0x10100000) ----
        self.ohci_ctrl = 0          # HcControl
        self.ohci_cmd = 0           # HcCommandStatus (HCR sticky until read)
        self.ohci_ist = 0           # HcInterruptStatus W1C residual
        self.ohci_ie = 0            # HcInterruptEnable/Disable state
        self.ohci_hcca = 0
        self.ohci_ctrl_head = 0     # HcControlHeadED
        self.ohci_bulk_head = 0
        self.ohci_done = 0          # HcDoneHead
        self.ohci_ports = [0, 0]    # sticky PES|PPS flags + W1C residuals
        self.ohci_tds_done = 0
        # per-controller fake-device switches: with the device detached the
        # module's AL6 CCS check fails cleanly (used to reach the OHCI round
        # of the 'u' install loop, which stops at the first successful test)
        self.uhci_attached = True
        self.ohci_attached = True
        self.usb_cbws = 0           # BOT CBWs parsed (both engines)
        self.usb_csws = 0           # CSWs served
        self.usb_last_cmd = None    # (op, lba, cnt) of the last R/W command

    # ---- virtual USB device: descriptors + BOT ---------------------------
    USB_DEV_DESC = bytes([
        0x12, 0x01, 0x00, 0x02, 0x00, 0x00, 0x00, 0x40,   # 64B EP0, HS
        0x34, 0x12, 0x78, 0x56, 0x00, 0x01,               # VID 0x1234 PID 0x5678
        0x01, 0x02, 0x03, 0x01])
    USB_CFG_DESC = bytes([
        0x09, 0x02, 0x20, 0x00, 0x01, 0x01, 0x00, 0x80, 0xFA,
        0x09, 0x04, 0x00, 0x00, 0x02, 0x08, 0x06, 0x50, 0x00,   # MSC/BOT/Bulk
        0x07, 0x05, 0x81, 0x02, 0x40, 0x00, 0x00,               # EP1 IN bulk
        0x07, 0x05, 0x02, 0x02, 0x40, 0x00, 0x00])              # EP2 OUT bulk

    def usb_scsi_inquiry(self):
        d = bytearray(36)
        d[0], d[1], d[3] = 0x00, 0x80, 0x02     # direct-access, removable, UFI? no: SCSI
        d[2] = 0x05                             # SPC-3
        d[4] = 0x1F                             # extra length
        d[8:16] = b"PLOP     "
        d[16:32] = b"VIRTUAL-DISK     "
        d[32:34] = b"1.0"
        return bytes(d)

    def usb_scsi_read_capacity(self):
        n = max(self.disk_nsect, 1) - 1
        return struct.pack(">II", n, 512)

    def usb_csw(self):
        tag = self.usb_cbw["tag"] if self.usb_cbw else 0
        return b"USBS" + struct.pack("<IIB", tag, 0, 0)

    def usb_host_cbw(self, payload):
        """Parse a BOT CBW (31B) - shared by the EHCI qTD and UHCI TD engines."""
        self.usb_write = None          # new CBW resyncs the BOT state
        tag = struct.unpack("<I", payload[4:8])[0]
        dlen = struct.unpack("<I", payload[8:12])[0]
        cb = payload[15:31]
        op = cb[0]
        self.usb_cbws += 1
        self.usb_cbw = {"tag": tag, "dlen": dlen, "flags": payload[12]}
        if op == 0x12:                # INQUIRY
            self.usb_data_in = self.usb_scsi_inquiry()
        elif op == 0x25:              # READ CAPACITY(10)
            self.usb_data_in = self.usb_scsi_read_capacity()
        elif op == 0x28:              # READ(10)
            lba = struct.unpack(">I", cb[2:6])[0]
            cnt = struct.unpack(">H", cb[7:9])[0]
            self.usb_last_cmd = (op, lba, cnt)
            self.usb_data_in = self.disk_read(lba, cnt)
        elif op == 0x2A:              # WRITE(10): data-OUT stage follows
            lba = struct.unpack(">I", cb[2:6])[0]
            cnt = struct.unpack(">H", cb[7:9])[0]
            self.usb_last_cmd = (op, lba, cnt)
            self.usb_write = (lba, cnt * 512)
            self.usb_data_in = None
        else:                         # TEST UNIT READY et al
            self.usb_data_in = None
            self.usb_csw_pending = True

    def usb_host_data_out(self, buf, nbytes):
        """BOT data-OUT stage: persist WRITE(10) payload into the disk."""
        u = self.uc
        lba, left = self.usb_write
        data = bytes(u.mem_read(buf, nbytes))
        n = min(len(data), left)
        if not self.disk_write(lba, data[:n]):
            self.notes.append("BOT WRITE(10) dropped: LBA %d OOB (%d B)" % (lba, n))
        self.usb_write = None if n >= left else (lba + n // 512, left - n)
        self.usb_csw_pending = True   # data stage done -> CSW next

    def usb_respond(self, nbytes):
        """Payload for the next IN transfer of `nbytes` bytes."""
        if self.usb_data_in is not None:
            data, self.usb_data_in = self.usb_data_in, None
            self.usb_csw_pending = True
            return data[:nbytes].ljust(min(nbytes, len(data)), b"\0")
        if self.usb_csw_pending and nbytes <= 15:
            self.usb_csw_pending = False
            self.usb_csws += 1
            return self.usb_csw()
        # control phase: standard requests
        s = self.usb_setup
        if len(s) >= 8 and (s[0] & 0x80) and s[1] == 0x06:   # GET_DESCRIPTOR
            t = s[3]
            if t == 1:
                return self.USB_DEV_DESC[:nbytes]
            if t == 2:
                return self.USB_CFG_DESC[:nbytes]
            if t == 3:
                return b"\x04\x03\x09\x04"[:nbytes]
        if len(s) >= 8 and s[1] == 0x00 and s[0] == 0x80:    # GET_STATUS
            return b"\x00\x00"[:nbytes]
        return b"\0" * min(nbytes, 64)

    def usb_exec_qtd(self, addr):
        """Execute one active qTD (token bit7) at `addr`; returns next ptr."""
        u = self.uc
        td = [int.from_bytes(u.mem_read(addr + 4*i, 4), "little") for i in range(8)]
        token = td[2]
        if not (token & 0x80):
            return td[0]                      # not active
        pid = (token >> 12) & 3
        nbytes = (token >> 16) & 0x7FFF
        buf0 = td[3]
        if pid == 2:                          # SETUP
            self.usb_setup = bytes(u.mem_read(buf0, 8))
        elif pid == 1:                        # IN
            data = self.usb_respond(nbytes)
            if data:
                u.mem_write(buf0, data[:nbytes])
        else:                                 # OUT
            payload = bytes(u.mem_read(buf0, min(nbytes, 31)))
            if payload[:4] == b"USBC" and self.usb_write is None:   # BOT CBW
                self.usb_host_cbw(payload)
            elif self.usb_write is not None:  # BOT data-OUT: persist sectors
                self.usb_host_data_out(buf0, nbytes)
        newtok = (token & ~0xFF) ^ 0x80000000   # clear active+status, flip toggle
        u.mem_write(addr + 8, struct.pack("<I", newtok))
        return td[0]

    def usb_process_async(self):
        """Controller-side async advance: complete active qTDs, raise IRQ."""
        u = self.uc
        bar = self.PCI_EHCI_BAR
        al = int.from_bytes(u.mem_read(bar + 0x10 + 0x18, 4), "little")
        if not al or al & 1:
            self.usb_irq |= 0x21
            return
        q = al
        for _ in range(8):
            qh = [int.from_bytes(u.mem_read(q + 4*i, 4), "little") for i in range(12)]
            cur = qh[3]
            t = cur if cur and not (cur & 1) else 0
            last = 0
            steps = 0
            while t and not (t & 1) and steps < 8:
                last = t
                t = self.usb_exec_qtd(t)
                steps += 1
            if last:
                # retire the queue: cur=0, overlay mirrors the last qTD
                td = [int.from_bytes(u.mem_read(last + 4*i, 4), "little") for i in range(8)]
                u.mem_write(q + 0x0C, struct.pack("<I", 0))
                u.mem_write(q + 0x10, struct.pack("<I", 1))   # overlay next: term
                u.mem_write(q + 0x14, struct.pack("<I", 1))   # overlay alt: term
                u.mem_write(q + 0x18, struct.pack("<I", td[2]))  # overlay token
            self.usb_irq |= 0x21              # USBINT + IAA
            q = qh[0] & ~0x1F
            if qh[0] & 1 or q == al or q == 0:
                break

    # ---- virtual UHCI engine (port I/O registers at 0xC000) --------------
    # Modeled from the UHCI module decode (DRIVERS.md 6.6): the driver fills
    # a 1024-entry frame list with QH|2 links, chains TDs (32B) off the QH
    # element link, sets USBCMD.RUN and polls USBSTS.bit0 (USBINT) - sub_2F95.
    UHCI_IOBASE = 0xC000
    def uhci_io_hook(self, uc, addr, size, ud):
        """Per-site IN/OUT emulation (UC_HOOK_INSN never fires in this
        unicorn build): answer the port access and skip the instruction."""
        cs = uc.reg_read(X86_REG_CS)
        ip = uc.reg_read(X86_REG_EIP)
        l = ((cs << 4) + ip) & 0xFFFFF
        try:
            b0 = uc.mem_read(l, 1)[0]
        except Exception:
            return
        wide, ilen = False, 1
        if b0 == 0x66:
            try:
                b1 = uc.mem_read(l + 1, 1)[0]
            except Exception:
                return
            if b1 not in (0xED, 0xEF):
                return
            op, wide, ilen = b1, True, 2
        elif b0 in (0xED, 0xEF):
            op = b0
        else:
            return                     # not a port op at this ip right now
        dx = uc.reg_read(X86_REG_EDX) & 0xFFFF
        if not (self.UHCI_IOBASE <= dx < self.UHCI_IOBASE + 0x20):
            return                     # some other port: leave it unhandled
        off = dx - self.UHCI_IOBASE
        if op == 0xED:                 # IN
            v = self.uhci_read(off) & (0xFFFFFFFF if wide else 0xFFFF)
            uc.reg_write(X86_REG_EAX, v)
        else:                          # OUT
            v = uc.reg_read(X86_REG_EAX) & (0xFFFFFFFF if wide else 0xFFFF)
            self.uhci_write(off, v, 4 if wide else 2)
        uc.reg_write(X86_REG_EIP, ip + ilen)

    def uhci_write(self, off, value, size):
        if off == 0x00:                       # USBCMD
            old = self.uhci_cmd
            self.uhci_cmd = value & 0x1F
            if value & 4:                     # HCRESET self-clears, halts
                self.uhci_cmd &= ~0x01
            if (value & 1) and not (old & 1): # RUN edge: advance one frame
                self.uhci_advance()
        elif off == 0x02:                     # USBSTS: W1C
            self.uhci_sts_resid &= ~(value & 0xFFFF)
        elif off == 0x08:                     # FRBASEADD (32b, maybe split)
            self.uhci_frbase = value if size == 4 else \
                value | (self.uhci_frbase & 0xFFFF0000)
        elif off == 0x0A and size == 2:       # FRBASEADD high word
            self.uhci_frbase = (self.uhci_frbase & 0xFFFF) | (value << 16)
        elif off in (0x10, 0x12):             # PORTSC0/1
            pi = (off - 0x10) // 2
            if value & 0x100:                 # PortReset: self-clears,
                self.uhci_ports[pi] |= 0x200  # raises PRC, enables port
                self.uhci_pe[pi] |= 0x04
            self.uhci_pe[pi] = (self.uhci_pe[pi] & ~0x04) | (value & 0x04)
            self.uhci_ports[pi] &= ~(value & 0x020B)   # W1C: CSC|PEDC|PRC
            self.uhci_io[off] = value & 0x1F  # rest: raw mirror (debug)
        else:
            self.uhci_io[off] = value & 0xFFFF

    def uhci_read(self, off):
        if off == 0x00:                       # USBCMD
            return self.uhci_cmd
        if off == 0x02:                       # USBSTS: residual | HCHalted
            self.uhci_advance()               # each poll drives a frame
            return (self.uhci_sts_resid & 0x1F) | \
                   (0x00 if self.uhci_cmd & 1 else 0x20)
        if off == 0x06:                       # FRNUM: creep forward
            self.uhci_frames += 1
            return self.uhci_frames & 0x3FF
        if off == 0x08:                       # FRBASEADD (also 32b reads)
            return self.uhci_frbase
        if off in (0x10, 0x12):               # PORTSC0/1: CCS|PE|residual
            pi = (off - 0x10) // 2
            return (0x0001 if self.uhci_attached else 0) | \
                   self.uhci_pe[pi] | self.uhci_ports[pi]
        return self.uhci_io.get(off, 0)

    def uhci_advance(self):
        """One frame: run the active TDs of the QH element chain."""
        u = self.uc
        if not self.uhci_frbase:
            return
        try:
            fl0 = int.from_bytes(u.mem_read(self.uhci_frbase, 4), "little")
        except Exception:
            return
        if fl0 & 1 or not (fl0 & 2):          # terminate / not a QH link
            return
        qh = fl0 & ~0xF                       # UHCI links: 16-byte aligned
        try:
            t = int.from_bytes(u.mem_read(qh + 4, 4), "little")
        except Exception:
            return
        ran, steps = 0, 0
        while t > 1 and steps < 16:
            addr = t & ~0xF
            ran += self.uhci_exec_td(addr)
            try:
                t = int.from_bytes(u.mem_read(addr, 4), "little")
            except Exception:
                break                         # dangling link: stop the walk
            steps += 1
        if ran:
            self.uhci_sts_resid |= 1          # USBINT
            self.uhci_tds_done += ran

    def uhci_exec_td(self, addr):
        """Execute one active UHCI TD (status bit23); returns 1 if run."""
        u = self.uc
        try:
            status = int.from_bytes(u.mem_read(addr + 4, 4), "little")
            if not (status & 0x00800000):
                return 0
            token = int.from_bytes(u.mem_read(addr + 8, 4), "little")
            buf = int.from_bytes(u.mem_read(addr + 0xC, 4), "little")
        except Exception:
            return 0
        pid = token & 0xFF
        ml = (token >> 21) & 0x7FF
        n = 0 if ml == 0x7FF else ml + 1
        p = {0x2D: 2, 0xE1: 0, 0x69: 1}.get(pid)   # SETUP/OUT/IN
        if p == 2:                            # SETUP
            self.usb_setup = bytes(u.mem_read(buf, 8))
        elif p == 1:                          # IN
            data = self.usb_respond(n)
            if data:
                u.mem_write(buf, data[:n])
        elif p == 0:                          # OUT
            payload = bytes(u.mem_read(buf, min(n, 31)))
            if payload[:4] == b"USBC" and self.usb_write is None:
                self.usb_host_cbw(payload)
            elif self.usb_write is not None:
                self.usb_host_data_out(buf, n)
        status &= ~0x00800000                 # retire: clear Active
        u.mem_write(addr + 4, struct.pack("<I", status))
        return 1

    # ---- virtual OHCI engine (MMIO op regs at 0x10100000) ----------------
    # Modeled from the OHCI module decode (DRIVERS.md 6.7): the driver builds
    # EDs/TDs (sub_4203/sub_4066), sets HcControl.CLE, rings the HcCommandStatus
    # CLF/BLF doorbell and polls HcInterruptStatus.bit1 (WritebackDoneHead,
    # sub_4264), then W1C-acks it.  TD = control|CBP|next|BE (OHCI spec).
    # The direction comes from device state, not the TD DP field: 'USBC'
    # payload -> CBW, pending WRITE(10) -> data-OUT, else IN respond.
    PCI_OHCI_BAR = 0x10100000
    OHCI_REGS = (0x00, 0x04, 0x08, 0x0C, 0x10, 0x14, 0x18, 0x20, 0x24,
                 0x28, 0x30, 0x34, 0x48, 0x50, 0x54, 0x58, 0x5C)
    def ohci_read_model(self, off, addr):
        b = self
        if off == 0x00:
            v = 0x10                        # HcRevision
        elif off == 0x04:
            v = b.ohci_ctrl                 # HcControl
        elif off == 0x08:                   # HcCommandStatus: HCR self-clears
            v = b.ohci_cmd & ~1
            b.ohci_cmd = v
        elif off == 0x0C:                   # HcInterruptStatus: WDH poll = door
            b.ohci_advance()
            v = b.ohci_ist | 0xC0000000     # HI bit30/31 always readable
        elif off == 0x10:
            v = b.ohci_ie
        elif off == 0x18:
            v = b.ohci_hcca
        elif off == 0x20:
            v = b.ohci_ctrl_head
        elif off == 0x28:
            v = b.ohci_bulk_head
        elif off == 0x30:
            v = b.ohci_done
        elif 0x54 <= off < 0x5C:            # HcRhPortStatus
            pi = (off - 0x54) // 4
            v = (0x0001 if b.ohci_attached else 0) | b.ohci_ports[pi]
        else:
            return                          # unmodelled: keep the static RAM
        b.uc.mem_write(addr, struct.pack("<I", v & 0xFFFFFFFF))

    def ohci_write_model(self, off, value):
        """Returns True when the access was modelled (suppress the raw
        write); False lets the guest's write land in RAM untouched."""
        b = self
        if off == 0x04:                     # HcControl (HCFS/CLE/BLE...)
            b.ohci_ctrl = value & 0x1FF
        elif off == 0x08:                   # HcCommandStatus
            b.ohci_cmd |= value & 1         # HCR (self-clears on read)
            if value & 0x2:                 # CLF/BLF doorbell -> run lists
                b.ohci_advance()
        elif off == 0x0C:                   # HcInterruptStatus W1C
            b.ohci_ist &= ~value
        elif off == 0x10:                   # HcInterruptEnable
            b.ohci_ie |= value
        elif off == 0x14:                   # HcInterruptDisable
            b.ohci_ie &= ~value
        elif off == 0x18:
            b.ohci_hcca = value
        elif off == 0x20:
            b.ohci_ctrl_head = value
        elif off == 0x28:
            b.ohci_bulk_head = value
        elif off == 0x30:
            b.ohci_done = value
        elif 0x54 <= off < 0x5C:            # HcRhPortStatus writes
            pi = (off - 0x54) // 4
            p = b.ohci_ports[pi]
            if value & 0x002:               # SetPortReset: reset -> enabled
                p |= 0x002 | 0x0020000      # PES + PESC change
            if value & 0x004:               # SetPortEnable
                p |= 0x002
            if value & 0x100:               # SetPortPower
                p |= 0x100
            p &= ~(value & 0x003E0000)      # W1C: CSC/PESC/PSSC/OCIC/PRSC
            b.ohci_ports[pi] = p
        else:
            return False
        return True

    def ohci_advance(self):
        """Run the control ED chain once; retire finished TDs, raise WDH."""
        u = self.uc
        if not self.ohci_ctrl_head:
            return
        ran, ed, steps = 0, self.ohci_ctrl_head, 0
        while not (ed & 1) and ed > 0xF and steps < 8:
            eda = ed & ~0xF                 # OHCI ED links: 16-byte aligned
            ran += self.ohci_exec_ed(eda)
            try:
                ed = int.from_bytes(u.mem_read(eda + 0xC, 4), "little")
            except Exception:
                break
            steps += 1
        if ran:
            self.ohci_ist |= 2              # WritebackDoneHead
            self.ohci_tds_done += ran

    def ohci_exec_ed(self, eda):
        """Execute the TDs hanging off one ED; returns completed TD count.
        ED layout (OHCI spec): +0 flags, +4 TailTd, +8 HeadTd, +0xC NextED;
        TD links are 16-byte aligned, TDs are 16 bytes."""
        u = self.uc
        try:
            d = [int.from_bytes(u.mem_read(eda + 4*i, 4), "little")
                 for i in range(4)]
        except Exception:
            return 0
        head, tail = d[2], d[1]              # HeadTd, TailTd
        t, ran, steps, last = head, 0, 0, 0
        while not (t & 1) and steps < 16:
            tda = t & ~0xF                   # OHCI links: 16-byte aligned
            if tda == (tail & ~0xF):         # reached the empty-queue marker
                break
            ran += self.ohci_exec_td(tda)
            last = tda
            try:
                t = int.from_bytes(u.mem_read(tda + 8, 4), "little")
            except Exception:
                break
            steps += 1
        if last:
            # retire: HeadTd <- TailTd (queue empty); done head -> HCCA+0x80
            try:
                u.mem_write(eda + 8, struct.pack("<I",
                            (tail & ~0xF) | (head & 2)))
                if self.ohci_hcca:
                    u.mem_write(self.ohci_hcca + 0x80,
                                struct.pack("<I", last))
            except Exception:
                pass
            self.ohci_done = last
        return ran

    def ohci_exec_td(self, tda):
        """Execute one OHCI TD; returns 1 if it was pending (CC=0xF)."""
        u = self.uc
        try:
            ctrl = int.from_bytes(u.mem_read(tda, 4), "little")
            if (ctrl >> 28) != 0xF:         # CC != not-accessed: done/idle
                return 0
            cbp = int.from_bytes(u.mem_read(tda + 4, 4), "little")
            be = int.from_bytes(u.mem_read(tda + 0xC, 4), "little")
        except Exception:
            return 0
        length = (be - cbp + 1) if cbp and be >= cbp else 0
        if length > 0x2000:                 # bogus BE: clamp
            length = 0
        if length:
            payload = bytes(u.mem_read(cbp, min(length, 31)))
            if payload[:4] == b"USBC" and self.usb_write is None:
                self.usb_host_cbw(payload)                  # BOT CBW (OUT)
            elif self.usb_write is not None:
                self.usb_host_data_out(cbp, length)             # WRITE(10)
            elif length == 8 and payload[0] in (0x00, 0x80) and \
                    payload[1] in (0x00, 0x05, 0x06, 0x08, 0x09):
                self.usb_setup = payload                    # control SETUP
            else:
                data = self.usb_respond(length)             # IN
                if data:
                    u.mem_write(cbp, data[:length])
        # complete: CC=NoError, CBP=0 (buffer consumed)
        ctrl &= 0x0FFFFFFF
        u.mem_write(tda, struct.pack("<I", ctrl))
        u.mem_write(tda + 4, struct.pack("<I", 0))
        return 1

    # ---- helpers ---------------------------------------------------------
    def reg(self, n):   return self.uc.reg_read(n)
    def sreg(self, n):  return self.uc.reg_read(n)
    def set(self, n, v): self.uc.reg_write(n, v & 0xFFFF)
    def lin(self, seg, off): return ((seg << 4) + off) & 0xFFFFF

    def cf(self, v):
        f = self.reg(X86_REG_FLAGS)
        f = (f | 1) if v else (f & ~1)
        self.set(X86_REG_FLAGS, f)

    def rd(self, seg, off, n): return bytes(self.uc.mem_read(self.lin(seg, off), n))
    def wr(self, seg, off, data): self.uc.mem_write(self.lin(seg, off), data)

    # ---- disk ------------------------------------------------------------
    DISK_SECTORS = 1024 * 16 * 63 // 512 * 0  # placeholder; 8MB = 16384 sect
    disk = None
    disk_dl = 0x80                 # the one attached drive
    part_base = {0x80: 0, 0x81: 63, 0x82: 0, 0x83: 0}   # dl -> LBA (0x82/83 absent)

    def drive_ok(self, dl):
        # during detection (AH=08/48) only the real drive responds; during the
        # partition scan Plop reads synthetic drive numbers 0x81..0x83 that map
        # to MBR partition boot sectors (we map 0x81 -> partition 1 @ LBA 63).
        return dl in (0x80, 0x81)

    def drive_lba(self, dl, lba):
        return lba + self.part_base.get(dl, 0)

    def disk_attach(self, image):
        self.disk = bytearray(image)           # mutable: BOT WRITE(10) persists
        self.disk_nsect = len(image) // 512
        self.disk_writes = []                  # [(lba, nbytes)] BOT WRITE(10) log

    def disk_read(self, start, n):
        if start < 0 or start + n > self.disk_nsect:
            return None
        return bytes(self.disk[start*512:(start+n)*512])

    def disk_write(self, start, data):
        """Persist a BOT WRITE(10) payload into the virtual disk (bytes)."""
        if not data or start < 0 or start*512 + len(data) > self.disk_nsect * 512:
            return False
        self.disk[start*512:start*512+len(data)] = data
        self.disk_writes.append((start, len(data)))
        return True

    # ---- int 13h ---------------------------------------------------------
    def int13(self):
        uc, ah = self.uc, self.reg(X86_REG_AX) >> 8
        dl = self.reg(X86_REG_DX) & 0xFF
        if not self.drive_ok(dl):
            self.cf(1)
            self.set(X86_REG_AX, 0x8000)      # drive not present
            return
        if ah == 0x02:      # read sectors CHS
            al = self.reg(X86_REG_AX) & 0xFF
            ch = (self.reg(X86_REG_CX) >> 8) & 0xFF
            cl = self.reg(X86_REG_CX) & 0xFF
            dh = (self.reg(X86_REG_DX) >> 8) & 0xFF
            cyl = ((ch << 8) | (cl >> 6)) & 0x3FF
            sec = cl & 0x3F
            lba = (cyl * 16 + dh) * 63 + (sec - 1)
            es, bx = self.reg(X86_REG_ES), self.reg(X86_REG_BX)
            data = self.disk_read(lba, al)
            if data is not None and len(data) == al * 512:
                self.wr(es, bx, data)
                self.cf(0); self.set(X86_REG_AX, (0 << 8) | al)
            else:
                self.cf(1); self.set(X86_REG_AX, (0x04 << 8))
            return
        if ah == 0x03:      # write sectors CHS
            self.cf(0); self.set(X86_REG_AX, 0)
            return
        if ah == 0x08:      # get drive geometry
            # CX = cyl(spt<<6|sec), DX = heads-1 : dl
            self.set(X86_REG_CX, ((1023 << 8) | 63))
            self.set(X86_REG_DX, (15 << 8) | dl)
            self.set(X86_REG_AX, 0)
            self.cf(0)
            return
        if ah == 0x41:      # ext presence check
            self.set(X86_REG_BX, 0xAA55)
            self.set(X86_REG_CX, 0x0001)
            self.cf(0)
            return
        if ah == 0x42:      # ext read (LBA)
            ds, si = self.reg(X86_REG_DS), self.reg(X86_REG_SI)
            pkt = self.rd(ds, si, 16)          # size,rsvd,count,seg,off,lba[8]
            cnt = pkt[2]
            f1 = struct.unpack("<H", pkt[4:6])[0]
            f2 = struct.unpack("<H", pkt[6:8])[0]
            lba = struct.unpack("<Q", pkt[8:16])[0] & 0xFFFFFFFF
            # EDD spec: +4=offset, +6=segment (Plop's sub_1778 builds it so).
            # The bz setup's own builder historically matched the swapped
            # reading, so accept whichever target is actually mapped.
            # Plop's builder only zeroes the low LBA dword; stale high bytes
            # made huge LBAs read empty slices that "succeeded" while
            # writing nothing (digit-boot sig=0000).
            data = self.disk_read(lba, cnt)
            ok = data is not None and len(data) == cnt * 512
            done = False
            if ok:
                for seg, off in ((f2, f1), (f1, f2)):
                    try:
                        self.uc.mem_read(self.lin(seg, off), 1)
                    except UcError:
                        continue
                    self.wr(seg, off, data)
                    done = True
                    break
            if done:
                self.set(X86_REG_AX, 0); self.cf(0)
            else:
                self.set(X86_REG_AX, 0x04); self.cf(1)
            return
        if ah == 0x48:      # EDD params — Q2's key hook ([si+0x28] host-bus type)
            ds, si = self.reg(X86_REG_DS), self.reg(X86_REG_SI)
            base = self.lin(ds, si)
            req = self.uc.mem_read(base, 1)[0]              # caller's buffer size
            size_out = 0x42 if req >= 0x42 else 0x1E        # EDD2.0 incl. bus type
            self.uc.mem_write(base, bytes([size_out]))
            self.uc.mem_write(base+1, bytes([0]))           # info flags
            self.uc.mem_write(base+2, struct.pack("<I", 1024 * 16 * 63))  # cyls
            self.uc.mem_write(base+6, struct.pack("<I", 16))
            self.uc.mem_write(base+10, struct.pack("<I", 63))
            self.uc.mem_write(base+14, struct.pack("<I", 512))
            self.uc.mem_write(base+22, struct.pack("<Q", self.disk_nsect))
            # bytes 34.. = host bus type, at [si+0x28]
            bus = b"USB " if self.edd_type == "USBD" else self.edd_type.encode()
            if size_out >= 0x42:
                self.uc.mem_write(base + 0x28, bus)
            self.set(X86_REG_AX, 0); self.cf(0)
            return
        self.cf(1); self.set(X86_REG_AX, 0x01)   # unknown AH -> invalid

    # ---- int 10h ---------------------------------------------------------
    def int10(self):
        uc, ah = self.uc, self.reg(X86_REG_AX) >> 8
        if ah == 0x00:      # set video mode
            self.cf(0); return
        if ah == 0x03:      # get cursor pos
            self.set(X86_REG_CX, 0x0007)
            self.set(X86_REG_DX, (self.cursor[0] << 8) | self.cursor[1])
            return
        if ah == 0x02:      # set cursor pos
            row, col = self.reg(X86_REG_DX) >> 8, self.reg(X86_REG_DX) & 0xFF
            self.cursor = (row, col); return
        if ah == 0x08:      # read char at cursor
            r, c = self.cursor
            self.set(X86_REG_AX, self.screen[r*80 + c]); return
        if ah == 0x0E:      # TTY write
            ch = self.reg(X86_REG_AX) & 0xFF
            self.putch(ch); return
        if ah == 0x11:      # character generator / font routines
            al = self.reg(X86_REG_AX) & 0xFF
            if al == 0x30:  # get font info -> ES:BP = 8x8 font ptr
                self.set(X86_REG_ES, 0xF000)
                self.set(X86_REG_BP, 0xFA6E)   # VGA 8x8 font (VGA ROM)
                if not self.font_installed:
                    # No VGA ROM in the emulator: install a DECODABLE synthetic
                    # 8x8 font — glyph c shows c's low-7 bits as full-width bars
                    # in rows 1..7, so text can be recovered from an LFB dump.
                    fnt = bytearray(2048)
                    for c in range(32, 127):
                        for r in range(1, 8):
                            if (c >> (r - 1)) & 1:
                                fnt[c*8 + r] = 0xFF
                    self.uc.mem_write(0xF0000 + 0xFA6E, bytes(fnt))
                    self.font_installed = True
                self.set(X86_REG_CX, 256)
                self.set(X86_REG_DX, 0x0007)
                self.cf(0); return
            if al in (0x00, 0x02, 0x03, 0x04, 0x10, 0x12):  # load font — no-op
                self.cf(0); return
            self.cf(0); return
        if ah == 0x13:      # write string
            es, bp = self.reg(X86_REG_ES), self.reg(X86_REG_BP)
            cx = self.reg(X86_REG_CX)
            data = self.rd(es, bp, cx)
            self.putstr(data)
            return
        if ah == 0x4F:      # VBE
            al = self.reg(X86_REG_AX) & 0xFF
            if al == 0x00:  # 4F00: VBE controller info -> AL=4F, write VBE2 block
                es, di = self.reg(X86_REG_ES), self.reg(X86_REG_DI)
                base = self.lin(es, di)
                info = bytearray(256)
                info[0:4] = b"VBE2"
                info[4:6] = struct.pack("<H", 0x200)      # version 2.0
                info[6:8] = struct.pack("<H", 0x0000)      # OEM string off
                info[8:10] = struct.pack("<H", 0)          # capabilities lo
                info[10:12] = struct.pack("<H", 0)         # capabilities hi
                info[14:16] = struct.pack("<H", 0x0100)    # video modes off
                info[16:18] = struct.pack("<H", 0)         # total mem (0=)
                # real plpbt mode list terminated by FFFF
                modes = struct.pack("<4H", 0x101, 0x103, 0x105, 0x107) + b"\xff\xff"
                self.wr(es, di, bytes(info))
                self.wr(es, (di + 0x100) & 0xFFFF, modes)
                self.set(X86_REG_AX, 0x004F)   # VBE: AL=0x4F supported, AH=0 ok
                self.cf(0); return
            if al == 0x01:  # 4F01: mode info (256B block at ES:DI)
                # plpbt reads the block IN PLACE afterwards: the dword at
                # block+0x28 (PhysBasePtr) IS its [0xAE0F] LFB pointer.
                cx = self.reg(X86_REG_CX) & 0x3FFF
                es, di = self.reg(X86_REG_ES), self.reg(X86_REG_DI)
                base = self.lin(es, di)
                w, h = VBE_MODES.get(cx, (640, 480))
                blk = bytearray(256)
                struct.pack_into("<H", blk, 0x00, 0x009B)  # supported|color|graphics|LFB
                struct.pack_into("<H", blk, 0x04, 4)       # win granularity
                struct.pack_into("<H", blk, 0x06, 64)      # win size (KB)
                struct.pack_into("<H", blk, 0x08, 0xA000)  # win A segment
                struct.pack_into("<I", blk, 0x0C, 0xC0000000)  # win func ptr dummy
                struct.pack_into("<H", blk, 0x10, w)       # bytesPerScanLine (8bpp)
                struct.pack_into("<H", blk, 0x12, w)       # XResolution
                struct.pack_into("<H", blk, 0x14, h)       # YResolution
                blk[0x16] = 8                              # XCharSize
                blk[0x17] = 16                             # YCharSize
                blk[0x18] = 1                              # planes
                blk[0x19] = 8                              # bpp
                blk[0x1B] = 4                              # memoryModel: packed
                struct.pack_into("<I", blk, 0x28, LFB_BASE)  # PhysBasePtr
                self.wr(es, di, bytes(blk))
                self.set(X86_REG_AX, 0x004F); self.cf(0); return
            if al == 0x02:  # 4F02: set mode -> ok
                self.set(X86_REG_AX, 0x004F); self.cf(0); return
            self.set(X86_REG_AX, 0x0100); self.cf(1); return
        self.cf(1); return

    def putch(self, ch):
        r, c = self.cursor
        if ch in (0x0D,):           c = 0
        elif ch in (0x0A,):         r = min(r + 1, 24)
        elif ch == 0x08:            c = max(c - 1, 0)
        else:
            if c >= 80: r, c = r + 1, 0
            if r < 25:
                self.screen[r*80 + c] = ch & 0x7F
                c += 1
                if c >= 80: r, c = r + 1, 0
        self.cursor = (r % 25, c % 80)

    def putstr(self, data, at=None, attr=None):
        if at is not None:
            r, c = at
            for ch in data:
                if ch in (0x0D, 0x0A, 0x08):
                    self.putch(ch)
                elif r < 25 and c < 80:
                    self.screen[r*80 + c] = ch & 0x7F
                    c += 1
            self.cursor = (r, c)
        else:
            for ch in data:
                self.putch(ch)

    # ---- int 16h ---------------------------------------------------------
    # key queue holds BIOS words (scan<<8|char).  plpbt dispatches on the
    # full word: ESC=0x011B, Ctrl-PgUp=0x8400 (next mode), Ctrl-PgDn=0x7600
    # (prev mode), Ctrl-A=0x1E01 (resident hotkey), letters on AL.
    SCAN = {'\x1b': 0x01, '\r': 0x1C, '\n': 0x1C,
            '1': 0x02, '2': 0x03, '3': 0x04, '4': 0x05, '5': 0x06,
            '6': 0x07, '7': 0x08, '8': 0x09, '9': 0x0A, '0': 0x0B,
            'q': 0x10, 'w': 0x11, 'e': 0x12, 'r': 0x13, 't': 0x14,
            'y': 0x15, 'u': 0x16, 'i': 0x17, 'o': 0x18, 'p': 0x19,
            'a': 0x1E, 's': 0x1F, 'd': 0x20, 'f': 0x21, 'g': 0x22,
            'h': 0x23, 'j': 0x24, 'k': 0x25, 'l': 0x26,
            'z': 0x2C, 'x': 0x2D, 'c': 0x2E, 'v': 0x2F, 'b': 0x30,
            'n': 0x31, 'm': 0x32,
            'up': 0x48, 'down': 0x50, 'left': 0x4B, 'right': 0x4D,
            'ctrl-pgup': 0x84, 'ctrl-pgdn': 0x76}

    def key_push(self, word):
        self.kbd.append(word & 0xFFFF)
        self.kbd_tail += 1

    def key_available(self):
        """True while unread key words remain in the queue."""
        return self.kbd_head < self.kbd_tail

    def key_flag_write(self, on):
        """Reflect queue availability into Plop's key-pending byte [0xB01B].
        The write is routed through Plop.key_flag_write (Bios has no base)."""
        if hasattr(self, "_kfw"):
            self._kfw(on)

    def int16(self):
        ah = self.reg(X86_REG_AX) >> 8
        if ah == 0x00 or ah == 0x10:      # read char
            if self.kbd_head >= self.kbd_tail:
                self.set(X86_REG_AX, 0)         # no key -> 0 (avoid stall)
                return
            k = self.kbd[self.kbd_head]
            self.kbd_head += 1
            self.set(X86_REG_AX, k)
            return
        if ah == 0x01 or ah == 0x11:      # peek
            if self.kbd_head >= self.kbd_tail:
                self.cf(1); self.set(X86_REG_AX, 0)
            else:
                self.cf(0); self.set(X86_REG_AX, self.kbd[self.kbd_head])
                # Plop only registers a key as "available" (its [0xB01B]
                # flag) when a peek finds one; and fire_irq0 does the same
                # on ticks.  Keep the two in sync: once the machine has
                # seen the key pending it may peek multiple times before
                # the AH=00 read - do not drop the flag early, only when
                # the queue is actually drained.
            return
        if ah == 0x02:      # shift flags
            self.set(X86_REG_AX, 0); return
        self.set(X86_REG_AX, 0)

    # ---- int 15h ---------------------------------------------------------
    def int15(self):
        ah = self.reg(X86_REG_AX) >> 8
        if ah == 0x24:      # A20 gate
            self.set(X86_REG_AX, 0); self.cf(0); return
        if ah == 0x88:      # ext memory (KB above 1MB)
            self.set(X86_REG_AX, 0x1000); self.cf(0); return
        if ah == 0xE801:    # large ext memory
            self.set(X86_REG_AX, 0); self.set(X86_REG_BX, 0); self.cf(0); return
        if ah == 0xC0:      # system descriptor
            self.cf(1); return
        if ah == 0x86:      # busy wait — return immediately (no delay)
            self.cf(1); return
        self.cf(1); self.set(X86_REG_AH, 0x86); return

    # ---- int 1Ah (RTC / time) --------------------------------------------
    def int1a(self):
        ah = self.reg(X86_REG_AX) >> 8
        if ah == 0xB1:      # PCI BIOS (used by the Plop USB modules for
                            # controller detection: B101 find, B103 class
                            # search, B108-B10A config r/w)
            self.pci_bios()
            return
        if ah in (0x00, 0x01):      # get/set RTC ticks
            self.ticks += 1
            self.set(X86_REG_CX, (self.ticks >> 16) & 0xFFFF)
            self.set(X86_REG_DX, self.ticks & 0xFFFF)
            self.cf(0); return
        self.cf(1); return

    # ---- PCI BIOS (int 1A, AH=B1) ----------------------------------------
    # Virtual PCI bus: one USB controller per Plop module, found by class
    # via B103 (ECX = class<<8|prog-if, SI = match index):
    #   dev2 = EHCI (0x0C0320, MMIO BAR0 0x10000000) - original device
    #   dev3 = UHCI (0x0C0300, I/O BAR at config 0x20 = 0xC000, PIIX4-style)
    #   dev4 = OHCI (0x0C0310, MMIO BAR0 0x10100000)
    # B101 (presence, EDX=" ICP"), B108-B10D config byte/word/dword r/w.
    PCI_BUS = 0x00
    PCI_DEVS = {                # dev -> (class dword @8, bar0 @0x10, bar4 @0x20)
        0x02: (0x000C0320, 0x10000000, 0x00000000),   # EHCI
        0x03: (0x000C0300, 0x00000000, 0x0000C001),   # UHCI (I/O BAR)
        0x04: (0x000C0310, 0x10100000, 0x00000000),   # OHCI
    }
    PCI_DEV = 0x02                  # default/legacy: the EHCI controller
    PCI_EHCI_BAR = 0x10000000       # memory-mapped EHCI register page
    PCI_OHCI_BAR = 0x10100000       # memory-mapped OHCI register page
    PCI_UHCI_IOBASE = 0xC000        # UHCI I/O register base
    def pci_bios(self):
        ax = self.reg(X86_REG_AX)
        al = ax & 0xFF
        if not hasattr(self, 'pci_log'):
            self.pci_log = []
        if al == 0x01:              # B101: PCI BIOS32 presence
            # returns: EDX = " ICP" (0x20494350), EBX = entry, AH=0, CF=0
            self.pci_log.append(('B101', 'ok'))
            self.set(X86_REG_AX, 0x0000)
            self.uc.reg_write(X86_REG_EDX, 0x20494350)   # full 32-bit
            self.set(X86_REG_BX, 0x0201)     # BH:BL = version 2.1
            self.set(X86_REG_CX, 0x0004)     # CL = last bus number
            self.cf(0)
            return
        if al == 0x03:              # B103: find PCI device by class
            # ECX[23:0]=class<<8|prog-if; SI=match index; returns BH=bus,
            # BL=dev<<3|fn, AH=0 success / AH=0x86 device not found
            want = self.reg(X86_REG_ECX) & 0xFFFFFF
            idx = self.reg(X86_REG_SI) & 0xFFFF
            matches = [d for d, (cls, _, _) in sorted(self.PCI_DEVS.items())
                       if cls == want]
            if idx < len(matches):
                self.pci_log.append(('B103', hex(want), idx, 'dev%02X' % matches[idx]))
                self.set(X86_REG_BX, (self.PCI_BUS << 8) | (matches[idx] << 3))
                self.set(X86_REG_AX, 0x0000)   # AH=0 success
                self.cf(0)
                return
            self.set(X86_REG_AH, 0x86)   # device not found
            self.cf(1)
            return
        if al in (0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D):   # B108-B10D: config r/w
            # BH=bus, BL=dev<<3|fn, DI=reg.
            bus = self.reg(X86_REG_BX) >> 8
            dev = (self.reg(X86_REG_BX) & 0xFF) >> 3
            if bus != self.PCI_BUS or dev not in self.PCI_DEVS:
                self.set(X86_REG_AH, 0x86); self.cf(1); return
            self.pci_dev = dev
            reg = self.reg(X86_REG_DI) & 0xFF
            if al == 0x08:          # read config byte -> CL
                self.set(X86_REG_CL, self.pci_cfg_byte(reg)); self.set(X86_REG_AX, 0); self.cf(0)
            elif al == 0x09:        # read config word -> CX
                self.set(X86_REG_CX, self.pci_cfg_word(reg)); self.set(X86_REG_AX, 0); self.cf(0)
            elif al == 0x0A:        # read config dword -> ECX
                self.uc.reg_write(X86_REG_ECX, self.pci_cfg_dword(reg))
                self.set(X86_REG_AX, 0); self.cf(0)
            elif al == 0x0B:        # write config byte (CL)
                self.pci_cfg_write(reg, self.reg(X86_REG_CL), 1); self.set(X86_REG_AX, 0); self.cf(0)
            elif al == 0x0C:        # write config word (CX)
                self.pci_cfg_write(reg, self.reg(X86_REG_CX), 2); self.set(X86_REG_AX, 0); self.cf(0)
            else:                   # B10D: write config dword (ECX)
                self.pci_cfg_write(reg, self.reg(X86_REG_ECX), 4); self.set(X86_REG_AX, 0); self.cf(0)
            return
        # B102 (find by id) / others: not found
        self.set(X86_REG_AH, 0x81); self.cf(1)

    def pci_cfg_byte(self, reg):
        return (self.pci_cfg_dword(reg) >> (8 * (reg & 3))) & 0xFF
    def pci_cfg_word(self, reg):
        return (self.pci_cfg_dword(reg & ~1) >> (8 * (reg & 2))) & 0xFFFF
    def pci_cfg_dword(self, reg):
        # minimal config space per virtual controller (see PCI_DEVS)
        r = reg & 0xFC
        dev = getattr(self, 'pci_dev', 0x02)
        if dev == 0x02:      # EHCI (legacy values, regression-locked)
            tbl = {
                0x00: 0x70208086,       # vendor 8086 device 7020 (PIIX4-family)
                0x04: 0x02800000,       # status/command
                0x08: 0x00000C03,       # class 0C03 (USB), prog-if 00
                0x10: self.PCI_EHCI_BAR,  # BAR0: MEMORY-mapped register page
                0x3C: 0x0000000B,       # int line 11
            }
        elif dev == 0x03:    # UHCI (PIIX4-style: I/O BAR at config 0x20)
            tbl = {
                0x00: 0x70208086,
                0x04: 0x02800000,
                0x08: 0x000C0300,
                0x20: self.PCI_UHCI_IOBASE | 1,   # I/O space BAR (bit0=1)
                0x3C: 0x0000000B,
            }
        else:                # OHCI
            tbl = {
                0x00: 0x70208086,
                0x04: 0x02800000,
                0x08: 0x000C0310,
                0x10: self.PCI_OHCI_BAR,  # BAR0: MEMORY-mapped register page
                0x3C: 0x0000000B,
            }
        return tbl.get(r, 0)
    def pci_cfg_write(self, reg, val, width):
        # the driver writes the command register (reg 4) to enable the
        # device (bus-master + IO); accept silently (state is virtual).
        pass

    # ---- main hook -------------------------------------------------------
    def on_intr(self, intno):
        """Called for every real-mode `int n`. intno == vector number."""
        self.int_trace.append((intno, self.reg(X86_REG_AX), self.reg(X86_REG_BX),
                               self.reg(X86_REG_CX), self.reg(X86_REG_DX),
                               self.reg(X86_REG_SI), self.reg(X86_REG_DI),
                               self.reg(X86_REG_CS), self.reg(X86_REG_IP)))
        # manual IVT dispatch: int 19/1A have no IVT override in plpbt
        if intno == 0x19:
            self.last_int19 = tuple(self.int_trace[-1])
            self.cf(0)
            raise Int19Reboot()
        # butterfly: int 0x13 may have been hooked by plpbt -> far-call IVT
        if intno == 0x13:
            v = self.uc.mem_read(4 * 0x13, 4)
            v_off, v_seg = struct.unpack("<HH", v)
            if (v_seg << 16 | v_off) != 0:     # a real handler is installed
                self.far_call(v_seg, v_off)
                return
        # otherwise: BIOS stub service
        if   intno == 0x13: self.int13()
        elif intno == 0xFE: self.int13()   # fake-BIOS chain trampoline (0xF100:0)
        elif intno == 0x10: self.int10()
        elif intno == 0x15: self.int15()
        elif intno == 0x16: self.int16()
        elif intno == 0x1A: self.int1a()
        else:
            # not a service we know: stop and let the caller inspect
            raise UnknownInt(intno, tuple(self.int_trace[-1]))

    def far_call(self, vcs, vip):
        """Simulate software-int far transfer to (vcs:vip); handler ends iret.
        Unicorn has already advanced IP past the int instruction — that is the
        return address.  Frame (low->high): ip, cs, flags."""
        uc = self.uc
        sp = self.reg(X86_REG_SP)
        ss = self.reg(X86_REG_SS)
        ip = self.reg(X86_REG_IP)
        cs = self.reg(X86_REG_CS)
        fl = self.reg(X86_REG_FLAGS) | 0x2          # bit1 always 1
        fl &= ~0x100                               # IF cleared during handler
        frame = struct.pack("<HHH", ip, cs, fl)
        self.wr(ss, sp - 6, frame)
        self.set(X86_REG_SP, (sp - 6) & 0xFFFF)
        self.set(X86_REG_CS, vcs)
        self.set(X86_REG_IP, vip)


class Int19Reboot(Exception):
    pass


class UnknownInt(Exception):
    def __init__(self, intno, t):
        self.intno = intno
        self.t = t
        super().__init__("int %02Xh at CS:IP=%04X:%04X (ax=%04X bx=%04X cx=%04X dx=%04X si=%04X di=%04X)"
                         % (intno, t[7], t[8], t[1], t[2], t[3], t[4], t[5], t[6]))


# -------------------------------------------------------------------- machine
class Plop:
    def __init__(self, **kw):
        self.mode   = kw.get("mode", "raw")
        self.load_seg  = kw.get("load_seg", 0x3000)
        self.img_off   = kw.get("img_off", 0x100)   # file offset 0 sits at CS:0x100
        if self.mode == "bzimage" and kw.get("entry") is None:
            self.entry = 0x200            # bzImage setup entry (file 0x200)
        else:
            self.entry = kw.get("entry", 0x9BE)   # CS offset == file 0x8BE
        self.edd_type  = kw.get("edd_type", "ATA")
        # virtual USB device visibility per controller (tests use
        # usb_uhci_dev=False to make the UHCI module's test fail cleanly so
        # the 'u' install loop proceeds to the OHCI round)
        self.usb_uhci_dev = kw.get("usb_uhci_dev", True)
        self.usb_ohci_dev = kw.get("usb_ohci_dev", True)
        self.resident  = kw.get("resident", False)
        self.keys      = kw.get("keys", b"")
        self.max_insns = kw.get("max_insns", 200_000_000)
        self.trace     = kw.get("trace")
        # deprecated experiments, kept as accepted no-ops (obsolete since the
        # +0x100 load-layout fix: the real descriptor/table data is in the file)
        for dead in ("alloc_size", "preset_window"):
            if kw.get(dead):
                print("note: %s is a no-op since the +0x100 load fix" % dead)
        # virtual timer knobs
        self.tick_insns    = kw.get("tick_insns", 0)     # fire IRQ0 every N insns (0=off)
        self.feed_watchdog = kw.get("feed_watchdog", False)  # re-arm [0xb6e8]=3 each tick
        self.text_mode     = kw.get("text_mode", False)  # force [0xB018]=0xFFFF at file 0xB04
        self.ticks_fired   = 0
        self.in_hook       = False
        self.in_irq0       = False   # set while an IRQ0 far-call is being serviced
                                     # at guest level (cleared at the handler's
                                     # IRET, cs offset 0x673D) - no nested ticks
        self.hook_extra    = kw.get("hook_extra")   # optional fn(uc, cs_off) per insn
        self.data = open(BIN, "rb").read()
        self.uc = Uc(UC_ARCH_X86, UC_MODE_16)
        self.uc.mem_map(0, 0x8000000)             # 128MB: conv + HMA + extended
        # virtual EHCI register page (the Plop modules find the controller via
        # int1A PCI BIOS, take BAR0 as MMIO base and drive the registers with
        # fs:[...] flat-window accesses; see DRIVERS.md "EHCI register init").
        self.uc.mem_map(Bios.PCI_EHCI_BAR, 0x1000)
        # virtual OHCI register page (dev4: class 0x0C0310, BAR0 MMIO)
        self.uc.mem_map(Bios.PCI_OHCI_BAR, 0x1000)
        oreg = bytearray(0x1000)
        oreg[0x00] = 0x10                          # HcRevision = 0x10 (OHCI 1.0)
        oreg[0x48:0x4C] = struct.pack("<I", 0x00000002)  # HcRhDescriptorA: NDP=2
        oreg[0x4C:0x50] = struct.pack("<I", 0x00000000)  # HcRhDescriptorB
        self.uc.mem_write(Bios.PCI_OHCI_BAR, bytes(oreg))
        bar = Bios.PCI_EHCI_BAR
        reg = bytearray(0x1000)
        reg[0x00] = 0x10                          # CAPLENGTH (op regs at +0x10)
        reg[0x02:0x04] = b"\x10\x01"              # HCI version 1.10
        reg[0x04:0x08] = struct.pack("<I", 0x00010002)  # HCSPARAMS: 2 ports, PPC
        reg[0x08:0x0C] = struct.pack("<I", 0)     # HCCPARAMS (0 keeps the
                                                  #  module's +8 loop skipped)
        self.uc.mem_write(bar, bytes(reg))
        self.bios = Bios(self.uc, edd_type=self.edd_type, keys=self.keys)
        self.bios.uhci_attached = self.usb_uhci_dev
        self.bios.ohci_attached = self.usb_ohci_dev
        self.bios._kfw = lambda on: self.key_flag_write(on)
        import io
        self.trace_f = open(OUT + "/trace.log", "w") if self.trace else io.StringIO()

        # image at CS:0x100; BSS follows to CS:0xF8CF; stack top CS:0xFFFE
        base = self.load_seg << 4
        self.base = base
        data = bytearray(self.data)
        # ---- patch: Unicorn can't execute ANY 'mov fs,<sel>' while CR0.PE=1
        # (raises #GP on the segment load itself, regardless of selector).
        # The excursion builds a runtime GDT whose entry-1 is a FLAT (base 0)
        # window (verified live: the fw zero-loops EDI=0x200000 len 0x3C0000
        # and reads the image base ptr from 0x9000:0x228) -- fs:[edi] uses
        # true linear addresses.  Unicorn's real-mode rule linear=FS<<4+EDI
        # gives that with FS=0, so preset FS=0 at machine start and NOP the
        # loads.  AL (CR0 low byte) stays untouched for the cr0 rewrite.
        self.fsseg = 0                        # flat window: fs:[edi] == [edi]
        for off in (0x464E, 0x57F7, 0x59F9):
            assert data[off:off+2] == bytes([0x8E, 0xE3]), hex(off)
            data[off:off+2] = b"\x90\x90"
        self.patches = ["A20/PM fs-window mov-fs->nop (FS preset=0 flat)"]
        if self.mode == "bzimage":
            # bootloader contract (syslinux / qemu -kernel): setup region
            # (file 0x000-0x9FF) at 0x9000:0, payload (file 0xA00..) at
            # 0x1000:0 — the real file size is used despite syssize=0.
            # plpbt's own setup (file 0x250) reassembles the +0x100 layout
            # at CS=0x5000 (file X -> 0x5000:X+0x100) and retf's to 0x5000:0x100.
            self.uc.mem_write(0x9000 * 16, bytes(data[:0xA00]))
            self.uc.mem_write(0x1000 * 16, bytes(data[0xA00:]))
        else:
            self.uc.mem_write(base + self.img_off, bytes(data))
        if self.mode == "bzimage":
            # reassembled image lives at CS=0x5000: BSS/dumps/probes must
            # read from there, not the raw-layout load_seg base
            self.base = 0x50000
        # loader convention: 0x9000:0x228 = image linear load base (the 0x888
        # flat self-check reads its EDI from es:[0x228] with es=0x9000)
        self.uc.mem_write(0x9000 * 16 + 0x228, struct.pack("<I", base + self.img_off))
        # IVT preset: int 13h -> bios (vector 0x4C unused marker 0); our hook
        # services ints before plpbt installs; after install vector points at
        # the hook segment and we far-call it.
        self.uc.mem_write(0x4C, struct.pack("<HH", 0x0000, 0x0000))
        # fake "old BIOS" int13 chain target for the Plop driver: trampoline
        # at 0xF100:0000 = `int 0xFE; retf 2` — on_intr services 0xFE in place
        # as int13 (live flags carry CF/AX), and retf 2 consumes the flags
        # word that an int-style far-call frame leaves below [ip][cs].  This
        # balances both callers: our int13 far-call frame AND the driver's
        # pushf + call far [old vector] chain.
        self.uc.mem_write(0xF1000, b"\xcd\xfe\xca\x02\x00")
        self.uc.mem_write(0x4C, struct.pack("<HH", 0x0000, 0xF100))
        # IVT[0] watchdog sled (SeaBIOS): when the IRQ0 handler's watchdog
        # expires it does `ljmp 0:0`, which on real HW lands on the IVT bytes
        # 53 ff 00 f0 (x2) + c3 = push bx / inc [bx+si] / add [bx+si],dh /
        # push bx / inc / ret -- the ret pops the ljmp frame and returns into
        # the interrupt frame, i.e. harmless absorption (verified on QEMU,
        # DYNAMIC_FINDINGS s7.2).  Without the sled the zeros spin at 0:0.
        sled = b"\x53\xff\x00\xf0\x53\xff\x00\xf0\xc3"
        self.uc.mem_write(0, sled)
        self.uc.mem_write(0x40C, struct.pack("<HH", 0x0000, 0xF000))
        # BDA: conventional mem size 640K @ 0:0x413, EBDA seg/warm flag
        self.uc.mem_write(0x413, struct.pack("<H", 640))
        self.uc.mem_write(0x40E, struct.pack("<H", 0x9FC0))
        self.uc.mem_write(0x472, struct.pack("<H", 0x1234))
        # resident-mode flag [0xB07C] preset (BSS, set by external MBR bootstrap)
        if self.resident:
            self.uc.mem_write(base + 0xB07C, b"\x01")

    def regs(self):
        u = self.uc
        v = [("AX", u.reg_read(X86_REG_AX)), ("BX", u.reg_read(X86_REG_BX)),
             ("CX", u.reg_read(X86_REG_CX)), ("DX", u.reg_read(X86_REG_DX)),
             ("SI", u.reg_read(X86_REG_SI)), ("DI", u.reg_read(X86_REG_DI)),
             ("BP", u.reg_read(X86_REG_BP)), ("SP", u.reg_read(X86_REG_SP)),
             ("DS", u.reg_read(X86_REG_DS)), ("ES", u.reg_read(X86_REG_ES)),
             ("SS", u.reg_read(X86_REG_SS)), ("CS", u.reg_read(X86_REG_CS)),
             ("IP", u.reg_read(X86_REG_IP)),
             ("EAX", u.reg_read(X86_REG_EAX)), ("EBX", u.reg_read(X86_REG_EBX)),
             ("ECX", u.reg_read(X86_REG_ECX)), ("EDX", u.reg_read(X86_REG_EDX)),
             ("ESI", u.reg_read(X86_REG_ESI)), ("EDI", u.reg_read(X86_REG_EDI))]
        return " ".join("%s=%08X" % (n, x) for n, x in v)

    def key_available(self):
        """True while unread key words remain in the queue."""
        return self.bios.key_available()

    def key_flag_write(self, on):
        """Write Plop's key-pending flag [0xB01B] at the image base."""
        self.uc.mem_write(self.base + 0xB01B, b"\x01" if on else b"\x00")

    def fire_irq0(self):
        """One virtual PIT tick: far-call the IRQ0 handler from IVT[8].
        Skipped while another hook/int service is in flight (the periodic
        hook_code tick used to re-enter the machine mid-handler, corrupting
        the int13/int10 services' registers - the ticks must never nest),
        or before sub_65BA installed the vector (IVT[8] == 0:0)."""
        if self.in_hook or self.bios.in_service or self.in_irq0:
            return False
        v = bytes(self.uc.mem_read(0x20, 4))
        off, seg = struct.unpack("<HH", v)
        if seg == 0 and off == 0:
            return False
        self.in_hook = True
        self.in_irq0 = True          # until the handler iret's at cs 0x673D
        try:
            self.bios.far_call(seg, off)
            self.ticks_fired += 1
            # BDA tick counter 0x40:0x6C: on real hardware the BIOS owns
            # IRQ0 and bumps this ~18.2Hz; Plop's own handler doesn't.  The
            # USB modules' tick delays (sub_56AC: cmp al,es:[0x6C]/je spin,
            # used for port-reset waits) hang forever without it.
            t = int.from_bytes(self.uc.mem_read(0x46C, 4), "little")
            self.uc.mem_write(0x46C, struct.pack("<I", (t + 1) & 0xFFFFFFFF))
            # UHCI has no doorbell: the controller runs its schedule with
            # time.  The driver's completion wait (sub_31B1) scans TD memory
            # for Active bits without touching any port, so the engine must
            # advance from the tick, not from USBSTS polls alone.
            if self.bios.uhci_cmd & 1 and self.bios.uhci_frbase:
                self.bios.uhci_advance()
            # OHCI: advance too (the WDH poll in the driver drives it, but a
            # tick keeps the schedule moving when the guest is between polls)
            if self.bios.ohci_ctrl & 0x10 and self.bios.ohci_ctrl_head:
                self.bios.ohci_advance()
        finally:
            self.in_hook = False
        return True

    def run(self):
        u = self.uc
        base = self.base                            # hook range = execution segment
        img_off = self.img_off
        start_base = base
        if self.mode == "bzimage":
            start_base = 0x9000 << 4                # emu_start = setup entry copy
        start = start_base + self.entry
        seg = 0x9000 if self.mode == "bzimage" else self.load_seg
        u.reg_write(X86_REG_CS, seg)
        u.reg_write(X86_REG_IP, self.entry)
        u.reg_write(X86_REG_DS, seg)
        u.reg_write(X86_REG_ES, seg)
        u.reg_write(X86_REG_SS, seg)
        u.reg_write(X86_REG_FS, self.fsseg)      # flat window: FS<<4 == CS<<4
        u.reg_write(X86_REG_SP, 0xFFFE)
        u.reg_write(X86_REG_DL, 0x80)
        u.reg_write(X86_REG_FLAGS, 0x0002)

        def hook_intr(uc, intno, ud):
            self.bios.in_service += 1
            self.in_hook = True
            try:
                self.bios.on_intr(intno)
            except Int19Reboot:
                self.in_hook = False
                self.bios.in_service -= 1
                raise UcError(UC_ERR_EXCEPTION)
            finally:
                self.bios.in_service -= 1
                self.in_hook = False

        text_done = [not self.text_mode]
        insns = [0]
        extra = self.hook_extra
        # execution windows: raw = load_seg (0x3000) segment plus the int13
        # hookseg the USB modules install to (EBDA-derived, ~0x9A70:0x100);
        # bzImage = the setup copy at 0x9000:0 then the reassembled image at
        # 0x5000:0x100.  Hook all of them so hook_code sees every guest code.
        if self.mode == "bzimage":
            hook_begin, hook_end = 0x50000, 0xA0000
        else:
            hook_begin, hook_end = base, 0xA0000
        def hook_code(uc, addr, size, ud):
            if addr < hook_begin or addr >= hook_end:
                return
            if addr >= 0x90000 and self.mode != "bzimage":
                cs_off = addr - 0x90000          # hookseg region (module code)
                img_base = base
            elif self.mode == "bzimage":
                # image runs at 0x5000 after the setup's reassembly (setup
                # itself at 0x9000 is only the first ~0x350 bytes) - express
                # cs_off against the 0x5000 image segment so milestones,
                # the IRQ0-iret clear and the text-mode patch see the same
                # offsets raw mode sees against 0x3000.
                if 0x50000 <= addr < 0x60000:
                    cs_off = addr - 0x50000
                elif 0x90000 <= addr < 0x90350:
                    cs_off = addr - 0x90000 + 0x100   # setup region
                else:
                    return
                img_base = 0x50000
            else:
                cs_off = addr - base
                img_base = base
            if self.mode == "bzimage":
                img_base = 0x50000
            if self.trace:
                off = cs_off - img_off
                if 0 <= off < len(self.data):
                    self.trace_f.write("%04X\n" % off)
            if extra is not None:
                extra(uc, cs_off)
            if cs_off == 0x673D:                  # the IRQ0 handler's IRET
                self.in_irq0 = False              #   -> ticks may fire again
                if self.feed_watchdog:
                    # re-arm AFTER the handler's dec (it decs [0xB6E8] each
                    # tick; arming before the far-call raced the dec and the
                    # first tick still ljmpped)
                    uc.mem_write(img_base + 0xB6E8, b"\x03")
            if not text_done[0] and cs_off == 0x0C04:   # file 0xB04, after sub_5B9E
                uc.mem_write(img_base + 0xB018, b"\xff\xff")
                text_done[0] = True
            if self.tick_insns:
                insns[0] += 1
                if insns[0] >= self.tick_insns:
                    insns[0] = 0
                    self.fire_irq0()
            if size == 1 and uc.mem_read(addr, 1)[0] == 0xF4:   # hlt -> tick
                uc.reg_write(X86_REG_EIP, cs_off + 1)   # skip the hlt
                self.fire_irq0()

        u.hook_add(UC_HOOK_INTR, hook_intr)
        u.hook_add(UC_HOOK_CODE, hook_code, begin=hook_begin, end=hook_end)
        # ---- port I/O (UHCI controller window) -----------------------------
        # NOTE: this unicorn build registers UC_HOOK_INSN callbacks but never
        # fires them (verified in isolation), so port semantics are done with
        # per-site UC_HOOK_CODE hooks on the UHCI module's in/out instructions
        # (runtime listing coords 0x2434..0x2DF4, see DRIVERS.md 6.6).  Each
        # hook validates the opcode actually at CS:IP (the same ip hosts other
        # code during the EHCI/OHCI rounds) and the DX port window, answers
        # the access and skips the 1-2 byte instruction.
        uhci_sites = (0x2434, 0x2704, 0x2CFF, 0x2DCD, 0x2DD3, 0x2DD9,
                      0x2DDF, 0x2DE5, 0x2DEB, 0x2DF4, 0x2D90, 0x2D9E)
        uhci_base_lin = 0x9A800          # hookseg ip 0x100
        for site in uhci_sites:
            s_lin = uhci_base_lin + (site - 0x2353)
            u.hook_add(UC_HOOK_CODE, self.bios.uhci_io_hook, begin=s_lin, end=s_lin)
        # ---- EHCI MMIO register semantics ---------------------------------
        # Modeled at READ time (mem-write hooks cannot suppress the guest's
        # write; a read hook fires before the load, so we materialize the
        # modeled register value in RAM and let the guest read it):
        #   * USBCMD.HCReset (bit1) always reads 0 (self-cleared, sub_51D4)
        #   * USBSTS.HCHalted (bit12) = !USBCMD.RUN (sub_5244 spins on it)
        #   * PORTSC reads as CCS|PED|PP (fake high-speed device, sub 5110+).
        #     The module keeps the PORTSC address in [0x2B53] = op+0x40
        #     (0x10000050, measured live); op+0x44 is the spec position and
        #     op+0x24 was the old stub guess - model all three.
        bar = Bios.PCI_EHCI_BAR
        op_usbcmd  = bar + 0x10 + 0x00       # op base = BAR + CAPLENGTH(0x10)
        op_usbsts  = bar + 0x10 + 0x04
        portscs    = (bar + 0x10 + 0x24, bar + 0x10 + 0x40, bar + 0x10 + 0x44)
        self.uc.mem_write(op_usbsts, struct.pack("<I", 0x00001000))
        def hook_mmio_read(uc, access, address, size, value, ud):
            if address == op_usbcmd:
                v = struct.unpack("<I", uc.mem_read(address, 4))[0] & ~2
                uc.mem_write(address, struct.pack("<I", v))
            elif address == op_usbsts:
                cmd = struct.unpack("<I", uc.mem_read(op_usbcmd, 4))[0]
                halted = 0x1000 if not (cmd & 1) else 0   # !RUN -> HCHalted
                uc.mem_write(address,
                             struct.pack("<I", halted | self.bios.usb_irq))
            elif address in portscs:
                # CCS|PED|PP; PR(bit8)/status-change bits self-clear, so the
                # presented value never shows them
                uc.mem_write(address, struct.pack("<I", 0x00001005))
            return False
        def hook_mmio_write(uc, access, address, size, value, ud):
            if address == op_usbsts:
                # W1C: guest writes 1s to ack raised status bits
                self.bios.usb_irq &= ~value & 0xFFFF
            elif address == op_usbcmd and value & 0x24:
                # IAAD doorbell / async-schedule enable: the virtual
                # controller processes the pending qTDs now (sub_54A9
                # rings 0x20; the driver also arms 0x04)
                self.bios.usb_process_async()
            return True
        if self.mode != "bzimage":       # bz never touches the EHCI page;
            for a in (op_usbcmd, op_usbsts) + portscs:   # 10 hooks registered
                u.hook_add(UC_HOOK_MEM_READ, hook_mmio_read, begin=a, end=a)
                u.hook_add(UC_HOOK_MEM_WRITE, hook_mmio_write, begin=a, end=a)

        # ---- OHCI MMIO register semantics (BAR 0x10100000) -----------------
        # Same read-materialize / write-capture model as the EHCI page.  The
        # doorbell is HcCommandStatus.CLF/BLF; completion waits poll
        # HcInterruptStatus.WDH (sub_4264) - the read hook advances the ED
        # chain and raises WDH, the guest acks with a W1C write.
        obar = Bios.PCI_OHCI_BAR
        o_regs = tuple(obar + off for off in Bios.OHCI_REGS)
        def hook_ohci_read(uc, access, address, size, value, ud):
            self.bios.ohci_read_model(address - obar, address)
            return False
        def hook_ohci_write(uc, access, address, size, value, ud):
            self.bios.ohci_write_model(address - obar, value)
            return True
        if self.mode != "bzimage":
            for a in o_regs:
                u.hook_add(UC_HOOK_MEM_READ, hook_ohci_read, begin=a, end=a)
                u.hook_add(UC_HOOK_MEM_WRITE, hook_ohci_write, begin=a, end=a)
        try:
            u.emu_start(start, 0xFFFFFFFF, count=self.max_insns, timeout=0)
            if self.trace:
                self.trace_f.close()
            return "end (ticks=%d)" % self.ticks_fired
        except UcError as e:
            err = str(e)
            regs = self.regs()
            if self.trace:
                self.trace_f.close()
            if "EXCEPTION" in err.upper():
                if self.bios.last_int19:
                    return "int19 " + regs
                return "exception " + regs
            return "uc_error " + err + " " + regs
        except UnknownInt as e:
            if self.trace:
                self.trace_f.close()
            return "unknown_int: %s | %s" % (e, self.regs())

    def dump_screen(self):
        lines = []
        for r in range(25):
            row = self.bios.screen[r*80:(r+1)*80]
            lines.append("".join(chr(c) if 32 <= c < 127 else "." for c in row).rstrip(" ."))
        return "\n".join(lines).strip("\n")

    # ---- VBE GUI framebuffer helpers --------------------------------------
    def lfb_params(self):
        u = self.uc
        w = struct.unpack("<H", bytes(u.mem_read(self.base + 0xB014, 2)))[0]
        h = struct.unpack("<H", bytes(u.mem_read(self.base + 0xB016, 2)))[0]
        if not (0 < w <= 2048 and 0 < h <= 2048):
            w, h = 640, 480
        return w, h

    def lfb_data(self):
        w, h = self.lfb_params()
        return bytes(self.uc.mem_read(LFB_BASE, w * h)), w, h

    def lfb_png(self, path):
        """Grayscale PNG dump of the VBE LFB (pure zlib, no PIL)."""
        px, w, h = self.lfb_data()
        raw = b"".join(b"\x00" + px[y*w:(y+1)*w] for y in range(h))
        def chunk(tag, payload):
            c = struct.pack("<I", len(payload)) + tag + payload
            return c + struct.pack("<I", zlib.crc32(tag + payload) & 0xFFFFFFFF)
        png = (b"\x89PNG\r\n\x1a\n"
               + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 0, 0, 0, 0))
               + chunk(b"IDAT", zlib.compress(raw, 6))
               + chunk(b"IEND", b""))
        open(path, "wb").write(png)
        return path

    def lfb_text(self):
        """Decode the synthetic bar-font from the LFB into ASCII lines.
        glyph c = bars for bits 0..6 of c in rows 1..7 (see int10 0x1130)."""
        px, w, h = self.lfb_data()
        cols, rows = w // 8, h // 8
        out = []
        for gy in range(rows):
            line = []
            for gx in range(cols):
                c = 0
                for r in range(1, 8):
                    v = px[gy*8*w + gx*8 + r*w]
                    if v != 0:
                        c |= 1 << (r - 1)
                line.append(chr(c) if 32 <= c < 127 else " ")
            out.append("".join(line).rstrip())
        return "\n".join(out)

    def dump_bss(self, start=0xAB3B, end=0xABF0):
        base = self.base
        return bytes(self.uc.mem_read(base + start, end - start)).hex(" ")

    def dump_ivt(self):
        return bytes(self.uc.mem_read(0, 0x100)).hex(" ")

    # named BSS vars from REPORT.md §7 / DRIVERS.md
    BSS_VARS = [
        ("AB37", "saved loader SS", 2, "H"),
        ("AB39", "saved loader SP", 2, "H"),
        ("AB4B", "data segment", 2, "H"),
        ("AB51", "boot drive DL", 1, "B"),
        ("A1A8", "A20 method", 1, "B"),
        ("B018", "current VBE mode", 2, "H"),
        ("B062", "device name table dst", 2, "H"),
        ("B075", "disk-found bitmap", 1, "B"),
        ("B07C", "MBR-resident flag", 1, "B"),
        ("B6E8", "int13 hook flag [0xB6E9]", 1, "B"),
        ("B6F8", "install drive DL", 1, "B"),
        ("CF43", "disk count", 2, "H"),
        ("CF44", "USB disk count", 2, "H"),
        ("CF5B", "hook module seg", 2, "H"),
        ("E08A", "saved int13 vector", 4, "I"),
    ]

    def bss_report(self):
        base = self.base
        out = ["--- BSS vars ---"]
        for off, name, size, fmt in self.BSS_VARS:
            raw = bytes(self.uc.mem_read(base + int(off, 16), size))
            if fmt == "H":
                v = struct.unpack("<H", raw)[0]
            elif fmt == "B":
                v = raw[0]
            else:
                v = struct.unpack("<I", raw)[0]
            out.append("  [%s] %-22s = 0x%04X" % (off, name, v))
        ivt13 = bytes(self.uc.mem_read(0x4C, 4))
        cs13, ip13 = struct.unpack("<HH", ivt13)
        out.append("  IVT  0:0x4C (int13)    = %04X:%04X" % (cs13, ip13))
        dseg = base >> 4
        blob = bytes(self.uc.mem_read(dseg * 16 + 0x100, 16))
        out.append("  CS:0x100 (file 0)       = %s" % blob.hex(" "))
        return "\n".join(out)


def default_disk():
    """8MB virtual disk: MBR (active part 1 @LBA63) + tiny boot sector there."""
    disk = bytearray(8 * 1024 * 1024)
    mbr = bytearray(512)
    mbr[446] = 0x80
    mbr[447:450] = bytes([0, 1, 1])
    mbr[450] = 0x06
    mbr[451:454] = bytes([15, 63, 63])
    mbr[454:458] = struct.pack("<I", 63)
    mbr[458:462] = struct.pack("<I", 1022)
    mbr[510:512] = b"\x55\xAA"
    disk[0:512] = mbr
    pbs = bytearray(512)
    pbs[0] = 0xEA; pbs[1:5] = bytes([0x00, 0x00, 0x00, 0x00])  # jmp 0:0x7C00
    pbs[510:512] = b"\x55\xAA"
    disk[63*512:(63*512)+512] = pbs
    return bytes(disk)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["raw", "bzimage"], default="raw")
    ap.add_argument("--edd", choices=["ATA", "USBD"], default="ATA")
    ap.add_argument("--resident", action="store_true")
    ap.add_argument("--text-mode", action="store_true",
                    help="force [0xB018]=0xFFFF at file 0xB04 (skip VBE fill path)")
    ap.add_argument("--tick-insns", type=int, default=0,
                    help="also fire one IRQ0 tick every N instructions (0=off; "
                         "hlt already fires one tick each)")
    ap.add_argument("--feed-watchdog", action="store_true",
                    help="re-arm the IRQ0 handler watchdog [0xb6e8]=3 on every "
                         "tick (nothing in the image re-arms it; without this "
                         "the 3rd tick does ljmp 0:0)")
    ap.add_argument("--keys", default="")
    ap.add_argument("--trace", action="store_true")
    ap.add_argument("--max-insns", type=int, default=200_000_000)
    ap.add_argument("--screen", action="store_true")
    ap.add_argument("--bss", action="store_true")
    ap.add_argument("--ivt", action="store_true")
    ap.add_argument("--flow", action="store_true")     # match int trace vs static map
    a = ap.parse_args()

    # bz mode reassembles the image itself (setup->0x5000); load_seg must
    # stay 0x3000 so self.base keeps the +0x100 model coordinates - a
    # load_seg=0x9000 broke base-relative wiring (watchdog feed, BSS dumps)
    # and crashed the setup handoff at 0x5000:0xB018 (ticks=0, ints=0).
    seg, entry = (0x3000, 0x9BE) if a.mode == "raw" else (0x3000, 0x200)
    p = Plop(mode=a.mode, load_seg=seg, entry=entry, edd_type=a.edd, resident=a.resident,
             text_mode=a.text_mode, tick_insns=a.tick_insns,
             feed_watchdog=a.feed_watchdog,
             keys=a.keys, trace=a.trace, max_insns=a.max_insns)

    # 8MB virtual disk (see default_disk)
    p.bios.disk_attach(default_disk())

    r = p.run()
    print("run:", r)
    if p.bios.disk_writes:
        wb = b"".join(p.bios.disk[lba*512:lba*512+n] for lba, n in p.bios.disk_writes)
        with open(os.path.join(OUT, "disk_writeback.bin"), "wb") as f:
            f.write(wb)
        print("disk writes: %s -> out/disk_writeback.bin (%d B)"
              % (p.bios.disk_writes, len(wb)))
    if a.screen: print("--- screen ---\n" + p.dump_screen())
    if a.bss:    print("--- bss 0xAB3B..0xABF0 ---\n" + p.dump_bss())
    if a.ivt:    print("--- ivt 0..0x100 ---\n" + p.dump_ivt())
    print(p.bss_report())
    ints = p.bios.int_trace
    print("--- int trace (%d) ---" % len(ints))
    shown = 0
    for i, (n, ax, bx, cx, dx, si, di, cs, ip) in enumerate(ints):
        tag = {0x10: "video", 0x13: "disk", 0x15: "sys", 0x16: "kbd",
               0x19: "reboot", 0x1A: "rtc", 0xFE: "bios13"}.get(n, "exc?")
        print("%5d  int %02Xh %-6s from %04X:%04X ax=%04X bx=%04X cx=%04X dx=%04X si=%04X di=%04X"
              % (i, n, tag, cs, ip, ax, bx, cx, dx, si, di))
        shown += 1
        if shown > 120: print("... (%d more)" % (len(ints) - shown)); break


if __name__ == "__main__":
    main()