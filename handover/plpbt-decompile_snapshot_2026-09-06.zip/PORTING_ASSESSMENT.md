# PBM USB 驱动移植到 grub4dos 的可行性评估

> 结论先行：**可行，且这条路的"挂接模式"在 grub4dos 里已经有现成先例**——
> 这棵 0.4.6a 树（chenall/grub4dos）自带第三方 USB 驱动 `USB2DRI`，
> 它与 Plop 驱动是同构架构。移植工作 = 沿用同一挂接模式，把驱动内核换成 Plop 的。
> 依据：`REPORT.md` / `DRIVERS.md`（Plop 侧）+ `grub4dos/stage2/asm.S`、`builtins.c`（grub4dos 侧）。

---

## 1. grub4dos 侧现状（D:\repo\grub4dos）

### 1.1 已有 USB 驱动 `USB2DRI`（asm.S，~17000 行文件内的嵌入模块）

| 挂接点 | 位置 | 说明 |
|---|---|---|
| 命令入口 | `builtins.c:15007 usb_func` | `usb --init`：调 `init_usb()`，读回 `usb_drive_num[]`，把盘注册进 `fd_geom/hd_geom/cdrom_drive`；错误码 0x80=无 PCI BIOS32、0x81=枚举失败、0x82=设备未就绪 |
| 初始化 | `asm.S:8019 init_usb` | `.code32` → `prot_to_real` → **`lcall` 到 USB2DRI 段**（16 位实模式）→ 返回后 `real_to_prot` |
| 驱动本体 | `asm.S USB2DRI` | 16 位实模式；`Register_pci` + `bus_device_function` 经 **INT 1Ah PCI BIOS32** 枚举控制器；自带 CBW 结构体（源码字段名 `dCBWSignature/dCBWTag/CBWCB`、`qh` 传输结构）= **BOT 大容量存储栈**；内嵌 GDT 做 PM 数据搬运 |
| int 13h 挂钩 | asm.S ~16567–16754 | 保存原向量到 `old_int13`、写 `0:0x4C`，与 grub4dos 自己的 `int13_handler`（签名 `$INT13SFGRUB4DOS`，`ROM_int13` 链）并存 |
| BDA 操作 | `usb_func` 中 `0x410`/`0x475` 读 | 驱动**修改 BDA 软/硬盘计数**把 USB 盘注册成"BIOS 盘"，`usb --init` 前后对比计数得知新增盘号 |

### 1.2 关键判断

**USB2DRI 与 Plop 驱动架构同构**：16 位实模式内核 + int 13h 服务界面 + 盘号映射 + BDA 修改 +
保存原向量 + PM 短暂切换（Plop 用 FS 平坦选择子，USB2DRI 用自带 GDT）。
=> "在 grub4dos 里挂一个实模式 USB 栈"这个问题已经被 USB2DRI 的存在**回答过了**；
PBM 移植是工程集成问题，不是架构研究问题。

## 2. Plop 侧可用的资产（来自本项目静态逆向）

| 资产 | 内容 | 用于 |
|---|---|---|
| 安装协议 | `0x8442` 安装（blob→CS:0x100，IVT 0:0x4C）、`eax='PoLP',ebp='TINI'/'TIUQ'` 魔数命令、钩子标志 `[0xB6E9]` | 装载/卸载胶水 |
| 初始化入口 | `0x8BE`（清 BSS、建栈、存盘号 DL）+ 每盘安装函数 `0x84A6`（`[0xB6F8]=dl`） | 最小化初始化序列（不需跑 UI） |
| 盘发现结果 | 磁盘位图 `[0xB075]`、盘计数 `[0xCF43]/[0xCF44]`、虚拟盘号槽 `cs:[0x104]` | 注册进 grub4dos geom 表 |
| 驱动栈本体 | 3×USB BOT blob（'USBC' 签名）+ 1×ATAPI CDROM blob + 常驻重定向器（0x5860，[0x104]↔0x80 映射） | 驱动内核 |
| 卸载 | `'TIUQ'` 命令 + `0x840E`（BDA/EBDA 还原） | grub4dos 引导 OS 前清理 |

**动态阶段补充（2026-09-04，DYNAMIC_FINDINGS §9.8-9.11）**：三模块传输语义
全部实测闭环——EHCI qTD/QH 引擎（门铃 USBCMD|=0x20 + USBSTS.USBINT 应答）、
UHCI 端口/TD/帧表引擎（I/O 基址 BAR0@cfg20，轮询 USBSTS.USBINT，TD 32B
0x20 步长）、OHCI ED/TD 引擎（MMIO BAR0，门铃 CLF/BLF + WDH 轮询，TD/ED
16B）。三模块共享 BOT 尾部（CBW tag 0x74354045、'USBC' 帧、SCSI 0x12/0x25/
0x28/0x2A）与 int13 AH=0x99 分发（AL 1..9）；安装循环"首个测试成功模块获胜"
（类码 0x0C0300/0x0C0310/0x0C0320）。路线 B（干净重写）所需的控制器语义细节
现已在 DRIVERS.md §6.6/§6.7/§6.8 齐备。

## 3. 移植方案

### 路线 A：blob 包装（二进制复用，推荐先行）

1. `builtins.c` 新增命令（如 `plopdrv --init`，或扩展 `usb` 命令加后端参数）。
2. `asm.S` 新增 16 位胶水：`prot_to_real` → 把 plpbt.bin（43,575B）载入选定的 64KB 段
   → 走最小初始化（复制 `0x8BE` 入口的序言：清 BSS `0xAB3B..0xF8CF`、设栈、DL=目标盘号）
   → 调安装路径（`0x8442`/`0x84A6`，或直接发 'PoLP'/'TINI' 魔数 int 13h）→ 返回。
3. 读 `[0xCF43]`/`[0xB075]`/`cs:[0x104]`，仿照 `usb_func` 把盘号注册进 grub4dos
   磁盘表（BDA 计数此时已被 Plop 修改，可直接对比 0x410/0x475 增量）。
4. 钩子拓扑：**grub4dos `int13_handler`（顶层）→ Plop handler（CS:0x100）→ ROM int 13h**。
   Plop 安装时把"当时的 0:0x4C"存为原向量，因此**安装顺序决定拓扑**——先装 grub4dos 钩子，
   再 init Plop，Plop 自然链到 grub4dos 之下。
5. 引导 OS 前：'TIUQ' 拆钩子 + `0x840E` 还原 BDA/EBDA（或保留常驻，Plop 本就支持）。

工程点（可枚举，非研究问题）：
- **内存占位**：Plop 需要镜像段内 0x0000–0xF8CF（含 BSS），需选一个不与 grldr core /
  int13_handler / EBDA 冲突的段，并向 grub4dos 的内存登记，避免被覆盖。
- **EBDA 收缩**：Plop 安装路径会动 BDA/EBDA——与 grub4dos 的常规内存假设要核对。
- **int 8h 定时器钩子**（Plop `sub_65BA` → CS:0x66FB 链式）：与 grub4dos 无已知冲突，登记即可。
- **A20**：Plop 只使能不关闭，无冲突。
- **最小初始化序列的精确定义**：静态已给出候选（0x8BE 序言 + 0x8442/0x84A6），
  精确步骤是动态阶段（bootlab-mcp P3/P4）的第一个实验。

工作量：胶水 ~200–400 行 asm/C，加调试，约数天。

### 路线 B：干净重写（GPL 兼容，工作量大）

把 Plop 的 USB 栈（UHCI/OHCI/EHCI 控制器层 + BOT + SCSI 命令层）重写为 USB2DRI 的替代/可选后端。
需要先完成动态分析（blob↔控制器对应、CSW 校验、传输细节），数周级。
产出是 GPL 干净的源码，可上游。

## 4. 法律/许可决策点

grub4dos 是 GPL；Plop Boot Manager 是闭源 freeware。**路线 A 的产物若要再分发/进上游，
有许可冲突风险**（GPL 要求对应源码；Plop 的再分发与反汇编条款需核对 plop.at 许可文本）。
个人本地集成不受此限。若目标是有尊严地上游：
- 路线 B（clean-room）；或
- 联系 Plop 作者 Elmar Hanlhofer 授权（论坛显示他对此类集成话题是开放的，PBM6 也在重写驱动）。

## 5. 建议的执行顺序

1. 先在真机/QEMU 上验证现有 `usb --init`（USB2DRI）的控制器覆盖与稳定性，
   明确 PBM 移植的**增量收益**（预期：老机器上 UHCI/OHCI 兼容性更好的概率高）。
2. bootlab-mcp P2–P4：跑通 Plop 最小初始化，确定最小安装序列与 blob↔控制器对应表。
3. 路线 A 原型：`plopdrv --init` 命令 + 内存占位 + 钩子拓扑，QEMU 里验证 grub4dos 能从 Plop 盘读扇区。
4. 稳定后再决策：仅本地使用（路线 A 即可）或走路线 B 重写上游。
