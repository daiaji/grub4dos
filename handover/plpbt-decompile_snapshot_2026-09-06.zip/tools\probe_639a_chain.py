#!/usr/bin/env python3
"""When 0x639A first fires, print: the call chain (via a shadow return stack),
SI / template / geometry state, and the last ~30 executed offsets before it.
Goal: which draw path reaches sub_6340 with garbage geometry."""
import sys, os, struct
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from unicorn import *
from unicorn.x86_const import *
from bootlab import Plop
_xc = sys.modules['unicorn.x86_const']
for _n in dir(_xc):
    if _n.startswith('UC_X86_REG_'):
        globals()[_n[3:]] = getattr(_xc, _n)

def build_disk():
    disk = bytearray(8*1024*1024)
    mbr = bytearray(512); mbr[446]=0x80; mbr[447:450]=bytes([0,1,1]); mbr[450]=0x06
    mbr[451:454]=bytes([15,63,63]); mbr[454:458]=struct.pack('<I',63); mbr[458:462]=struct.pack('<I',1022)
    mbr[510:512]=b'\x55\xAA'; disk[0:512]=mbr
    pbs=bytearray(512); pbs[510:512]=b'\x55\xAA'; disk[63*512:64*512]=pbs
    return bytes(disk)

p = Plop(load_seg=0x7C00, entry=0x8BE, edd_type='ATA', max_insns=60_000_000)
p.bios.disk_attach(build_disk())
base = 0x7C00<<4
W,H = 80*8, 25*8

def mkdesc(size):
    d = bytearray(0x25)
    struct.pack_into('<I', d, 0x00, size)
    struct.pack_into('<H', d, 0x14, W)
    struct.pack_into('<H', d, 0x16, H)
    d[0x18]=1
    struct.pack_into('<H', d, 0x19, W)
    struct.pack_into('<H', d, 0x1B, 0)
    struct.pack_into('<H', d, 0x1D, H)
    struct.pack_into('<H', d, 0x1F, W)
    struct.pack_into('<H', d, 0x21, H)
    struct.pack_into('<H', d, 0x23, 0)
    return bytes(d)
p.uc.mem_write(base+0x9A26, mkdesc(0x2320))
p.uc.mem_write(base+0x9A4B, mkdesc(0x1000))
p.uc.mem_write(base+0xB732, bytes(bytearray(0x39)))
p.uc.mem_write(base+0xB76B, bytes(bytearray(0x39)))

state = {'done': False, 'last': [], 'chain': [], 'seen6340': 0, 'seen639a': 0}
def code(uc, addr, size, ud):
    off = addr-base
    state['last'].append(off)
    if len(state['last']) > 40:
        state['last'].pop(0)
    # track calls via opcode? too slow; instead record chain by scanning for E8
    if off == 0x6340:
        state['seen6340'] += 1
        if state['seen6340'] == 1:
            print('-- first sub_6340 entry: SI=%04X [B018]=%04X [B01A]=%02X'%(
                uc.reg_read(X86_REG_SI)&0xFFFF,
                struct.unpack('<H', bytes(uc.mem_read(base+0xB018,2)))[0],
                uc.mem_read(base+0xB01A,1)[0]))
    if off == 0x639A and not state['done']:
        state['done'] = True
        print('== 0x639A first hit')
        print('last 40 offsets: ' + ' '.join('%04X'%o for o in state['last']))
        print('SI=%04X BP=%04X  es:di=%04X:%04X cx=%04X ax=%04X'%(
            uc.reg_read(X86_REG_SI)&0xFFFF, uc.reg_read(X86_REG_BP)&0xFFFF,
            uc.reg_read(X86_REG_ES)&0xFFFF, uc.reg_read(X86_REG_DI)&0xFFFF,
            uc.reg_read(X86_REG_CX)&0xFFFF, uc.reg_read(X86_REG_AX)&0xFFFF))
        tpl = bytes(uc.mem_read(base+0xB732, 0x39))
        print('template 0xB732: ' + ' '.join('%02X'%b for b in tpl))
        tpl2 = bytes(uc.mem_read(base+0xB76B, 0x39))
        print('template 0xB76B: ' + ' '.join('%02X'%b for b in tpl2))
        for o in (0xab52,0xab56,0xab58,0xab5a,0xab5c,0xab5e,0xab60,0xab62,0xab64,
                  0xab72,0xab74,0xab76,0xab78,0xab7a,0xab7b,0xab81,0xab4d,0xab53,0xab55):
            print('  [%04X]=%04X'%(o, struct.unpack('<H', bytes(uc.mem_read(base+o,2)))[0]))
        raise KeyboardInterrupt
p.uc.hook_add(UC_HOOK_CODE, code)
try:
    r = p.run()
    print('run:', r[:120])
except KeyboardInterrupt:
    print('(stopped by probe)')
