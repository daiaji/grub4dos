# probe_boot_v2.py — run the +0x100-layout boot with milestone tracing.
# Milestones are CS offsets (file offset = CS - 0x100).
import sys, struct
import bootlab

MILESTONES = {   # CS offsets = file + 0x100
    0x0C4A: "alloc#1 call (file B4A)",
    0x5FC2: "draw sub_5EC2 (file 5EC2)",
    0x0C82: "alloc#2 (file B82)",
    0x13E6: "sub_1282 wait [b061] (file 12E6)",
    0x1431: "main loop 0x1331 (file 1331)",
    0x0D1A: "menu loop 0x0C1A (file C1A)",
    0x0DAE: "redraw+0x1331 (file CAE)",
    0x6738: "WATCHDOG ljmp 0:0 (file 6638)",
    0x0E63: "timer uninstall (file D63)",
    0x649A: "VBE fill loop (file 639A)",
    0x8542: "install hook blob (file 8442)",
}
seen = []

def extra(uc, cs):
    if cs in MILESTONES and cs not in seen:
        seen.append(cs)
        b061 = uc.mem_read(bootlab_base + 0xB061, 1)[0]
        b018 = struct.unpack("<H", bytes(uc.mem_read(bootlab_base + 0xB018, 2)))[0]
        print("[milestone] CS:%04X %s  [b061]=%d [B018]=%04X ticks=%d" %
              (cs, MILESTONES[cs], b061, b018, p.ticks_fired))
        sys.stdout.flush()

p = bootlab.Plop(max_insns=60_000_000, tick_insns=200_000, feed_watchdog=True,
                 hook_extra=extra)
bootlab_base = p.base
p.hook_extra = extra
p.bios.disk_attach(bootlab.default_disk())
r = p.run()
print("run:", r)
print("final IP: CS=%04X IP=%04X" % (p.uc.reg_read(bootlab.UC_X86_REG_CS),
                                     p.uc.reg_read(bootlab.UC_X86_REG_IP)))
b061 = p.uc.mem_read(bootlab_base + 0xB061, 1)[0]
b6e8 = p.uc.mem_read(bootlab_base + 0xB6E8, 1)[0]
print("[b061]=%d [b6e8]=%d ticks=%d" % (b061, b6e8, p.ticks_fired))
print("--- screen ---")
print(p.dump_screen())
ivt8 = bytes(p.uc.mem_read(0x20, 4))
print("IVT[8] =", struct.unpack("<HH", ivt8))
