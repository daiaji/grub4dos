#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""OHCI transport probe: run 'u' (all three modules) and watch the OHCI round.

Milestones live at OHCI-module runtime addresses (linear = 0x9A800 + file
- 0x33E9); the AL dispatcher (sub_364C) records the AH=0x99 AL sequence.
The virtual controller (MMIO 0x10100000) advances the control ED chain on
HcCommandStatus.CLF/BLF writes and on HcInterruptStatus.WDH polls; the
driver's sub_4264 wait loop is the OHCI doorbell equivalent.
"""
import os, sys, struct
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bootlab
from bootlab import Plop

HSEG, BASE = 0x9A700, 0x33E9
def lin(foff): return HSEG + 0x100 + (foff - BASE)

M = {
    0x3507: 'int13 hook AH=99',
    0x3BB6: 'AL2 PCI presence',      # the 0x9902 gate
    0x382E: 'AL3 find-by-class',
    0x3CE5: 'AL4 controller init',
    0x42F0: 'port power/reset',
    0x4264: 'doorbell+WDH wait',
    0x4203: 'TD build (CBW)',
    0x4066: 'TD build (data)',
    0x436D: 'AL6 CCS check',
    0x4354: 'port CSC ack',
    0x44C2: 'AL7 enum',
}
hits, ticks_at = {}, {}
al_log = []
def mk(name):
    def cb(uc, addr, size, ud):
        hits[name] = hits.get(name, 0) + 1
        if name not in ticks_at:
            ticks_at[name] = p.ticks_fired
    return cb

hot = {}
_n = [0]
def sampler(uc, cs_off):
    _n[0] += 1
    if _n[0] >= 2_000_000:
        _n[0] = 0
        cs = uc.reg_read(bootlab.X86_REG_CS)
        ip = uc.reg_read(bootlab.X86_REG_IP)
        hot[(cs, ip)] = hot.get((cs, ip), 0) + 1

p = Plop(keys='u', edd='USBD', tick_insns=200_000, feed_watchdog=True,
         hook_extra=sampler, max_insns=400_000_000,
         usb_uhci_dev=False)   # fail the UHCI test (AL6 CCS=0) so the 'u'
                               # install loop proceeds to the OHCI round
p.bios.disk_attach(bootlab.default_disk())
u = p.uc

# round tracking: sub_8442's SI carries the module id of the round being
# installed; milestones only count while round == 'OHCI'
cur_round = ['?']
ROUNDS = {0x479D: 'EHCI', 0x2453: 'UHCI', 0x34E9: 'OHCI'}
def install_copy(uc, addr, size, ud):
    si = uc.reg_read(bootlab.X86_REG_SI) & 0xFFFF
    cur_round[0] = ROUNDS.get(si, hex(si))
    print('>>> round: %s @tick %d' % (cur_round[0], p.ticks_fired), flush=True)
u.hook_add(bootlab.UC_HOOK_CODE, install_copy,
           begin=0x30000 + 0x8442 + 0x100, end=0x30000 + 0x8442 + 0x100)

round_hits = {}
def mk(name):
    def cb(uc, addr, size, ud):
        hits[name] = hits.get(name, 0) + 1
        if cur_round[0] == 'OHCI':
            round_hits[name] = round_hits.get(name, 0) + 1
        if name not in ticks_at:
            ticks_at[name] = p.ticks_fired
    return cb

def al_cb(uc, addr, size, ud):
    al = uc.reg_read(bootlab.X86_REG_AX) & 0xFF
    if cur_round[0] == 'OHCI':
        al_log.append(al)
    hits['AL dispatcher'] = hits.get('AL dispatcher', 0) + 1
    if 'AL dispatcher' not in ticks_at:
        ticks_at['AL dispatcher'] = p.ticks_fired
u.hook_add(bootlab.UC_HOOK_CODE, al_cb, begin=lin(0x364C), end=lin(0x364C))

for foff, name in M.items():
    u.hook_add(bootlab.UC_HOOK_CODE, mk(name), begin=lin(foff), end=lin(foff))

r = p.run()
print('run:', r, flush=True)
print('milestones (all rounds):', {k: (v, ticks_at.get(k)) for k, v in hits.items()}, flush=True)
print('OHCI-round milestones:', round_hits, flush=True)
print('OHCI AL sequence:', al_log, flush=True)
print('pci_log:', p.bios.pci_log, flush=True)
b = p.bios
print('ohci engine: tds=%d ctrl=%04X ist=%08X hcca=%08X ctrlhead=%08X done=%08X'
      % (b.ohci_tds_done, b.ohci_ctrl, b.ohci_ist, b.ohci_hcca,
         b.ohci_ctrl_head, b.ohci_done), flush=True)
print('usb: cbws=%d csws=%d last_cmd=%s write=%s' %
      (b.usb_cbws, b.usb_csws, b.usb_last_cmd, b.usb_write), flush=True)
print('disk writes:', b.disk_writes, flush=True)
print('hot (cs,ip):', {(hex(c), hex(i)): n for (c, i), n in
      sorted(hot.items(), key=lambda kv: -kv[1])[:12]}, flush=True)
