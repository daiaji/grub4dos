# plpbt.bin 动态分析实现方案（讨论稿）

> 前置结论见 `REPORT.md`：plpbt.bin 是 16 位实模式双格式引导镜像（raw boot-sector / Linux bzImage），
> 未压缩，BSS 0xAB3B–0xF8CF，运行时通过 IVT 钩子（int 13h 替换）挂接 USB/IDE 驱动，
> 静态反汇编仅覆盖 23.3%，剩余 33KB 需要动态跟踪补全。
> **现有 windbg MCP 无法承担此任务**（无法加载平铺 16 位 bin、无法执行实模式代码、反汇编器不支持 16 位），
> 本文讨论自建动态环境，核心是**新增一个仿真类 MCP server**。

---

## 1. 动态分析要回答的问题

| # | 问题 | 静态分析卡点 |
|---|------|--------------|
| Q1 | bzImage 路径（syssize=0, setup_sects=4）在 syslinux/grub 下如何自举？setup 段（0x250）是否自己补读磁盘？ | setup 代码未静态覆盖 |
| Q2 | int 13h 钩子（0x845E/0x8473 安装）的完整处理器逻辑、USB 盘如何被识别（"USBD" 判定、Force USB 1.1） | 15.8KB gap（0x1AFD–0x580F）经 IVT 进入 |
| Q3 | MBR 常驻模式：外部 bootstrap 预置 [0xB07C] 的确切协议（热键 CTRL-A 轮询、int 19h 放行） | bootstrap 不在本文件内，需观察行为 |
| Q4 | PM 切换后的 GUI 流程（VBE 分支 0x5A05、图形初始化、菜单状态机） | 0x66 前缀 32 位代码区未覆盖 |
| Q5 | 运行时数据结构：磁盘位图 [0xB075]、EDD 参数缓冲、菜单表——拿到真实值后回灌静态标注 | BSS 语义多为推断 |

## 2. 三条技术路线对比

### 路线 A：Unicorn Engine + 自写 mini-BIOS（推荐主力）

Python 进程内仿真：把 plpbt.bin 映射到实模式段，用 Unicorn（`pip install unicorn`）跑 CPU，
自己实现被调用到的 BIOS 中断桩和端口 IO 钩子。

- 优点：完全可脚本化、确定性可重放；支持指令级/内存级 hook、快照恢复；天然适合封装成 MCP 工具；
  单步成本极低（每秒百万级指令），跑完引导+菜单不到一分钟。
- 缺点：BIOS 环境要自己造（好在 plpbt 的 BIOS 调用面是有限集合，见 §3）；保真度取决于桩的质量。
- plpbt 特有的友好点：入口只用了 sti/hlt 轮询 + int 16h（不是 IRQ 驱动），A20 探测有三层回退
  （int 15h AH=24 失败 → port 0x92 → 键盘控制器），桩只要"应答"即可，不需要真实硬件行为。

### 路线 B：QEMU (TCG) + gdbstub / trace 日志（高保真参照）

`qemu-system-i386 -drive file=disk.img,format=raw -s -S`（gdbstub 冻结启动），
用 Python 实现一条极简 GDB RSP 客户端（实模式下读写寄存器/内存、断点、单步均可）；
或者 `-d in_asm,exec,int -D trace.log` 拿全量翻译/中断日志后离线解析。

- 优点：SeaBIOS 提供真 BIOS（int 13h/EDD、VBE、int 15h 全是真实现），Q2/Q1 的保真度最高；
  适合做"对拍"——验证自建桩是否引导 Plop 走了同一条路径。
- 缺点：指令流日志巨大；gdbstub 对 16 位段的符号化支持弱；不好做按键注入级别的自动化 UI 遍历；
  封装成 MCP 时进程管理复杂度高于路线 A。

### 路线 C：Bochs 内置 debugger / DOSBox-X debug（备选）

`bochsdbg -q -f bochsrc`，`trace-on` + `watch` + `r`/`xp` 控制台命令；可以管道脚本化。

- 优点：指令级 trace + watchpoint 成熟；配置一个虚拟硬盘即可。
- 缺点：控制台协议不适合做细粒度 MCP 工具面（只能命令透传）；速度慢于 Unicorn。
- 定位：当需要"真实 BIOS + 指令级观察"而 QEMU 日志太粗时的折中。

**结论：A 做主力并 MCP 化；B 做高保真对拍（人工或半自动，不必 MCP 化）；C 备用。**

## 3. mini-BIOS 需要实现的服务清单

来自静态分析的实际调用面（`out/functions.txt` 的 int 站点）：

| 中断/端口 | 功能号 | 用途 | 桩的最小实现 |
|---|---|---|---|
| int 13h | AH=02/03 | 读/写扇区（CHS） | 虚拟磁盘镜像（做一张 8MB 盘：MBR + 1 个 FAT16 分区 + Plop 安装态引导扇区） |
| int 13h | AH=08 | 取几何参数 | 返回虚拟盘 CHS（如 16 heads/63 spt） |
| int 13h | AH=41/42/48 | 扩展存在检查 / DA 读 / EDD 参数 | AH=48 必须填 [si+0x28] 主机总线类型（"ATA"/"USBD"）——**Q2 的关键开关**，可切换让 Plop 走 USB 识别路径 |
| int 10h | AH=03/08/0E/13 | 光标/字符/TTY 输出 | 记录到一个 80×25 文本画布，MCP 工具可直接读出"屏幕内容" |
| int 10h | AX=4F00/4F01/4F02 | VBE | 第一阶段返回失败（走文本 UI，静态已证实有该分支）；后续再补 VBE 桩看 GUI |
| int 16h | AH=00/01/02 | 键盘 | 队列桩——MCP 注入按键序列，实现菜单全自动遍历 |
| int 15h | AH=24 | A20 | 返回 CF=0、AH=0（成功）即可让 Plop 用 BIOS 路径 |
| int 15h | AH=88/C7/E801 | 内存大小 | 返回 640K/扩展内存 |
| int 19h | — | 重新引导 | 记录事件并停机（观察 Q3 的放行行为） |
| port 0x60/0x64 | — | 键盘控制器（A20） | 桩应答 0xD0 读（返回 bit1=1 即"A20 已开"） |
| port 0x92 | — | fast A20 | 记录读写即可 |
| port 0x1F0/0x3F6 | — | IDE 直接驱动 | 第一阶段不用（Plop 优先 BIOS）；Q2 深挖时再补 |
| port 0xCF8/0xCFC | — | PCI 枚举 | 同上，出现调用时桩返回空总线 |

## 4. 新 MCP server 设计（`bootlab-mcp`，建议名）

Python + unicorn + 官方 MCP SDK（stdio 传输），预估 500–800 行。工具面：

```
boot_load(image_path, load_seg="0x07C0"|"0x9000", entry_off=0x0|0x200,
          dl=0x80, resident_flag=false)   # 映射镜像、预置 [0xB07C] 等
disk_attach(path, geom="1024,16,63")     # 挂虚拟盘
key_send("...")                          # int 16h 键盘注入
run(max_instructions=50_000_000)         # 跑到 hlt 循环/int 19h/断点
step(n) / break_add(addr) / break_list / break_del
regs()                                   # 全部 16 位寄存器 + 段 + IP
mem_read(seg_off, len) / mem_dump(path, start, len)   # 如 dump BSS 0xAB3B..0xF8CF
ivt_dump()                               # 0:0-0x400 向量表快照（对比钩子安装）
screen()                                 # 返回文本画布（int 10h 桩的输出）
trace_on(filter) / trace_dump(limit)     # 指令/中断/端口 IO 流水
watch_add(addr, len, "r|w")              # 观察 [0xB075] 等 BSS 变量、IVT 写
snapshot_save(name) / snapshot_restore(name)
```

设计要点：
- 地址一律用 **"段内偏移 == 文件偏移"** 坐标（与 REPORT.md §2 一致），避免双重坐标系混乱。
- `boot_load` 需要同时预置 BSS 标志（如 [0xB07C]=1 模拟 MBR 常驻装载）——这正是 Q3 的实验手段。
- `trace_on` 默认记录：每条 `int`（向量号）、每次 IVT 写、端口 IO、段间跳转——这些足以把
  gap 区的函数边界回灌给静态清单（Q2/Q4）。
- 每个工具都是无状态短调用（状态存 server 进程内），符合 MCP 工具粒度。

## 5. 与现有 windbg MCP 的关系

windbg MCP 唯一沾边的姿势是 `record_trace` 录制 QEMU/Bochs 进程——但 TCG 是 JIT 执行，
录到的是宿主代码流而非 guest 指令流，价值有限，**不推荐**。正确路径就是 §4 的新 MCP；
windbg MCP 继续负责它擅长的 PE/dump/内核场景。

## 6. 分阶段里程碑

| 阶段 | 内容 | 验收 |
|---|---|---|
| P1 | unicorn 裸跑 raw 入口 0x8BE（无 BIOS 桩，先看 BSS 清零、SS:SP 保存、卡在哪） | 复现 REPORT.md §3 的顺序 |
| P2 | int 13h/10h/15h/16h 桩 + 虚拟盘 | 跑到主菜单，`screen()` 能看到 BOOTMANAGER 界面 |
| P3 | key_send 自动遍历菜单 + trace | Q4/Q5：菜单状态机、BSS 真值 |
| P4 | int 13h 钩子路径追踪（AH=48 "USBD" 开关实验） | Q2：15.8KB 驱动区函数边界回灌静态标注 |
| P5 | bzImage 路径实验（load_seg=0x9000, entry 0x200）+ QEMU 对拍 | Q1 |
| P6（可选） | VBE 桩、IDE/PCI 端口桩 | 图形 UI、直接硬件驱动路径 |

## 7. 风险与对策

- **自校验代码**：0x888 起的例程用 `fs:[edi]` 逐字节比较镜像内容（配合 0x59B5 的平坦选择子），
  疑似镜像完整性校验——修改文件做实验时可能触发；对策：先原样跑通再谈 patch。
- **hlt 轮询**：桩环境没有真实定时器 IRQ，`sti/hlt` 后 Unicorn 会停住——桩里把 hlt 实现为
  "消耗一个虚拟时钟 tick 并继续"，与 cx=5 的超时计数兼容。
- **16 位段/混合编码**：Unicorn 原生支持 16 位实模式与 0x66/0x67 前缀，无需特殊处理；
  反汇编侧（capstone）与仿真侧天然一致。
- **虚拟盘构造**：MBR + FAT16 + 安装态引导扇区可以手工构造（512B 级别），或直接用
  Plop 官方安装器在 QEMU 里装一份再把盘镜像拿来用（更真实）。

## 8. 收尾阶段计划与执行记录（2026-09-04）

原 §6 里程碑全部完成后，本轮收尾计划（5 阶段）与执行结果：

| 阶段 | 内容 | 结果 |
|---|---|---|
| 1 | BOT WRITE(10) 落盘 | ✅ disk_write + 数据 OUT 捕获；probe_write10 模式 A 逐字节验证（§9.8） |
| 2 | UHCI 传输层（静态解码 → 端口语义 → 0x9902 门 → 枚举/BOT） | ✅ 三根因修复（UC_HOOK_INSN 失效→位点钩子、16B 链接对齐、tick 驱动无门铃引擎）；门铃×34、47 TDs、模块真 CBW READ(10) LBA0、测试成功（§9.9） |
| 3 | OHCI 传输层（第二 PCI 功能 + MMIO ED/TD 引擎） | ✅ 四根因修复（BAR 映射、ED 布局、未建模寄存器透传、AL8 死代码门）；门铃×20、38 枚举 TDs、BOT 全周期经真实 ED/TD/WDH 管线（§9.10） |
| 4 | Setup 自然入口键 | ✅ **定论：不存在**——菜单条鼠标驱动（USB HID），静态（无键比较/无 int33）+ 动态（行扫描+按键全扫）双重证据（§9.4 附录） |
| 5 | 文档全面收尾 + 双模式回归 + out/ 清单 | ✅ DRIVERS §6.2c/6.4/6.6/6.7/6.8、DYNAMIC_FINDINGS §8.5/9.4附录/9.5/9.8-9.11、bss_truth UHCI/OHCI 槽表、analyze.py KNOWN_RUNTIME 扩充 + out/ 五件套重生成（99.4% 覆盖维持）、回归双绿 1674/1672·217 ints |

新增工具资产：probe_write10/probe_uhci/probe_ohci/probe_ohci_bot/probe_setup3/4/5；
bootlab 新增：PCI 多设备桩、UHCI/OHCI 双引擎、usb_uhci_dev/usb_ohci_dev 设备开关。
