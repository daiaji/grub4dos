#!/usr/bin/env python3
"""At sub_1282 entry, dump DS and the real table at DS:0xA825 (26 words) plus
the flag byte + first bytes of each pointed entry.  Settles whether DS != CS."""
import sys, os, struct
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from unicorn import *
from unicorn.x86_const import *
from bootlab import Plop
_xc = sys.modules['unicorn.x86_const']
for _n in dir(_xc):
    if _n.startswith('UC_X86_REG_'):
        globals()[_n[3:]] = getattr(_xc, _n)

def build_disk():
    disk = bytearray(8*1024*1024)
    mbr = bytearray(512); mbr[446]=0x80; mbr[447:450]=bytes([0,1,1]); mbr[450]=0x06
    mbr[451:454]=bytes([15,63,63]); mbr[454:458]=struct.pack('<I',63); mbr[458:462]=struct.pack('<I',1022)
    mbr[510:512]=b'\x55\xAA'; disk[0:512]=mbr
    pbs=bytearray(512); pbs[510:512]=b'\x55\xAA'; disk[63*512:64*512]=pbs
    return bytes(disk)

p = Plop(load_seg=0x7C00, entry=0x8BE, edd_type='ATA', max_insns=50_000_000)
p.bios.disk_attach(build_disk())
base = 0x7C00<<4
W,H = 80*8, 25*8

def mkdesc(size):
    d = bytearray(0x25)
    struct.pack_into('<I', d, 0x00, size)
    struct.pack_into('<H', d, 0x14, W)
    struct.pack_into('<H', d, 0x16, H)
    d[0x18]=1
    struct.pack_into('<H', d, 0x19, W)
    struct.pack_into('<H', d, 0x1B, 0)
    struct.pack_into('<H', d, 0x1D, H)
    struct.pack_into('<H', d, 0x1F, W)
    struct.pack_into('<H', d, 0x21, H)
    struct.pack_into('<H', d, 0x23, 0)
    return bytes(d)
p.uc.mem_write(base+0x9A26, mkdesc(0x2320))
p.uc.mem_write(base+0x9A4B, mkdesc(0x1000))
p.uc.mem_write(base+0xB732, bytes(bytearray(0x39)))
p.uc.mem_write(base+0xB76B, bytes(bytearray(0x39)))

seen = {'n':0}
def code(uc, addr, size, ud):
    off = addr-base
    if off == 0x1282 and seen['n'] == 0:
        seen['n'] += 1
        ds = uc.reg_read(X86_REG_DS)&0xFFFF
        cs = uc.reg_read(X86_REG_CS)&0xFFFF
        ss = uc.reg_read(X86_REG_SS)&0xFFFF
        print('sub_1282 entry: DS=%04X CS=%04X SS=%04X  (CS<<4=%05X DS<<4=%05X)'%(
            ds, cs, ss, cs<<4, ds<<4))
        # dump 26 words at DS:0xA825
        tbase = (ds<<4) + 0xA825
        words=[]
        for i in range(0x1a):
            w = struct.unpack('<H', bytes(uc.mem_read(tbase+2*i,2)))[0]
            words.append(w)
        print('table DS:0xA825 (26 words):')
        for i in range(0,26,4):
            print('  %02d: %s'%(i, ' '.join('%04X'%w for w in words[i:i+4])))
        for i, w in enumerate(words[:6]):
            e = (ds<<4)+w
            flag = uc.mem_read(e,1)[0]
            head = bytes(uc.mem_read(e,8))
            print('  entry#%02d off=%04X  flag=%02X  head=%s'%(
                i, w, flag, ' '.join('%02X'%b for b in head)))
p.uc.hook_add(UC_HOOK_CODE, code)
r=p.run()
print('run:', r[:120])
