import sys, struct
import bootlab

# Build a full 80x25 text window descriptor at 0x9A26 (stride 0x25).
# Layout (from 0x6481 tail reads, see DYNAMIC_FINDINGS.md):
#   +0  dword allocation size ; +4 word ; +6 word
#   +8  [ab5e] +A [ab60] +C [ab56] +E [ab58] +10 [ab5a] +12 [ab5c]
#   +14 [ab62] width px (>>3 = cols) ; +16 [ab64]
#   +18 [ab7a] byte ; +19 [ab7b] box width px (>>3) ; +1B [ab72]
#   +1D [ab74] height px (>>3) ; +1F [ab76] ; +21 [ab78] box height px
#   +23 [ab81]
W, H = 640, 200          # 80 x 25 text mode
BW, BH = 78 * 8, 23 * 8  # box ~78x23 chars
desc = bytearray(0x25)
struct.pack_into("<I", desc, 0x00, 0x2320)   # alloc size (dword)
struct.pack_into("<H", desc, 0x04, 0x0100)   # +4
struct.pack_into("<H", desc, 0x06, 0x0100)   # +6
struct.pack_into("<H", desc, 0x08, 0x0000)   # +8
struct.pack_into("<H", desc, 0x0A, 0x0000)   # +A
struct.pack_into("<H", desc, 0x0C, 0x0000)   # +C
struct.pack_into("<H", desc, 0x0E, 0x0000)   # +E
struct.pack_into("<H", desc, 0x10, 0x0000)   # +10
struct.pack_into("<H", desc, 0x12, 0x0000)   # +12
struct.pack_into("<H", desc, 0x14, W)        # +14 width
struct.pack_into("<H", desc, 0x16, 0x0000)   # +16
desc[0x18] = 0                              # +18 byte
struct.pack_into("<H", desc, 0x19, BW)      # +19 box width
struct.pack_into("<H", desc, 0x1B, 0x0000)  # +1B
struct.pack_into("<H", desc, 0x1D, H)       # +1D height
struct.pack_into("<H", desc, 0x1F, 0x0000)  # +1F
struct.pack_into("<H", desc, 0x21, BH)      # +21 box height
struct.pack_into("<H", desc, 0x23, 0x0000)  # +23

p = bootlab.Plop(load_seg=0x7C00, entry=0x8BE)
base = 0x7C000
data = bytearray(p.data)
data[0x9A26:0x9A26 + len(desc)] = desc
p.uc.mem_write(base, bytes(data))

disk = bytearray(8 * 1024 * 1024)
mbr = bytearray(512); mbr[446] = 0x80; mbr[450] = 0x06
mbr[454:458] = struct.pack('<I', 63); mbr[458:462] = struct.pack('<I', 1022)
mbr[510:512] = b'\x55\xaa'
disk[0:512] = mbr
pbs = bytearray(512); pbs[0] = 0xEA; pbs[510:512] = b'\x55\xaa'
disk[63*512:63*512+512] = pbs
p.bios.disk_attach(bytes(disk))

# patch mov-fs sites back (our data rewrite clobbered them)
for off in (0x464E, 0x57F7, 0x59F9):
    p.uc.mem_write(base + off, b'\x90\x90')

r = p.run()
print('run:', r[:110])
print('screen:', repr(p.dump_screen()[:400]))
print('ints:', len(p.bios.int_trace))
for e in p.bios.int_trace[-14:]:
    print('  int %02Xh from %04X:%04X ax=%04X dx=%04X' % (e[0], e[7], e[8], e[1], e[4]))