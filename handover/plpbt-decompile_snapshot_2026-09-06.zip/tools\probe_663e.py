import sys, struct
import bootlab, unicorn
from unicorn.x86_const import *
_xc = __import__('unicorn.x86_const', fromlist=['x'])
for _n in dir(_xc):
    if _n.startswith('UC_X86_REG_'):
        globals()[_n[3:]] = getattr(_xc, _n)

p = bootlab.Plop(load_seg=0x7C00, entry=0x8BE)
disk = bytearray(8 * 1024 * 1024)
mbr = bytearray(512); mbr[446] = 0x80; mbr[450] = 0x06
mbr[454:458] = struct.pack('<I', 63); mbr[458:462] = struct.pack('<I', 1022)
mbr[510:512] = b'\x55\xaa'
disk[0:512] = mbr
pbs = bytearray(512); pbs[0] = 0xEA; pbs[510:512] = b'\x55\xaa'
disk[63*512:63*512+512] = pbs
p.bios.disk_attach(bytes(disk))

uc = p.uc
base = 0x7C000
entries = []
def at_call663e(u, addr, size, ud):
    # instruction AT 0x64C1 (call 0x663e) about to run: EDI=start, EAX=end
    edi = u.reg_read(X86_REG_EDI)
    eax = u.reg_read(X86_REG_EAX)
    ebx = u.reg_read(X86_REG_EBX)
    ab4d = struct.unpack('<I', bytes(u.mem_read(base + 0xAB4D, 4)))[0]
    bpx = u.reg_read(X86_REG_BP)
    d9a26 = struct.unpack('<I', bytes(u.mem_read(base + 0x9A26, 4)))[0]
    d9a2a = struct.unpack('<I', bytes(u.mem_read(base + 0x9A2A, 4)))[0]
    entries.append((edi, eax, ebx, ab4d, bpx, d9a26, d9a2a))
uc.hook_add(unicorn.UC_HOOK_CODE, at_call663e, begin=base + 0x64C1, end=base + 0x64C1)
r = p.run()
print('run:', r[:60])
print('--- 0x663E call entries (edi start, eax end, ebx, [ab4d], bp, struct0, struct4):')
for i, e in enumerate(entries):
    print('  #%d start=%08X end=%08X ebx=%08X ab4d=%08X bp=%04X s0=%08X s4=%08X'
          % ((i,) + e))
