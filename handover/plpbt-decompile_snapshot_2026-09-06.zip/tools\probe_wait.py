#!/usr/bin/env python3
"""Decisive: preset only 0x9A26/0x9A4B descriptors (below BSS, survive zeroing).
Make int16 AH=00 block (raise WaitForKey) when queue empty -> proper menu-wait state."""
import sys, os, struct
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from unicorn import *
from unicorn.x86_const import *
from bootlab import Plop
_xc = sys.modules['unicorn.x86_const']
for _n in dir(_xc):
    if _n.startswith('UC_X86_REG_'):
        globals()[_n[3:]] = getattr(_xc, _n)

class WaitForKey(Exception): pass

def build_disk():
    disk=bytearray(8*1024*1024)
    mbr=bytearray(512); mbr[446]=0x80; mbr[447:450]=bytes([0,1,1]); mbr[450]=0x06
    mbr[451:454]=bytes([15,63,63]); mbr[454:458]=struct.pack('<I',63); mbr[458:462]=struct.pack('<I',1022)
    mbr[510:512]=b'\x55\xAA'; disk[0:512]=mbr
    pbs=bytearray(512); pbs[510:512]=b'\x55\xAA'; disk[63*512:64*512]=pbs
    return bytes(disk)

W,H=80*8,25*8   # 640x200 px -> /8 = 80x25 chars
def mkdesc(size):
    d=bytearray(0x25)
    struct.pack_into('<I',d,0x00,size)      # +0 dword size
    # geometry words at +8..+0x23
    struct.pack_into('<H',d,0x08,0x0002)    # ab5e
    struct.pack_into('<H',d,0x0A,0x0000)    # ab60
    struct.pack_into('<H',d,0x0C,0x0000)    # ab56
    struct.pack_into('<H',d,0x0E,0x0000)    # ab58
    struct.pack_into('<H',d,0x10,0x0000)    # ab5a
    struct.pack_into('<H',d,0x12,0x0000)    # ab5c
    struct.pack_into('<H',d,0x14,W)         # ab62 width  (px)
    struct.pack_into('<H',d,0x16,H)         # ab64 height (px)
    d[0x18]=1                               # ab7a border flag
    struct.pack_into('<H',d,0x19,W)         # ab7b box width
    struct.pack_into('<H',d,0x1B,0x0000)    # ab72
    struct.pack_into('<H',d,0x1D,H)         # ab74
    struct.pack_into('<H',d,0x1F,W)         # ab76 stride
    struct.pack_into('<H',d,0x21,H)         # ab78
    struct.pack_into('<H',d,0x23,0x0000)    # ab81
    return bytes(d)

p=Plop(load_seg=0x7C00, entry=0x8BE, edd_type='ATA', max_insns=120_000_000)
p.bios.disk_attach(build_disk())
base=0x7C00<<4
p.uc.mem_write(base+0x9A26, mkdesc(0x2320))
p.uc.mem_write(base+0x9A4B, mkdesc(0x1000))
# do NOT preset templates (BSS, rebuilt by code)

# patch int16: AH=00/10 with empty queue -> raise WaitForKey (real BIOS blocks)
orig_int16 = p.bios.int16
def new_int16():
    ah = p.uc.reg_read(X86_REG_AX)>>8
    if ah in (0x00,0x10):
        if p.bios.kbd_head == p.bios.kbd_tail:
            p.bios.int_trace.append((0x16, p.uc.reg_read(X86_REG_AX), 0,0,0,0,0,
                                     p.uc.reg_read(X86_REG_CS), p.uc.reg_read(X86_REG_IP)))
            raise WaitForKey()
    return orig_int16()
p.bios.int16 = new_int16

polls=[0]
def code(uc, addr, size, ud):
    off=addr-base
    if off in (0x172E,0x6317,0x833D):
        polls[0]+=1
p.uc.hook_add(UC_HOOK_CODE, code)
try:
    r=p.run()
    print('run:', r[:130])
except WaitForKey:
    print('WAITING FOR KEY (menu reached!)')
print('polls (peek sites):',polls[0])
print('int16 calls:', sum(1 for t in p.bios.int_trace if t[0]==0x16))
print('int19:', sum(1 for t in p.bios.int_trace if t[0]==0x19))
for o in (0xab62,0xab64,0xab74,0xab7b,0xab78):
    print('  [%04X]=%04X'%(o, struct.unpack('<H',bytes(p.uc.mem_read(base+o,2)))[0]))
