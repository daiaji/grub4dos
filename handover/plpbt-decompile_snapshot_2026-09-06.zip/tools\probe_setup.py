#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Setup / bootflag / Copy-to dynamic coverage probe.
Key script walks: 'c' (Setup) -> 's' (** Copy to ** screen) -> 'b' (bootflag
editor in profile/partition edit) -> 'p' (perform copy).  Milestones are
runtime-cs (file+0x100).  LFB text dumped after each phase."""
import os, sys, struct
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bootlab
from bootlab import Plop

M = {
    0x85A6: 'mainmenu f -> 0x84A6 screen',
    0x8745: 'setup screen 0x8645',
    0x8808: 'setup screen 0x8708',
    0x71B2: 'CopyTo screen open (s key, 0x70B2)',
    0x71D4: 'copy perform (p key, 0x70D3)',
    0x7C48: 'profile/part edit key handler (0x7B48)',
    0x7CC1: 'bootflag b (0x7BC1)',
    0x7CE7: 'logical l (0x7BE7)',
    0x7C74: 'clear flag d (0x7B72)',
}
counts = {}
phases = []
def extra(uc, cs_off):
    if cs_off in M:
        if cs_off not in counts:
            counts[cs_off] = 0
            phases.append((p.ticks_fired, hex(cs_off), M[cs_off]))
            print('[hit] %04X %s ticks=%d' % (cs_off, M[cs_off], p.ticks_fired),
                  flush=True)
        counts[cs_off] += 1

p = Plop(keys="c s b", edd='ATA', tick_insns=200_000,
         feed_watchdog=True, hook_extra=extra, max_insns=400_000_000)
p.bios.disk_attach(bootlab.default_disk())
r = p.run()
print('run:', r, flush=True)
print('milestones:', {hex(k): v for k, v in counts.items()}, flush=True)
txt = p.lfb_text()
print('--- LFB text (last 20 rows) ---', flush=True)
rows = [r for r in txt.split('\n') if r.strip()]
print('\n'.join(rows[-20:]), flush=True)