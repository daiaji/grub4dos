#!/usr/bin/env python3
"""Write-monitor 0xA7F0..0xA880 and 0xAB52..0xAB90 during boot: does ANY code
write the sub_1282 pointer table at 0xA825, or is it loader-preset (like
0x9A26)?  Also record geometry-block writes to explain the 0x639A clobber."""
import sys, os, struct
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from unicorn import *
from unicorn.x86_const import *
from bootlab import Plop
_xc = sys.modules['unicorn.x86_const']
for _n in dir(_xc):
    if _n.startswith('UC_X86_REG_'):
        globals()[_n[3:]] = getattr(_xc, _n)

def build_disk():
    disk = bytearray(8*1024*1024)
    mbr = bytearray(512); mbr[446]=0x80; mbr[447:450]=bytes([0,1,1]); mbr[450]=0x06
    mbr[451:454]=bytes([15,63,63]); mbr[454:458]=struct.pack('<I',63); mbr[458:462]=struct.pack('<I',1022)
    mbr[510:512]=b'\x55\xAA'; disk[0:512]=mbr
    pbs=bytearray(512); pbs[510:512]=b'\x55\xAA'; disk[63*512:64*512]=pbs
    return bytes(disk)

p = Plop(load_seg=0x7C00, entry=0x8BE, edd_type='ATA', max_insns=40_000_000)
p.bios.disk_attach(build_disk())
base = 0x7C00<<4
W,H = 80*8, 25*8

def mkdesc(size):
    d = bytearray(0x25)
    struct.pack_into('<I', d, 0x00, size)
    struct.pack_into('<H', d, 0x14, W)
    struct.pack_into('<H', d, 0x16, H)
    d[0x18]=1
    struct.pack_into('<H', d, 0x19, W)
    struct.pack_into('<H', d, 0x1B, 0)
    struct.pack_into('<H', d, 0x1D, H)
    struct.pack_into('<H', d, 0x1F, W)
    struct.pack_into('<H', d, 0x21, H)
    struct.pack_into('<H', d, 0x23, 0)
    return bytes(d)
p.uc.mem_write(base+0x9A26, mkdesc(0x2320))
p.uc.mem_write(base+0x9A4B, mkdesc(0x1000))
p.uc.mem_write(base+0xB732, bytes(bytearray(0x39)))
p.uc.mem_write(base+0xB76B, bytes(bytearray(0x39)))

RANGES = {
    'A825table': (0xA7F0, 0xA890),
    'geom':      (0xAB50, 0xAB95),
}
log = []
def hook_wr(uc, access, addr, size, val, ud):
    off = addr - base
    for name, (lo, hi) in RANGES.items():
        if lo <= off < hi:
            log.append('%04X w%d=%02X ip=%04X' % (off, size,
                        uc.mem_read(addr, 1)[0], (uc.reg_read(X86_REG_IP)&0xFFFF)))
            return
p.uc.hook_add(UC_HOOK_MEM_WRITE, hook_wr)
r = p.run()
print('run:', r[:120])
from collections import Counter
w_ip2 = Counter(rec.split('ip=')[-1] for rec in log)
print('total writes to monitored ranges:', len(log))
print('by writer ip:')
for ip,c in w_ip2.most_common(12):
    print('  ip=%s x%d' % (ip, c))
print()
print('last 25 writes:')
for rec in log[-25:]:
    print('  '+rec)
