import sys, struct
import bootlab, unicorn
from unicorn.x86_const import *
_xc = __import__('unicorn.x86_const', fromlist=['x'])
for _n in dir(_xc):
    if _n.startswith('UC_X86_REG_'):
        globals()[_n[3:]] = getattr(_xc, _n)

p = bootlab.Plop(load_seg=0x7C00, entry=0x8BE)
disk = bytearray(8 * 1024 * 1024)
mbr = bytearray(512); mbr[446] = 0x80; mbr[450] = 0x06
mbr[454:458] = struct.pack('<I', 63); mbr[458:462] = struct.pack('<I', 1022)
mbr[510:512] = b'\x55\xaa'
disk[0:512] = mbr
pbs = bytearray(512); pbs[0] = 0xEA; pbs[510:512] = b'\x55\xaa'
disk[63*512:63*512+512] = pbs
p.bios.disk_attach(bytes(disk))

r = p.run()
print('run:', r[:80])
uc = p.uc
base = 0x7C000
def rd(off, n):
    return bytes(uc.mem_read(base + off, n))
def dw(off): return struct.unpack('<I', rd(off, 4))[0]
def wd(off): return struct.unpack('<H', rd(off, 2))[0]
print('--- allocator BSS:')
for off, name in ((0xAB4D, 'base/cursor [ab4d]'), (0xAB6E, '[ab6e]'), (0xAB6A, '[ab6a]'), (0xAB7D, '[ab7d]'), (0xAB3B, '[ab3b]'), (0xAB3F, '[ab3f]'), (0xAB43, '[ab43]'), (0xAB47, '[ab47]')):
    print('  %s @ %04X = %08X' % (name, off, dw(off)))
print('--- structure at BP=0x9A26 (16 dwords):')
for i in range(16):
    print('  +%02X: %08X' % (i * 4, dw(0x9A26 + i * 4)))
print('--- word/struct at SI=0x9A2E,0x9A32,0x9A34: %04X %04X %04X'
      % (wd(0x9A2E), wd(0x9A32), wd(0x9A34)))
print('--- 0x9A26..0x9A60 raw:')
print('  ' + rd(0x9A26, 0x3A).hex(' '))