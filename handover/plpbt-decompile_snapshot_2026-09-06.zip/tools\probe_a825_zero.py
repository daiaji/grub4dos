#!/usr/bin/env python3
"""Hypothesis: 0xA825 is loader-preset window-entry table for sub_1282.  If we
zero it (all entries flag=0), sub_1282 calls no draw routines, geometry stays
valid, and boot should reach the keyboard-wait (sub_1331 int16 blocking)."""
import sys, os, struct
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from unicorn import *
from unicorn.x86_const import *
from bootlab import Plop
_xc = sys.modules['unicorn.x86_const']
for _n in dir(_xc):
    if _n.startswith('UC_X86_REG_'):
        globals()[_n[3:]] = getattr(_xc, _n)

def build_disk():
    disk = bytearray(8*1024*1024)
    mbr = bytearray(512); mbr[446]=0x80; mbr[447:450]=bytes([0,1,1]); mbr[450]=0x06
    mbr[451:454]=bytes([15,63,63]); mbr[454:458]=struct.pack('<I',63); mbr[458:462]=struct.pack('<I',1022)
    mbr[510:512]=b'\x55\xAA'; disk[0:512]=mbr
    pbs=bytearray(512); pbs[510:512]=b'\x55\xAA'; disk[63*512:64*512]=pbs
    return bytes(disk)

# block on empty keyboard queue -> detect menu-wait
class WaitForKey(Exception): pass

p = Plop(load_seg=0x7C00, entry=0x8BE, edd_type='ATA', max_insns=80_000_000)
p.bios.disk_attach(build_disk())
base = 0x7C00<<4
W,H = 80*8, 25*8

def mkdesc(size):
    d = bytearray(0x25)
    struct.pack_into('<I', d, 0x00, size)
    struct.pack_into('<H', d, 0x14, W)
    struct.pack_into('<H', d, 0x16, H)
    d[0x18]=1
    struct.pack_into('<H', d, 0x19, W)
    struct.pack_into('<H', d, 0x1B, 0)
    struct.pack_into('<H', d, 0x1D, H)
    struct.pack_into('<H', d, 0x1F, W)
    struct.pack_into('<H', d, 0x21, H)
    struct.pack_into('<H', d, 0x23, 0)
    return bytes(d)
p.uc.mem_write(base+0x9A26, mkdesc(0x2320))
p.uc.mem_write(base+0x9A4B, mkdesc(0x1000))
p.uc.mem_write(base+0xB732, bytes(bytearray(0x39)))
p.uc.mem_write(base+0xB76B, bytes(bytearray(0x39)))

# --- zero the loader-preset 0xA825 window-entry table (26 words) ---
for i in range(0x1a):
    p.uc.mem_write(base+0xA825+2*i, b'\x00\x00')

# block int16 read when queue empty
orig_int16 = p.bios.int16
def new_int16():
    ah = p.uc.reg_read(X86_REG_AX)>>8
    if ah in (0x00,0x10):
        if p.bios.kbd_head == p.bios.kbd_tail:
            raise WaitForKey()
    return orig_int16()
p.bios.int16 = new_int16

events=[]
def code(uc, addr, size, ud):
    off=addr-base
    if off in (0x172E,0x6317,0x833D):  # menu key polls
        events.append('KEYPOLL %04X'%off)
    if off==0x1331: events.append('0x1331 wait-entry')
    if off==0x1339: events.append('0x1339 int16-peek')
    if off==0x639A: events.append('639A-fill')
    if off==0x0C1C: events.append('0x0C1C boot-peek')
p.uc.hook_add(UC_HOOK_CODE, code)
try:
    r=p.run()
    print('run:', r[:120])
except WaitForKey:
    print('*** WAITING FOR KEY — menu wait reached! ***')
print('events (first 40):', events[:40])
print('int16 calls:', sum(1 for t in p.bios.int_trace if t[0]==0x16))
print('int19:', sum(1 for t in p.bios.int_trace if t[0]==0x19))
print('--- screen ---')
print(p.dump_screen())
for o in (0xab62,0xab64,0xab74,0xab7b,0xab78):
    print('  [%04X]=%04X'%(o, struct.unpack('<H', bytes(p.uc.mem_read(base+o,2)))[0]))
