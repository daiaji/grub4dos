#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""EHCI async-list evidence probe (4th gen, corrected frame).
Module installs at hookseg CS=0x9A70 (*0x100 target*): a file offset X runs
at linear 0x9A700 + 0x100 + (X - 0x469D) = 0x9A800 + X - 0x469D.
Hooks:
  - sub_4B9C entry  (0x4B9C)  enumeration entry, set-once at init
  - sub_5316 entry  (0x5316)  QH fill, set-once at init
  - async_gate      (0x54B0)  sub_54A9: wait fs:[ebp]&0x2000==0
  - doorbell        (0x54E7)  sub_54A9: USBCMD |= 0x20 (IAAD)
  - usbint_wait     (0x54F6)  sub_54F6 entry
  - usbint_loop     (0x54F8)  sub_54F6: je back while USBSTS.bit0==0
Also samples the last 64 hookseg (cs=0x9A70) IPs to see where it parks."""
import os, sys, struct
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bootlab
from bootlab import Plop

HSEG  = 0x9A700
GAP   = 0x100          # module code starts at hookseg:0x100
M0    = 0x469D         # EHCI blob file base
def lin(file_off): return HSEG + GAP + (file_off - M0)

hits = {}
ticks_at = {}
tail = []

def mk(name, file_off):
    def cb(uc, addr, size, ud):
        hits[name] = hits.get(name, 0) + 1
        if name not in ticks_at:
            ticks_at[name] = p.ticks_fired if hasattr(p, 'ticks_fired') else -1
    return cb

def eh(uc, cs_off):
    cs = uc.reg_read(bootlab.X86_REG_CS)
    if cs == 0x9A70:
        ip = uc.reg_read(bootlab.X86_REG_IP)
        tail.append((p.ticks_fired if hasattr(p, 'ticks_fired') else -1, ip))
        if len(tail) > 64:
            tail.pop(0)

p = Plop(keys='u', edd='USBD', tick_insns=200_000, feed_watchdog=True,
         hook_extra=eh, max_insns=400_000_000)
p.bios.disk_attach(bootlab.default_disk())
u = p.uc
hooks = [
    ('sub4B9C_init', 0x4B9C),    # enumeration entry (once)
    ('sub5316_qhfill', 0x5316),  # QH fill (once)
    ('async_gate',    0x54B0),   # sub_54A9 wait gate
    ('doorbell',      0x54E7),   # USBCMD |= 0x20
    ('usbint_wait',   0x54F6),   # sub_54F6 entry
    ('usbint_loop',   0x54F8),   # the je-back spin
]
for name, foff in hooks:
    u.hook_add(bootlab.UC_HOOK_CODE, mk(name, foff),
               begin=lin(foff), end=lin(foff))

r = p.run()
print('run:', r, flush=True)
print('hook hits:', hits, flush=True)
print('first-hit ticks:', {k: v for k, v in ticks_at.items()}, flush=True)
print('tail hookseg (tick,ip):', tail, flush=True)

def d16(a):  return struct.unpack('<H', bytes(u.mem_read(a, 2)))[0]
def d32(a):  return struct.unpack('<I', bytes(u.mem_read(a, 4)))[0]

reg = bytes(u.mem_read(bootlab.Bios.PCI_EHCI_BAR + 0x10, 0x30))
print('EHCI op regs:', reg.hex(' '), flush=True)
asynclist = d32(bootlab.Bios.PCI_EHCI_BAR + 0x10 + 0x18)
print('ASYNCLISTADDR = %08X' % asynclist, flush=True)
if asynclist:
    q = asynclist
    for depth in range(8):
        d = [d32(q + 4*i) for i in range(0x20 // 4)]
        ep = d[1]
        print('QH@%08X h=%08X dev=%d ep=%d spd=%s mps=%d cur=%08X '
              'ov_n=%08X ov_a=%08X tok=%08X'
              % (q, d[0], ep & 0x7F, (ep >> 8) & 0xF,
                 {0: 'full', 1: 'low', 2: 'high'}.get((ep >> 12) & 3, '?'),
                 (ep >> 16) & 0x7FF, d[3], d[4], d[5], d[6]), flush=True)
        q = d[0] & ~0x1F
        if d[0] & 1 or q == asynclist or q == 0:
            break
    base = asynclist & ~0x7F
    for off in range(0, 0x140, 0x10):
        print('%06X  %s%s' % (base + off,
              bytes(u.mem_read(base + off, 0x10)).hex(' '),
              ' <-QLIST' if base + off == asynclist else ''), flush=True)
print('[CF43]=%d [CF44]=%d' % (d16(p.base + 0xCF43), d16(p.base + 0xCF44)),
      flush=True)