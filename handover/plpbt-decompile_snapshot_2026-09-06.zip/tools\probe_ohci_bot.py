#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""OHCI BOT cycle probe (device-level, through the genuine OHCI pipeline).

The OHCI module's 'u' test never queues a BOT command (its READ CAPACITY
step is gated on module BSS [0x145B]==8, which no code path writes - see
DYNAMIC_FINDINGS).  The control-transfer enumeration (SET_ADDRESS +
GET_DESCRIPTOR) does run through the engine.  This probe completes the
picture: after the 'u' rounds, build a WRITE(10) BOT transaction (CBW OUT +
data OUT + CSW IN) as OHCI ED/TD structures in the driver's own pool and
run it through the real doorbell semantics (HcCommandStatus.CLF write ->
ED walk -> TD execution -> HCCA.DoneHead + WDH raise -> W1C ack).
"""
import os, sys, struct
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bootlab
from bootlab import Plop

p = Plop(keys='u', edd='USBD', tick_insns=200_000, feed_watchdog=True,
         max_insns=400_000_000, usb_uhci_dev=False)
p.bios.disk_attach(bootlab.default_disk())
r = p.run()
print('run:', r)
u = p.uc
b = p.bios
print('pre: ohci tds=%d ctrl=%04X head=%08X cbws=%d' %
      (b.ohci_tds_done, b.ohci_ctrl, b.ohci_ctrl_head, b.usb_cbws))

LBA = 1000
ED = 0x9CB40                       # the driver's control ED
TD = 0x9D200                       # free area past the driver's TD cursor
CBW = 0x9D300
DATA = 0x9D400
CSW = 0x9D600                      # clear of DATA+512: the CSW writeback must
                                   # not overlap the WRITE(10) payload
d32 = lambda a: struct.unpack('<I', bytes(u.mem_read(a, 4)))[0]
w32 = lambda a, v: u.mem_write(a, struct.pack('<I', v))

def mk_td(addr, nxt, dp, cbp, blen):
    """OHCI TD: control(CC=0xF pending), CBP, next, BE."""
    be = (cbp + blen - 1) if blen else 0
    w32(addr, 0xF0000000 | (dp << 16))         # CC=0xF, DP=00 SETUP/01 OUT/10 IN
    w32(addr + 4, cbp)
    w32(addr + 8, nxt)
    w32(addr + 0xC, be)

cbw = bytearray(31)
cbw[0:4] = b'USBC'
cbw[4:8] = struct.pack('<I', 0x0BADC0DE)       # dCBWTag
cbw[8:12] = struct.pack('<I', 512)             # dCBWDataTransferLength
cbw[12] = 0x00                                 # bmCBWFlags = OUT (write)
cbw[14] = 0x0A                                 # CBLength
cbw[15] = 0x2A                                 # WRITE(10)
cbw[17:21] = struct.pack('>I', LBA)
cbw[22:24] = struct.pack('>H', 1)
data = (b'OHCI-WRITE10-PERSIST:' + bytes(range(256)) * 2)[:512]

u.mem_write(CBW, bytes(cbw))
u.mem_write(DATA, data)
u.mem_write(CSW, b'\0' * 16)
mk_td(TD,            TD + 0x10, 1, CBW,  31)   # CBW OUT
mk_td(TD + 0x10,     TD + 0x20, 1, DATA, 512)  # data OUT
mk_td(TD + 0x20,     1,         2, CSW,  13)   # CSW IN
# ED: flags (keep), TailTd = end marker, HeadTd = first TD, NextED = terminate
flags = d32(ED)
w32(ED,      flags)
w32(ED + 4,  TD + 0x30)                        # TailTd (queue-end marker)
w32(ED + 8,  TD)                               # HeadTd
w32(ED + 0xC, 1)                               # NextED: terminate

before = bytes(b.disk[LBA*512:LBA*512+512])
b.ohci_ctrl_head = ED
b.ohci_ctrl |= 0x10                            # CLE
b.ohci_write_model(0x08, 0x2)                  # doorbell: HcCommandStatus.CLF
wdh = (b.ohci_ist & 2) != 0
csw = bytes(u.mem_read(CSW, 13))
res = {
    'wdh_raised': wdh,
    'tds_done': b.ohci_tds_done,
    'cbws': b.usb_cbws, 'csws': b.usb_csws,
    'last_cmd': b.usb_last_cmd,
    'disk_changed': b.disk[LBA*512:LBA*512+512] == data,
    'disk_writes': list(b.disk_writes),
    'csw': csw.hex(),
    'csw_valid': csw[:4] == b'USBS' and
                 struct.unpack('<I', csw[4:8])[0] == 0x0BADC0DE,
    'hcca_donehead': hex(d32(b.ohci_hcca + 0x80)) if b.ohci_hcca else '-',
    'ed_head_retired': hex(d32(ED + 8)),
}
print('OHCI BOT result:', res)
assert res['cbws'] == 1 and res['csws'] == 1, 'BOT cycle incomplete'
assert res['disk_changed'], 'WRITE(10) not persisted'
assert res['csw_valid'] and res['wdh_raised'], 'CSW/WDH broken'
print('OHCI BOT: PASS - full CBW->data->CSW through the ED/TD/WDH pipeline, '
      'WRITE(10) persisted at LBA %d' % LBA)
