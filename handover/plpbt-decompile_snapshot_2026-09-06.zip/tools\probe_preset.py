#!/usr/bin/env python3
"""Try a loader-preset of the main-window descriptor at 0x9A26 + template 0xB732
with 80x25 text geometry.  See whether boot completes (menu drawn, screen visible)."""
import sys, os, struct
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from unicorn import *
from unicorn.x86_const import *
from bootlab import Plop
_xc = sys.modules['unicorn.x86_const']
for _n in dir(_xc):
    if _n.startswith('UC_X86_REG_'):
        globals()[_n[3:]] = getattr(_xc, _n)

def build_disk():
    disk = bytearray(8*1024*1024)
    mbr = bytearray(512); mbr[446]=0x80; mbr[447:450]=bytes([0,1,1]); mbr[450]=0x06
    mbr[451:454]=bytes([15,63,63]); mbr[454:458]=struct.pack('<I',63); mbr[458:462]=struct.pack('<I',1022)
    mbr[510:512]=b'\x55\xAA'; disk[0:512]=mbr
    pbs=bytearray(512); pbs[510:512]=b'\x55\xAA'; disk[63*512:64*512]=pbs
    return bytes(disk)

p = Plop(load_seg=0x7C00, entry=0x8BE, edd_type='ATA', max_insns=50_000_000)
p.bios.disk_attach(build_disk())
base = 0x7C00<<4

# --- loader-preset: main window descriptor at 0x9A26 (0x25 bytes) ---
W = 80*8     # 640 px -> /8 = 80 cols
H = 25*8     # 200 px -> /8 = 25 rows
desc = bytearray(0x25)
struct.pack_into('<I', desc, 0x00, 0x2320)     # size dword
struct.pack_into('<H', desc, 0x04, 0x0000)     # +4
struct.pack_into('<H', desc, 0x06, 0x0000)     # +6
struct.pack_into('<H', desc, 0x08, 0)          # ->0xAB5E
struct.pack_into('<H', desc, 0x0A, 0)          # ->0xAB60
struct.pack_into('<H', desc, 0x0C, 0)          # ->0xAB56
struct.pack_into('<H', desc, 0x0E, 0)          # ->0xAB58
struct.pack_into('<H', desc, 0x10, 0)          # ->0xAB5A
struct.pack_into('<H', desc, 0x12, 0)          # ->0xAB5C
struct.pack_into('<H', desc, 0x14, W)          # ->0xAB62 (screen width)
struct.pack_into('<H', desc, 0x16, 0)          # ->0xAB64
desc[0x18] = 1                                 # ->0xAB7A (border flag)
struct.pack_into('<H', desc, 0x19, W)          # ->0xAB7B (box width)
struct.pack_into('<H', desc, 0x1B, 0)          # ->0xAB72 (x off)
struct.pack_into('<H', desc, 0x1D, H)          # ->0xAB74 (screen height)
struct.pack_into('<H', desc, 0x1F, W)          # ->0xAB76 (row stride)
struct.pack_into('<H', desc, 0x21, H)          # ->0xAB78 (box height)
struct.pack_into('<H', desc, 0x23, 0)          # ->0xAB81
p.uc.mem_write(base+0x9A26, bytes(desc))

# --- template at 0xB732 (0x39 bytes, copied to 0xAB52 by sub_6481) ---
tpl = bytearray(0x39)
# leave mostly 0; the allocator overwrites 0xAB52=0x0B, 0xAB55=0xF6, 0xAB5A=0xA0
p.uc.mem_write(base+0xB732, bytes(tpl))

# second window descriptor 0x9A4B (used at 0x0B82) -- same geometry, size small
desc2 = bytearray(0x25)
struct.pack_into('<I', desc2, 0x00, 0x1000)
struct.pack_into('<H', desc2, 0x14, W)
desc2[0x18] = 1
struct.pack_into('<H', desc2, 0x19, W)
struct.pack_into('<H', desc2, 0x1D, H)
struct.pack_into('<H', desc2, 0x1F, W)
struct.pack_into('<H', desc2, 0x21, H)
p.uc.mem_write(base+0x9A4B, bytes(desc2))
p.uc.mem_write(base+0xB76B, bytes(bytearray(0x39)))

# hook: stop if we reach the main menu wait (int16 read loop) or int19
events=[]
def code(uc, addr, size, ud):
    off=addr-base
    if off==0x5EC2:
        events.append('5EC2 draw entry')
    if off==0x6029 and len(events)<12:
        events.append('6029 loop (cx=%04X)'% (uc.reg_read(X86_REG_CX)&0xFFFF))
    if off==0x0B4A:
        events.append('0B4A alloc#1')
    if off==0x0B82:
        events.append('0B82 alloc#2')
p.uc.hook_add(UC_HOOK_CODE, code)
r=p.run()
print('run:', r[:140])
print('events:', events[:15])
print('--- screen ---')
print(p.dump_screen())
print(p.bss_report())
