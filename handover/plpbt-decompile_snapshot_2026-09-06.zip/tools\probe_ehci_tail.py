#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Trace where the EHCI module's code executes (hookseg 9A70) after PCI
stub install - last 45 ips tell where it stops."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bootlab
from bootlab import Plop

last = []
def eh(uc, cs_off):
    cs = uc.reg_read(bootlab.X86_REG_CS)
    ip = uc.reg_read(bootlab.X86_REG_IP)
    if cs == 0x9A70:
        last.append(ip)
        if len(last) > 3000:
            last.pop(0)

p = Plop(keys='u', edd='USBD', tick_insns=200_000, feed_watchdog=True,
         hook_extra=eh, max_insns=150_000_000)
p.bios.disk_attach(bootlab.default_disk())
r = p.run()
print('run:', r, flush=True)
print('hookseg execs:', len(last), flush=True)
print('last ips:', [hex(x) for x in last[-45:]], flush=True)
