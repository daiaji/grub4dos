import sys, struct
import bootlab, unicorn
from unicorn.x86_const import *
_xc = __import__('unicorn.x86_const', fromlist=['x'])
for _n in dir(_xc):
    if _n.startswith('UC_X86_REG_'):
        globals()[_n[3:]] = getattr(_xc, _n)

p = bootlab.Plop(load_seg=0x7C00, entry=0x8BE)
disk = bytearray(8 * 1024 * 1024)
mbr = bytearray(512); mbr[446] = 0x80; mbr[450] = 0x06
mbr[454:458] = struct.pack('<I', 63); mbr[458:462] = struct.pack('<I', 1022)
mbr[510:512] = b'\x55\xaa'
disk[0:512] = mbr
pbs = bytearray(512); pbs[0] = 0xEA; pbs[510:512] = b'\x55\xaa'
disk[63*512:63*512+512] = pbs
p.bios.disk_attach(bytes(disk))

uc = p.uc
base = 0x7C000
ring = []
hit = [False]

def hc(u, addr, size, ud):
    if addr >= base and addr < base + 0x10000:
        ring.append(addr - base)
        if len(ring) > 200:
            ring.pop(0)
        if not hit[0] and (addr - base) == 0x664D:
            hit[0] = True
            raise SystemExit

u0 = uc.hook_add(unicorn.UC_HOOK_CODE, hc)
try:
    p.run()
    print('did not hit 0x664D; run returned normally?')
except SystemExit:
    pass
finally:
    try:
        uc.hook_del(u0)
    except Exception:
        pass

print('--- first time at 0x664D, last 200 executed:')
print(' '.join('%04X' % a for a in ring[-200:]))
print('regs: EDI=%08X EAX=%08X EBX=%08X ECX=%08X BP=%04X SI=%04X CS:IP=%04X:%04X'
      % (uc.reg_read(X86_REG_EDI), uc.reg_read(X86_REG_EAX),
         uc.reg_read(X86_REG_EBX), uc.reg_read(X86_REG_ECX),
         uc.reg_read(X86_REG_BP), uc.reg_read(X86_REG_SI),
         uc.reg_read(X86_REG_CS), uc.reg_read(X86_REG_IP)))
print('BSS [ab4d]=%08X [ab3b]=%08X [ab3f]=%08X'
      % tuple(struct.unpack('<I', bytes(uc.mem_read(base + o, 4)))[0]
              for o in (0xAB4D, 0xAB3B, 0xAB3F)))