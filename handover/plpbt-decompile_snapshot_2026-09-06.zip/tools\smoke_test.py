#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Smoke test: does Unicorn (16-bit real mode) dispatch software `int n`
through the IVT like real silicon, or must we intercept via UC_HOOK_INTR?
"""
from unicorn import *
from unicorn.x86_const import *
import struct, sys

# unicorn 2.x renamed register constants X86_REG_* -> UC_X86_REG_*
_xc = sys.modules["unicorn.x86_const"]
for _n in dir(_xc):
    if _n.startswith("UC_X86_REG_"):
        globals()[_n[3:]] = getattr(_xc, _n)

def test_ivt_dispatch():
    # map 256KB covering IVT (0:0), stub seg (0x10000) and code seg (0x20000)
    uc = Uc(UC_ARCH_X86, UC_MODE_16)
    uc.mem_map(0, 0x40000)

    # BIOS stub for int 0x13 at 0x1000:0000 : mov ah,0x42 ; iret
    stub = bytes([0xB4, 0x42, 0xCF])
    uc.mem_write(0x10000, stub)
    # IVT entry int 0x13 -> vector at 0:0x4C, layout: [IP:2][CS:2]
    uc.mem_write(0x4C, struct.pack("<HH", 0x0000, 0x1000))

    # test code at 0x2000:0x100 : mov ah,0x11 ; int 0x13 ; mov al,ah ; hlt
    code = bytes([0xB4, 0x11, 0xCD, 0x13, 0x8A, 0xC4, 0xF4])
    uc.mem_write(0x20000 + 0x100, code)

    uc.reg_write(X86_REG_CS, 0x2000)
    uc.reg_write(X86_REG_IP, 0x100)
    uc.reg_write(X86_REG_SS, 0x3000)
    uc.reg_write(X86_REG_SP, 0x100)
    uc.reg_write(X86_REG_AX, 0x1111)

    intr = {"n": None}
    def on_intr(u, intno, user_data):
        intr["n"] = intno
    uc.hook_add(UC_HOOK_INTR, on_intr)

    try:
        uc.emu_start(0x20000 + 0x100, 0x20000 + 0x100 + len(code), count=1000)
        ah = uc.reg_read(X86_REG_AX) >> 8
        print("IVT dispatch: ran to end, AH=%02X (expected 42 if IVT worked)," % ah,
              "intr hook saw:", intr["n"])
    except UcError as e:
        print("IVT dispatch: UcError", e)

def test_hook_intr_manual():
    # Without IVT, does hook_intr fire for software `int`? And what does
    # unicorn do to CS:IP after the hook returns?
    uc = Uc(UC_ARCH_X86, UC_MODE_16)
    uc.mem_map(0, 0x40000)
    code = bytes([0xB4, 0x11, 0xCD, 0x13, 0x90, 0xF4])  # int 13h ; nop ; hlt
    uc.mem_write(0x20000 + 0x100, code)
    uc.reg_write(X86_REG_CS, 0x2000)
    uc.reg_write(X86_REG_IP, 0x100)
    uc.reg_write(X86_REG_SS, 0x3000)
    uc.reg_write(X86_REG_SP, 0x100)
    seen = []
    def on_intr(u, intno, user_data):
        seen.append(intno)
        u.reg_write(X86_REG_AX, 0x4200)  # stub: AH=0x42
        # unicorn will continue somewhere after the hook -> where?
    uc.hook_add(UC_HOOK_INTR, on_intr)
    try:
        uc.emu_start(0x20000 + 0x100, 0x20000 + 0x100 + len(code), count=1000)
        print("hook route: ran to end, seen ints:", seen, "AX=%04X" % uc.reg_read(X86_REG_AX),
              "CS:IP=%04X:%04X" % (uc.reg_read(X86_REG_CS), uc.reg_read(X86_REG_IP)))
    except UcError as e:
        print("hook route: UcError", e)

if __name__ == "__main__":
    test_ivt_dispatch()
    test_hook_intr_manual()