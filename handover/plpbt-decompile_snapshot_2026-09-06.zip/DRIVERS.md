# plpbt.bin 实模式驱动专题分析（DRIVERS.md）

> 前置：`REPORT.md`（文件格式、寻址模型、启动主流程）。
> 本文聚焦实模式驱动框架与硬件访问。方法：以 int 13h 钩子安装点为根重新做递归反汇编
> + 对剩余 gap 线性扫描（`tools/analyze.py` v2），**代码覆盖率 23.3% → 99.4%**，
> 新增 `out/ports.txt`（全镜像端口 IO 清单）。

---

## 1. 驱动框架：int 13h 钩子 + 'PoLP' 魔数协议

Plop 的全部磁盘服务走一条机制：**把 int 13h 处理器复制到 CS:0x100 并接管 IVT**。

### 1.1 安装 / 卸载

| 地址 | 函数 | 行为 |
|---|---|---|
| 0x8442 | 安装 | `es=[0xCF5B]`，`rep movsb` 把模块 blob 复制到 **CS:0x100**；保存原 int 13h 向量（`0:0x4C` → BSS `[0xE08A]`）；把 `(CS<<16)|0x100` 写入 `0:0x4C`；置钩子标志 `[0xB6E9]=0`；随后以 `eax='PoLP'`, `ebp='TINI'` 发 INIT 命令 |
| 0x8496 | 卸载 | `eax='PoLP'`, `ebp='TIUQ'`（QUIT），经钩子发命令 → 处理器恢复原向量 |
| 0x840E | BDA 恢复 | 段 0x40 直接写 BDA：`[0x40E]`(EBDA 段址)、`[0x413]`(常规内存大小)、`[0x410]`(设备字)、`[0x490]` —— 即 Plop 常驻时曾**收缩/挪动 EBDA** 给自己腾内存，退出时还原 |
| 0x0D85 | 命令封装 | 保存/清零 `[0xB6E9]`（钩子生效标志）后 `int 13h` 发魔法寄存器命令 |

### 1.2 魔数寄存器协议（复制到 0x100 的处理器头部分发）

```asm
cmp     eax, 'PoLP'          ; 66 3d 50 6f 4c 50
jne     normal_int13_service
cmp     ebp, 'TINI'          ; INIT：记录引导盘号与模块指针
jne     +0x0c
mov     cs:[0x0104], dl      ; [0x104] = Plop 虚拟引导盘号
mov     cs:[0x0107], si      ; [0x107] = 模块/状态指针
iret
cmp     ebp, 'TIUQ'          ; QUIT：从 [0x107] 取回状态，恢复原向量
...
iret
```

INIT 之后，所有普通 int 13h 调用进入处理器的服务路径；服务代码用 `[0x104]` 里的盘号
判断"这个请求是发给 Plop 自己的盘（自己服务）还是别人的盘（链回原 BIOS 向量）"。

---

## 2. 五个 int 13h 处理器 blob（文件内位置与身份）

每个 blob 以同一套 'PoLP' 分发头开始，`call/jmp` 进入各自的服务体（仍在原文件位置执行，
0x100 处是入口跳板）。文件偏移 == 段内偏移，故 blob 内 `cs:[0x956]` 这类绝对引用在运行时
依然指向文件内对应位置。

| # | 分发头 @ | 服务入口 | 状态槽 | 身份与特征 |
|---|---|---|---|---|
| 1 | 0x1B1A | 0x1B5C | cs:[0x956]/[0x957] | **IDE/ATAPI CDROM**（ATAPI PACKET ×7、IDENTIFY PACKET DEVICE；AH=08/15/17 几何类分支） |
| 2 | 0x2374 | 0x23B6 | cs:[0x116F]/[0x1170] | **UHCI**（PCI 类码 0x0C0300 @0x2813；I/O 空间寄存器访问簇 0x2CFF–0x2DF4） |
| 3 | 0x340A | 0x344C | cs:[0x138B]/[0x138C] | **OHCI**（PCI 类码 0x0C0310 @0x3834；MMIO 访问） |
| 4 | 0x46BE | 0x4700 | cs:[0x1279]/[0x127A] | **EHCI**（PCI 类码 0x0C0320 @0x4B87；MMIO 访问；"Force USB 1.1" 即跳过此 blob） |
| 5 | 0x5860 | 0x58A2 | cs:[0x18A]/[0x18B] | **常驻重定向器**（仅 ~0x70 字节）：请求盘号 == `[0x104]` → 改成 `dl=0x80`；请求盘号 == 0x80 → 改回 `[0x104]`；然后链回原 int 13h。这就是 Plop 引导 OS 后保持 USB 盘可见的机制 |

**控制器发现机制（修正）**：每个 USB blob 自带一套 **INT 1Ah PCI BIOS32** 调用——
B101h 安装检查（`sub_2BF4`：`cmp edx,'PCI '`，BIOS32 入口存 [0x11D9]）、B103h 按类码找设备、
B108/B109/B10Ah 读配置字节/字/双字（**BAR/IO 基址由此取得**，故全镜像无 0xCF8/0xCFC 端口常量）。
调用点：UHCI blob 0x2C29–0x2CB4、OHCI blob 0x3BEB–0x3C47、EHCI blob 0x4F21–0x4F7D。

> blob 2/3/4 三个"盘号替换"变体对应多设备场景（Plop 最多同时挂几块自己驱动的盘）；
> blob 1 的 AH=17 分支偏软盘语义。**blob ↔ 具体控制器（USB-UHCI / OHCI / EHCI / IDE / ATAPI）
> 的最终对应关系需动态确认**——静态层面它们是同构骨架，差异在各自调用的后端硬件栈。

### 2.1 安装入口（谁在何时选 blob）

`0x84A6`（xref 自 0x0CBB 磁盘枚举路径）：`[0xB6F8]=dl`（盘号）→ `call 0x658D` …；
`0x8442/0x8496/0x84A6` 的上游 xref 群（0x8526/0x86E5/0x86EF/0x8704/0x873D/0x8743/0x8671/0x86F2/0x850C/0x8609）
是"按启动设备类型装配驱动"的分派层。例：`sub_1659`（xref 0x84BA）设 **IDE 通道基址
`[0xBC24]=0x170`**（次要 IDE），`[0xBC18]/[0xBC1B]` 填设备结构（类型 4、IRQ/标志 0x0A）。

---

## 3. 硬件访问盘点（`out/ports.txt`，共 273 处 IO）

| 簇 | 位置 | 判读 |
|---|---|---|
| 固定端口 | 0x60/0x64（键盘控制器）×9、0x92（fast A20）×3 | A20 例程 0x58D0 及其重复体（0x4550 附近一处、0x56F9 附近一处——不同 blob 各带一份 A20，服务自包含） |
| **DX 动态 IO** | **0x8CB0–0x96D4（64 处）+ 0xA0FB–0xAA29（127 处）** | 集中在文件尾部：`outsw/outsb/insb/insw` 字符串 IO —— **IDE/ATAPI 扇区数据传输**（rep insw 读 0x1F0 数据口 / rep outsb 发 PACKET 命令的典型形态）。修正 v1 报告"尾部是数据表"的判断：尾部 0x8B00–0xAA37 是驱动代码，混有表数据 |
| DX 动态 IO（散） | 0x1F81–0x2054（15）、0x2CFF–0x2DF4（10）、0x455F/0x5708/0x590A/0x5CD2/0x65E9/0x685C 各 4–9 处 | blob 内部的控制器寄存器访问（I/O 空间型）；0x5CD2 簇紧邻 A20/PM 区 |
| 字符串 IO 统计 | outsw×96, outsb×65, out×51, insb×29, in×17, insw×13, outsd×2 | 扇区传输 + 寄存器轮询 |

**端口基址全部参数化**：镜像内没有 `mov dx,0x1F0` 这类硬编码（唯一常量 `[0xBC24]=0x170` 是
通道路径的初始化值）——基址由 **INT 1Ah PCI BIOS32 的 B108–B10Ah 读配置空间（BAR）取得**后
存入 BSS 变量（如 [0xBC24]、[0xCF8B] 一带）。

## 4. 修正与新增结论（相对 REPORT.md）

1. 文件 0x100–0x1FF 是运行时填充的 int 13h 处理器驻留区（文件内为零占位）。
2. 0x8B00–0xAA37 尾部是 **IDE/ATAPI 传输代码**（字符串 IO 密集），非纯数据表。
3. 驱动不是零散钩子，而是**成体系的五 blob 框架**：统一 'PoLP' 魔数、统一跳板（0x100）、
   统一盘号替换语义（[0x104] ↔ 0x80）。
4. 覆盖率：递归反汇编 8,611 条指令（416 个函数标签）+ 51 个扫描区，总覆盖 99.4%；
   `out/disasm_full.asm` 现已包含驱动区（线性扫描段有显式标注，可能存在个别对齐偏差）。

## 5. 移交动态分析的验证清单

| # | 问题 | 手段（对应 DYNAMIC_PLAN.md） |
|---|---|---|
| D1 | ~~5 个 blob 各对应哪种控制器~~ **已静态解决**：blob1=ATAPI CDROM、blob2=UHCI、blob3=OHCI、blob4=EHCI、blob5=常驻重定向器（PCI 类码 + ATAPI PACKET 证据） | — |
| D2 | blob 复制到 0x100 的确切长度与跳板语义（`cx=[si+2]`） | rep movsb 处 watchpoint，dump 0x100 前后 |
| D3 | ~~USB 控制器枚举路径~~ **已静态解决**：INT 1Ah PCI BIOS32（B101/B103/B108–B10A），每个 blob 独立一套 | 动态仅需核对 BIOS32 入口失效时的回退行为 |
| D4 | IDE/ATAPI 传输循环的端口基址变量表（[0xBC24] 系） | watch BSS [0xBC20..0xBC60] |
| D5 | 常驻模式：BDA/EBDA 挪动量与恢复（0x840E） | 对比 [0x40E]/[0x413] 前后 |
| D6 | AH=08 盘号替换链（cs:[0x1196] 等槽的赋值时机） | blob 服务入口断点 + 寄存器记录 |

---

## 6. EHCI 传输层动态实测（QH/qTD/BOT 语义，2026-09-03）

> 证据链：`tools/probe_ehci_qh3.py` 全速跑 400M insns（keys='u', EDD='USBD'，
> tick_insns=200k, feed_watchdog），运行正常结束 `end (ticks=2001)`，命令流
> 0x9901→0x9906 完整；结束后回读 EHCI MMIO 页、QH 链、qTD 池与模块数据槽。
> 坐标：模块以 **hookseg CS=0x9A70（线性 0x9A700）** 驻留，模块内偏移 X ==
> 文件偏移 0x469D+X（BLOB 4 = EHCI，19562B，安装 si=cs:0x479D）。

### 6.1 传输层数据结构（实测加静态互证）

| 结构 | 位置 | 语义（实测值） |
|---|---|---|
| 寄存器指针表 | hookseg+0x2B37..0x2B53 | `[0x2B37]=10000010`(USBCMD)、`[0x2B3B]=10000014`(USBSTS)、`[0x2B53]=10000050`(PORTSC0)。**模块把 EHCI op 寄存器地址当作数据指针存这组槽**，访问一律 `fs:[esi]`（mmio read hook 命中的入口） |
| QH 异步列表 | `ASYNCLISTADDR = 0009D2C0`（= `[0x2B96]`） | 3 个 QH 环形链表，h 指针带类型位：`9D342/9D382/9D2C2 & 0x1F == 0x02`（QH 类型，非终止）。QH 步长 0x20 |
| QH 端点特征 | QH+4（dword 1） | QH0=`4040E000`（dev0/EP0/high-speed/DT-control/**head 标记**/mps=64）；QH1/2=`40006000`（dev0/EP0/high，mps=0，未配置）。cap dword2=`40000000` |
| QH overlay | QH+0x0C..0x2F | 运行时该 run 结束时已收回：cur=0、overlay next=1、alt=1（=terminate）、token=0。**说明传输阶段已完成/未进** |
| qTD 模板 | `[0x2BA0]` 段（seg=0x9D40 → 线性 0x9D400），步长 0x20 | sub_5416 构建：d0=1(next)、d1=1(alt)、d2=EBX(token)、d3=`[0x2BA2]`(buffer0=0x9E000)、d4..d7=0。sub_54A9 把它写入 QH overlay |
| 数据/暂存 | `[0x2BA2]=9E000`(buffer0)、`[0x2BA6]`=seg 0x9E00（0x9E000）、`[0x2B9C]=9D400`(qTD 区) | BOT CBW/数据帧经 0x9E000 段转发；sub_52BF 把 0x1000 字节从暂存拷回 `[0x16ED]`（描述符缓存） |
| 传输阶段程序 | 文件 0x4E20(control/setup)、0x4E56(data，CX=字节数)、0x4E8F(status)、0x4A98+ | 每阶段：sub_5544/模版 → sub_52B2 复制 CBW → sub_5416 建 qTD（EBX=token，toggle 取自 `[0x2B94]/[0x2B95]`）→ sub_54A9 挂 QH+门铃 → sub_54F6 等 USBSTS.bit0 → sub_5519 读回 overlay token bit31 |
| BOT CBW 构造 | sub_5544：`[0x26ED]='USBC'`(0x43425355)、`[0x26F5]=EBX`(dCBWTag/扇区量)、`[0x26F9]=AL`(bmCBWFlags，0x80=IN)、`[0x26FB]=0x0C`(CBWCB 长)、`[0x26FC]` 起 16B CDB | **模块用 USB Mass Storage BOT 帧（CBW→CSW）封装盘 I/O**；子阶段：CBW OUT(0x1F B)→数据→status |

### 6.2 主流程：async 调度启动与门铃（实测钩子时序，QH3→QH6 修正链）

```
key 'u' → 模块安装到 hookseg:0x100（线性 0x9A800；文件偏移 X 的运行时 ip
  = X − 0x469D + 0x100 —— QH3 的钩子地址少加了 0x100，命中点全部落在
  sub_5316 QH 填充内部，当时的"门铃时序"结论作废）。
正确钩子（QH4, 精确地址）：sub_5316=1次@tick467；async_gate/doorbell/
  usbint_wait/usbint_loop 全部 0 次 —— **传输原语根本没执行**。
根因 1（QH4 tail 采样）：模块死循环在 sub_56AC（文件 0x56B8..0x56C3）：
  `mov es,0x40; mov cx,2; .: cmp al,es:[0x6C]; je .` —— **等 BDA 0x40:0x6C
  的 tick 计数变化**（等 2 个 PIT tick 的延时）。真实 BIOS 拥有 IRQ0 并
  递增 0x46C；Plop 自己的 IRQ0 处理器不递增。
修复 1（bootlab.fire_irq0）：每次 tick 后 mem_write 0x46C += 1。
QH5（修复 1 后）：sub_5316 命中 42 次（枚举重试循环活了，端口等待通过），
  tail 显示模块在多个函数间正常流转；但传输原语仍 0 次 —— 端口一直读空。
根因 2：模块的 PORTSC 指针 [0x2B53] = 0x10000050 = **op+0x40**（实测），
  而 stub 只在 op+0x24 物化假设备值。
修复 2（bootlab hook_mmio_read）：在 op+0x24 / op+0x40 / op+0x44 三处
  都物化 PORTSC = CCS|PED|PP（0x00001005，PR 位读 0 = 自清）。
QH7/QH8/QH_MAGIC（修复 1+2 后，120M/400M insns）——**传输层点亮**：
  tick 504 一次完整枚举序列：sub_4B9C → sub_5416 建 qTD → sub_54A9 挂
  overlay + USBCMD|=0x20 门铃 → sub_54F6 等 USBSTS.bit0。
  虚拟设备应答（见下）后：门铃 ×10 全部完成（W1C 日志 USBSTS 写 0x25/0x1
  = 逐事务 ack），QH 端点特征变为 dev=5（**模块给虚拟设备分配了 USB 地址 5**，
  与 [0x2BA8] 地址计数一致）；命令流从 0x9906 推进到 **0x9907/0x9909**，
  MAGIC 序列呈 0x9903→…→0x9906→0x9907→0x9908→0x9906→0x9909 完整周期重复
  —— BOT 事务（CBW→数据→CSW）在虚拟设备上全通。
  待决 qTD 实测：QH0 cur=0x9D420、overlay next=0x9D440，qTD token
  0x80088D80 = toggle(bit31)|8 字节|0x8D80（data 阶段，buf0=0x9E000）——
  即 GET_DESCRIPTOR 前 8 字节的 IN。
```

### 6.2c 虚拟设备应答（bootlab 内建，本轮新增）

`Bios.usb_process_async()`（门铃写钩子 USBCMD&0x24 触发）：
1. 从 ASYNCLISTADDR 走 QH 链；沿 cur→next 执行 Active qTD：
   SETUP(2) 捕获 8 字节请求；IN(1) 按 `usb_respond()` 回数据写 buf0；
   OUT(0) 识别 'USBC' CBW → SCSI（0x12 INQUIRY 36B / 0x25 READ CAPACITY 8B /
   0x28 READ(10) 从 disk 镜像出扇区 / **0x2A WRITE(10) 数据阶段落盘** / 其他=CSW ok）。
2. 完成：token 清 Active+status、翻转 toggle(bit31)，写回 qTD 与 QH overlay，
   cur 清 0；USBSTS 置 USBINT|IAA（W1C 模型，读钩子 OR 入，guest 写 1 清除）。
描述符：device(64B EP0, VID 0x1234/PID 0x5678) + config(MSC/BOT/Bulk 2 端点)。

**WRITE(10) 落盘（2026-09-04）**：CBW 解析缓存 (lba, cnt*512)，数据 OUT qTD
的 payload 经 `disk_write()` 写入盘镜像（bytearray，`disk_attach` 统一转换），
越界写记入 `bios.notes`；写入清单 `bios.disk_writes` → 产物
`out/disk_writeback.bin`。实测：probe_write10 模式 A 在 LBA1000 落盘
512B 逐字节一致、CSW tag 回读正确、三支 qTD toggle 全翻转（§9.8）。

### 6.3 BOT/枚举语义结论（回填 §2 遗留）

- blob4(EHCI) 并非裸 bulk 引擎：**先走控制 EP0 枚举（GET_DESCRIPTOR 长度 0xC/9/`
  0x133F` 截 0x40），再用 BOT CBW/CSW 做扇区读写**——sub_4B9C 是枚举入口
  （`[0x1332]=0x40` 置 mps=64，`[0x2BA8]` 递增=device 地址计数）。
- 传输完成等待是 **USBSTS.bit0（USBINT）门铃应答**，不是轮询 RAM token；
  因此真实硬件上挂 IOC 中断配置（qTD token bit15=1 即 IOC）。
- `[0x2B94]/[0x2B95]` 为 toggle 状态字节，每阶段翻转（bit31 数据位随
  `_shl 31` 进入 token）。
- ~~**动态覆盖缺口**：本次 run 已把调度建好并完成首回合门铃，但设备体未应答
  （描述符全 0），所以枚举无设备连接而收场~~ ——已被 §6.2c 虚拟设备应答取代：
  枚举 + BOT 事务全通（DYNAMIC_FINDINGS §8.5#1 关闭）。

### 6.4 遗留状态（2026-09-04 收尾核对）

| # | 原待办 | 状态 |
|---|---|---|
| E1 | 虚拟设备应答：GET_DESCRIPTOR/SET_ADDRESS 应答桩，让枚举过 0x9906 后继续 | ✅ **完成** —— 实装在 bootlab `Bios.usb_process_async()/usb_exec_qtd()`（bootlab 内建，非 probe 桩）：门铃 ×10 全部完成（W1C ack）、设备分得 USB 地址 5、MAGIC 0x9903→…→0x9909 完整周期重复（§6.2c） |
| E2 | BOT CBW→CDB→扇区读回填（CSW 13B 语义） | ✅ **完成** —— 读路径：INQUIRY/READ CAPACITY/READ(10) 出盘镜像，模块经 UHCI BOT 真读 LBA0（§6.6）；写路径：WRITE(10) 数据阶段落盘（§6.2c、§9.8） |
| E3 | UHCI/OHCI 寄存器语义桩（现只 EHCI） | ✅ **完成** —— 新增 §6.6（UHCI 端口语义+TD/帧表引擎）与 §6.7（OHCI 第二 PCI 功能+MMIO ED/TD 引擎）；各自 0x9902 门通过、门铃完成、BOT 全周期实测（§9.9/§9.10） |

E1/E2/E3 全部关闭。剩余可见缺口（非目标遗留）：Setup 屏（0x6A64/0x6B20/
0x6B91 三函数）全镜像**零代码 xref**（数据字 0x6B20@file 0xB33 系 `call 0x7655`
的 E8 rel16 参数误报），但 **probe_natural3 已实证 0xB7A4 屏可经纯按键自然
打开**（DOWN×5+ENTER×2 → 运行时 0x6B64→0x6BA3→0xB7A4，见
DYNAMIC_FINDINGS §9.4）：SETUP 配置屏在键盘可达面内；其行处理器
（0x6A64 等）经 [0xC128] 记录表间接注册；键盘主循环无直达键、0x1600/0x1615（USB HID 层 LEFT/RIGHT 内部码）语义为装驱动非进
Setup 屏——虚拟 HID 指针需先模拟整套 Plop USB HID 事件队列，判定超纲
（见 DYNAMIC_FINDINGS §9.4 附录）；b/s/p 链覆盖以 far_call 强制开屏器 + 真机键为**实证上限**：edit-profile 注册表
（file 0x910E，行3=0x7B45 "edit profile -"）无代码安装者——plpbt.bin
引导版未接线（UI 死区），镜像固有事实。UHCI 轮的模块级 BOT
来自其测试流程自带读盘（READ(10) LBA0），OHCI 轮的模块测试不含 BOT
（READ CAPACITY 门 [0x145B]==8 为死代码），其 BOT 周期以设备级
ED/TD/WDH 管线注入验证（probe_ohci_bot）。

### 6.5 数字引导路径动态实测（'1' 键全链点亮，2026-09-03）

probe_digit.py（keys='1 …'，300M insns）——链路逐站命中：

| tick | 站点 | 说明 |
|---|---|---|
| 114 | 0x0DE7 | 主循环数字键分发（'1'-'9' → dl=digit-1） |
| 118 | 0x1939 | sub_1839 数字引导入口（[0xE089]=1、[0xB6F8]=dl） |
| 118 | 0x0F0A/0x668D/0x1759 | 设备表渲染(sub_0E0A)、BSS 备份(sub_658D)、设备窗+6 次泵(sub_1659) |
| 169→369 | 0x1785×6→0x1795 | 泵 6 次等 [0xBC20]==0x64（LFB 重绘 ~2M insns/次 → 每泵 ~40 tick） |
| 369 | 0x17B6 | "load profile data" 提示 |
| 402 | 0x7DB2 | **sub_7CB2 读取 per-device 档案记录** → B71D=01/B71E=00/B71F=80 |
| 434 | 0x1ADA→0x1AEE | sub_19DA 扫 [0xC6A9] 块 → **FOUND**（块[0]=0x80 设备字节） |
| 500 | 0x1B0D | sub_1A0D 解析表项：dl=[bp]=0x80、**LBA=[bp+8]=63**、读引导扇区 |
| 500 | 0x1A2B | 0xAA55 签名检查（修 seg/off 后 =55aa ✓） |
| 533 | **0x1B76** | **sub_1A76 引导跳转**：0xC6EB→0:0x7C00，retf 交接 |

交接寄存器实测（unknown_int 现场）：BX=0x7C00、SI=0x07BE（分区表项指针，
MBR 交接约定）、BP=0x07BE、DI=0x7DFE、DL=0x80 —— **数字引导路径端到端点亮**；
收尾 unknown_int = 假引导扇区自身行为（测试盘 LBA63 是 0xEA 桩）。

**档记录格式（实测+静态互证）**：
- `[0xB242+slot]` = 0x80|drive（可引导设备号，'b' 键编辑：`=(entry-1)>>2+0x80`，
  'r' 清 0xFF）；`[0xB232+slot]` = 1..16 顺序号（低 5 位 → B71D）。
- `[0xC6A9+blk*0x10]` = 16 字节引导表项 = **MBR 分区表项副本**（实测块[0]:
  80 00 01 01 06 0f 3f 3f 3f 00 00 00 fe 03 00 00 —— +8=LBA63）。
- `[0xB562+slot*0x10]` 16B/槽 × 4 dword = 分区可见性/名称标志（sub_1957 按
  B70D+part*4 重渲染；高半字节 0x10=清块、0x20..=用 B262 名称表、0=透传）。
- `[0xC32C+slot*0x13]` 19B 档案记录（默认 "hda partition N  \0 "）。
- 'w' 键 = 把启动标志写回 MBR（sub_0E0A 遍历 → sub_1742 AH=03 回写 0xC4EB）。

### 6.6 UHCI 传输层实测（2026-09-04，probe_uhci.py，修复链见 §9.9）

**模块坐标**：文件 0x2353 起 20358B，安装于 hookseg:0x100（运行时 ip = 文件 − 0x2253）。
AH=0x99 分发 sub_25C4（int13 钩子 0x2483 内 `cmp ah,0x99 → 0x2549 → 0x25C4`）。

```
0x9902 门（AL=2）＝ sub_2BF4：int1A B101h PCI BIOS 存在性（EDX=='ICP'）。
AL=3 ＝ find-by-class ECX=0x0C0300（PIIX4 UHCI 类码），SI=匹配索引。
AL=4 init ＝ sub_2824：B109/B10C 写 command（MM/IO 使能）→ B10A 读 BAR0
  （config 0x20，word，&~1 = I/O 基址）→ sub_2CC8 建寄存器指针表。
寄存器表 ＝ 模块内 7×word 偏移表 {00,02,04,06,08,10,12}（file 0x2CC1）+
  基址写入 [0x1B47]：USBCMD/USBSTS/USBINTR/FRNUM/FRBASEADD/PORTSC0/PORTSC1。
设备初始地址 [0x1B6E] = 5（与 EHCI 地址计数一致的约定）。
```

**传输语义（端口号 = I/O 基址 0xC000 + 偏移）**：

| 原语 | 位置 | 语义 |
|---|---|---|
| HC reset/停机 | sub_2E02 | USBCMD|=2 → 自旋等 USBSTS.bit5(HCHalted) → |=0 → 等 bit5 清 |
| 端口配置 | sub_2879/2880 | PORTSC \|= 0x20C（PP\|PED\|PRC）→ 等读回含 PED → 清 PR 位 → 自旋等 0x200 消失 |
| CCS 检查 | sub_28F6/28FD | PORTSC bit0==0 → **stc 直接失败**（模块测试 'U' 的门） |
| 帧表初始化 | sub_2863 | FRBASEADD=[0x1BAA]（cs+64KB 对齐页）；1024 槽全部 = QH 线性地址\|2；[0x1B6D]=1 |
| RUN | sub_2E4B | USBCMD\|=1 → 自旋读回 bit0==1 |
| 执行+等待 | **sub_2F95** | 帧表[0]=QH\|2、QH 元素=TD 链（0x20 步长）→ sub_31B1 扫描 40×TD Active 位 → **自旋轮询 USBSTS.bit0(USBINT)** → ax=1 W1C 应答（sub_2DE1）。UHCI 无门铃，控制器由时间驱动 |
| TD 构建 | sub_303C/313F | 槽位模板 [0x1B73..0x1B88]（32B/槽：link/status/token/buffer）→ sub_321E 算 buffer 线性地址 |
| CBW 构建 | sub_323B | 'USBC'@[0x170B]、tag=0x74354045、[0x1717]=方向、CBWCB=16B——**BOT 语义三模块共享同一尾部** |

**实测（bootlab 修复 3 处后）**：0x9902 门 ✓、B103 0xC0300→dev3 ✓、init 全链
✓、FRBASEADD=0x9D000、门铃（sub_2F95 进入）×34、**47 支 TD 完成**、
设备解析到真 CBW（tag 0x74354045、dlen=512、IN）= **模块测试自带 BOT READ(10)
LBA0**（MAGIC 0x9903..0x9909 后段）、AL 序列 [1..8] 走满、sub_87FB 测试
**成功返回** → 安装循环"首个成功模块获胜"退出（OHCI 轮被程序自身设计跳过）。

### 6.7 OHCI 传输层实测（2026-09-04，probe_ohci.py/probe_ohci_bot.py，§9.10）

**模块坐标**：文件 0x33E9 起 11759B；AH=0x99 分发 sub_364C（int13 钩子 0x3507）。
AL=2 门＝ sub_3BB6（B101，同 UHCI）；AL=3 find-by-class **0x0C0310**；
AL=4 init＝ sub_3CE5：BAR0（config 0x10）→[0x2139]=op 基址，
[0x21A2+4k]=36 个寄存器地址表（fs:[esi] 平坦窗访问，同 EHCI 机制），
HCCA=[0x213D]（256B 清零）、Control/Bulk ED 链头=[0x2161]/[0x216D]（+0x280 槽）。

| 原语 | 位置 | 语义 |
|---|---|---|
| 端口选择 | sub_42E0 | RhPortStatus 地址表 [0x21F6+4k] |
| 上电/复位 | sub_42F0 | PPS(bit8) 写 → 等读回 → PES 判定；bit9 LSDA 判低速 |
| CCS 检查 | sub_436D | RhPortStatus bit0==0 → stc 失败（'O' 测试门） |
| TD 构建 | sub_4066/4203 | 16B TD：ctrl(CC=0xF 待处理,DP,DI,toggle<<24)/CBP/next/BE；ED 16B：flags/TailTd/HeadTd/NextED，**链 16B 对齐** |
| **门铃+等待** | **sub_4264** | HcControl\|=CLE → HcCommandStatus\|=CLF/BLF → **自旋轮询 HcInterruptStatus.bit1(WDH/WritebackDoneHead)** → W1C 应答=2 |
| 完成 | done-head | 引擎把末 TD 写 HCCA+0x80 与 HcDoneHead；WDH 置位即子_4264 退出 |
| 中断关闭 | sub_4385 | HcInterruptEnable=0xC000007F（纯轮询模式） |

**实测**：usb_uhci_dev=False 让 UHCI 测试按 CCS 门干净失败后，OHCI 轮
[1..8] 全链：0x9902 ✓、B103 0xC0310→dev4 ✓、init ✓（HcControl=0x93
Operational+CLE、HCCA=0x9CA00、ctrl head ED=0x9CB40）、门铃 ×20、
**38 支枚举 TD**（SET_ADDRESS+GET_DESCRIPTOR）、AL [1,2,3,4,5,6,7,8,6,7,8,9,3]
测试成功返回。**BOT 全周期（probe_ohci_bot，设备级注入、走真实
ED/TD/WDH 管线）**：CBW OUT(31B)→数据 OUT(512B WRITE(10) LBA1000 落盘
逐字节一致)→CSW IN(13B tag 正确)，41 TDs、WDH 置位、ED head 回收到
TailTd、HCCA DoneHead=0x9D220。
**静态结论**：模块测试本身不含 BOT——AL8 的 READ CAPACITY 门
`cmp byte [0x145b],8` 无任何写入者（全镜像监视点 9 次写全为 0），
真实硬件上该路径同样不可达；BOT 只经 int13 读盘路径进入（UHCI 轮
所见 LBA0 READ(10)）。

### 6.8 bootlab 虚拟控制器实现要点（3 引擎）

- **UC_HOOK_INSN 在本 unicorn 构建注册成功但回调从不触发**（隔离最小
  复现）——UHCI 端口语义改为 12 个 IN/OUT 位点（file 0x2434..0x2DF4，
  线性 0x9A800+file−0x2353）的 UC_HOOK_CODE 钩子：读 opcode+DX 端口窗
  双重校验 → 应答 → 跳过 1-2B 指令。EHCI/OHCI 用 MMIO 读物化/写捕获
  （写钩子无法抑制 guest 写，读钩子在 load 前物化模型值）。
- PCI 桩多设备化：B103 按类码+prog-if+SI 索引精确匹配
  （dev2=EHCI 0x0C0320 BAR0 0x10000000 / dev3=UHCI 0x0C0300 I/O BAR
  config 0x20=0xC001 / dev4=OHCI 0x0C0310 BAR0 0x10100000）。
- BOT SCSI 层三引擎共享（usb_host_cbw/usb_host_data_out）；UHCI/OHCI
  可用 `usb_uhci_dev/usb_ohci_dev=False` 摘除假设备（CCS=0）以到达
  安装循环的后继轮次。
