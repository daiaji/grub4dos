# plpbt.bin 静态逆向报告

> 分析对象：`D:\repo\plpbt-decompile\plpbt.bin`，43,575 字节（0xAA37），文件日期 2023-01-26
> 工具：Python + capstone 5.0.7（16 位模式递归下降反汇编），产物在 `out/` 目录
> 身份：**Plop Boot Manager 5.x**（Elmar Hanlhofer, www.plop.at）。文件内未发现明确版本号字符串。

---

## 1. 文件格式：双格式引导镜像

同一个文件支持两种引导方式，靠文件头部两组数据区分：

### 1.1 原始引导 / 链式引导格式（boot-sector 路径）

| 文件偏移 | 内容 |
|---|---|
| 0x0000 | `e9 bb 08` → jmp 0x08BE（主入口） |
| 0x0003 | 识别横幅 "Hi, are you searching something? This is the Plop Boot Manager written by Elmar Hanlhofer http://www.plop.at"（防止有人 hexdump 时迷路，无实际代码作用） |
| 0x01FE | `55 AA` 引导签名 |

### 1.2 Linux bzImage 兼容格式（`KERNEL plpbt.bin` / `kernel /plpbt.bin` 路径）

标准 Linux x86 引导协议头：

| 偏移 | 字段 | 值 |
|---|---|---|
| 0x01F1 | setup_sects | 4（setup 区 = 5 扇区 = 0xA00 字节，即文件 0x000–0x9FF） |
| 0x01FE | 签名 | `55 AA` |
| 0x0200 | setup 入口 | `eb 4e` → jmp 0x0250 |
| 0x0202 | magic | `HdrS` |
| 0x0206 | protocol version | 0x0206（boot protocol 2.06） |
| 0x01F4 | syssize | **0**（声明 payload 为 0 字节——见下文动态验证项） |
| 0x0211 | loadflags | 0（zImage 式低载） |

setup 段代码位于文件 0x0250 起（`mov ax,0x1000; mov ds,ax; xor si,si; mov ax,0x5000; mov es,ax; mov di,0x0B00; …`，典型的"搬运系统映像"代码）。

**待动态验证的问题**：syssize=0 时，GRUB 的 Linux 引导路径不会加载 payload，只有当 loader 把整个文件当作镜像加载（如 syslinux 对 `.bin` 的处理）时完整代码才会在内存里。setup 段如何在不同 loader 下完成自举（是否依赖 0x1000:0 处的镜像、是否自己发起 int 13h 补读）是动态分析的第一优先问题。

---

## 2. 寻址模型与内存布局（本次分析的关键结论）

> **⚠️ 修正（2026-09-02，DYNAMIC_FINDINGS §6.1）：本节"段内偏移 == 文件偏移"错误。**
> 真实布局：**文件偏移 0 位于 CS:0x100**（CS 偏移 X == 文件偏移 X − 0x100），官方装载段
> CS=0x3000，raw 入口 CS:0x9BE（= 文件 0x8BE）。下表所有偏移为 CS 偏移；凡涉及
> "文件内容"的解读需按 −0x100 换算（例：窗口表 CS:0xA825 = 文件 0xA725 的 26 项指针表，
> 描述符 CS:0x9A26 = 文件 0x9926 的真实数据——不存在"装载器预置"）。

通过入口代码的绝对寻址反推并验证：

**段内偏移 == 文件偏移。** 入口 `jmp` 是相对跳转（目标文件偏移 0x8BE）；后续所有绝对寻址（`call 0xD5B5`、`mov si,0xA2E3`、`[0xAB51]` 等）都落在文件偏移坐标系上。因此代码对装载段址不敏感（入口 `mov ax,cs; mov ds/es/ss,ax`），但要求：

- 整个 43,575 字节镜像按"文件偏移 0 == CS:0000"整体驻留（装载器必须全文件加载，不是只加载第 1 扇区）；
- 镜像所在段后面要有空闲 RAM 放 BSS。

| 区域 | 段内偏移 | 说明 |
|---|---|---|
| 镜像本体 | 0x0000 – 0xAA36 | 代码 + 数据，未压缩 |
| SS:SP 保存区 | 0xAB37 / 0xAB39 | 入口保存装载者的 SS:SP |
| **BSS** | **0xAB3B – 0xF8CF** | 入口处 `rep stosb` 清零 0x4D94 字节，紧跟镜像尾部、同一 64KB 段内 |
| 屏幕快照缓冲 | 0xCF91（BSS 内） | 启动时保存 B800:0 的 0x7D0 字文本屏 |

对应线性地址：raw 模式 CS=0x7C00 时镜像在 0x7C000–0x86A36、BSS 在 0x86B3B–0x90CCF；bzImage 模式（0x9000 段）镜像在 0x90000–0x9AA36、BSS 在 0x9AB3B–0x9F8CF（紧贴 EBDA 之下）。

> 修正：早期猜测的"后半部压缩 payload / 自解压"不成立。字符串 `"** Copy to **"`（0x72C6，带 "s ... select partition to copy / p ... paste data" 帮助文本）是 Plop 内置的**磁盘数据复制/粘贴工具**的 UI，不是解压标记。整个文件未压缩（高熵块是 16/32 位混合指令代码，不是压缩数据）。

---

## 3. 启动主流程（raw 模式，入口 0x08BE）

```
0x08BE  mov ax,cs; ds/es=ax        ; 建立数据段
        [0xAB37]=ss, [0xAB39]=sp   ; 保存装载者栈（退出时恢复）
        dl=0x80                    ; 默认引导盘 = 第一块 HDD
        ss=cs, sp=0xFFFE           ; 换自己的栈
        push 0 / popf              ; 清标志寄存器
        清零 BSS 0xAB3B..0xF8CF
        [0xAB51]=dl, [0xAB4B]=ds, [0xB018]=0xFFFF
        call 0x0DA2                ; ① 磁盘枚举
        call 0x6525                ; ② 设备名表整理
        保存 VGA 文本屏 → 0xCF91
        cmp [0xB07C],0             ; ③ 常驻模式标志
```

- **① 0x0DA2 磁盘枚举**：int 13h AH=08（取几何参数）→ 逐盘 int 13h AH=48（EDD 参数，**检查参数块 [si+0x28] 是否为 "USBD"，以此识别 USB 盘**并计数）→ 读每盘 MBR（AH=02，1 扇区 → 缓冲 0xC4EB）。
- **② 0x6525**：把文件 0x388 处 0x300 字的设备名表（"hda partition 1 … hdd partition 4"）搬到 BSS 0xB062，并整理成 16×16 定宽显示串（空格填充）→ BSS 0xC1FB/0xC32B。
- **③ 0xB07C 分支**：
  - =0（普通启动）：打印 0xA2E3 字符串，进入全盘扫描（0x1331 读盘校验；对每个盘以 bx=0/0x10/0x20/0x30 调 4 次 0x1ACE 读 4 个主分区表项，结果位图存 [0xB075]），随后进入主菜单/文本 UI。
  - ≠0（MBR 常驻模式）：打印 0x94F `"Press CTRL-A to start the Plop Boot Manager"`，`cx=5` 轮询（sti/hlt + int 16h）：按 CTRL-A → 启动管理器；否则/超时 → **int 19h** 重新引出原 BIOS 引导顺序。注意 0xB07C 在 BSS 里，文件中恒为 0 —— 推断由装载它的 Plop 专用 MBR bootstrap 预置此标志（这也是该文件能当"MBR 常驻热键"用的机制）。
- 主循环菜单键盘轮询 int 16h（0x172E、0x6317、0x833D 等多处），显示走 int 10h。
- 0x5A05：VBE 检测（int 10h AX=4F00，VBE2 信息块 → BSS 0xABC4/0xABC5），决定走图形（VBE）还是文本 UI。
- 引导扇区加载/链式引导集中区：0x8442–0x8731（int 13h 读扇区、int 10h/16h/19h），即"选中分区后读它的 boot sector 并移交"的实现。

---

## 4. 保护模式与 A20

| 地址 | 功能 |
|---|---|
| 0x58D0 | **A20 使能**，经典三级：int 15h AH=24（BIOS A20 服务，探测方法写入 [0xA1A8]）→ port 0x92（fast A20）→ 键盘控制器 0x64/0x60（0xD0 读输出端口/0xD1 写，置 bit1） |
| 0x59B5 | **短促进出保护模式**：检查 CR0.PE；若未开则建 GDT（0xA198：limit=0xFFFF，base=CS<<4，平坦覆盖镜像段），`lgdt` → 置 PE → `jmp $+2` 清流水线 → **FS=选择子 8** → 关 PE 回实模式。作用是给实模式代码一个 32 位平坦访问窗口（后续代码大量用 `67` 前缀的 `fs:[edi]` 访问高位内存，如 0x888 的逐字节比较例程） |
| 0xA198 | GDT 表（镜像内） |
| 0x1AFD–0x580F | 15.8KB 未静态覆盖区：含 0x66 前缀的 32 位 PM 代码（GUI）+ 运行时才进入的驱动代码 |

---

## 5. 运行时 IVT 钩子 —— 33KB 未覆盖区域的主因

- **0x845E**：`mov edi, dword ptr es:[0x4C]`（保存原 int 13h 向量）
- **0x8473**：`mov dword ptr es:[0x4C], eax`（安装 Plop 自己的 int 13h 处理器）

即 Plop 在运行时把 int 13h 替换为自己的磁盘服务（含 USB 驱动路径）。这类经 IVT/远指针进入的代码，静态控制流追不到 —— 这正是本次递归反汇编只覆盖 23.3% 的原因。旁证：字符串 `"USBC"`（0x3241/0x43A1）、`"PCI"`（0x2C02）、`plpA20!` 签名 ×3、菜单项 "Force USB 1.1"/"Ignore USB devices"；代码里有大量 `66 3d 50 6f 4c 50`（`cmp eax,'PoLP'`）风格的特征码扫描，说明驱动子模块按魔数定位/校验。

未覆盖区域构成（`out/stats.txt` 的 gap 列表）：

| 文件偏移 | 大小 | 内容推断 |
|---|---|---|
| 0x003–0x886 | 2.1KB | banner + bzImage 头 + setup 代码（仅 bzImage 路径执行） |
| 0x1AFD–0x580F | 15.8KB | USB/IDE/PCI 驱动 + int 13h 处理器 + PM GUI 代码（16/32 位混合，IVT 进入） |
| 0x8B00–0xAA37 | 8KB | 驱动代码（大量 `insw/outsb` 字符串 IO = IDE/ATAPI 扇区传输），尾部混有表数据 —— 见 DRIVERS.md |
| 其余散段 | ~7KB | 各函数间数据、跳转表目标 |

---

## 6. 功能面（字符串 + 代码交叉证据）

- 设备/分区命名：`hda..hdd partition 1..4`
- 主菜单：`BOOTMANAGER`（0x8D8C）
- Setup 菜单（0x93A3 起）：`Boot countdown` / `Edit Boot Countdown` / `Show floppy boot` / `Show CDROM boot` / `Show USB boot` / `Force USB 1.1` / `Ignore USB devices` / `Last booted profile` / `Bootmanager font`
- 分区活动标志编辑：`b ... set boot partition` / `c ... clear partition` / `r ... remove bootflag`
- 内置工具：`** Copy to **`（分区数据复制/粘贴）
- 错误处理：`Boot error` / `No bootdevice selected` / `Can't read bootdevice`
- 错误路径均收口到 int 19h 重新引导。

## 7. BSS 关键变量（推断用途）

| 地址 | 用途 |
|---|---|
| 0xAB37/0xAB39 | 装载者 SS/SP（退出恢复） |
| 0xAB51 | 引导盘号（默认 0x80） |
| 0xA1A8 | A20 使能方法 |
| 0xB018 | 当前 VBE 模式（初始 0xFFFF） |
| 0xB075 | 已发现磁盘位图 |
| 0xB07C | MBR 常驻模式标志（由外部 bootstrap 预置） |
| 0xCF43/0xCF44 | 检测到的磁盘/USB 盘计数 |
| 0xABC4/0xABC5 | VBE 状态 / "VBE2" 信息块 |

## 8. 产物与覆盖统计

| 文件 | 内容 |
|---|---|
| `out/disasm_full.asm` | 带标签/交叉引用/BIOS 与端口注释的反汇编清单（地址 = 文件偏移） |
| `out/strings.txt` | 全部 ASCII 字符串 + 偏移 + 引用点 |
| `out/functions.txt` | 133 个调用目标、间接近似边界、候选跳转表、int 调用点 |
| `out/stats.txt` | 覆盖率、高熵块、gap 清单 |

覆盖率（analyze.py v3 终态）：43,321 字节解码（**99.4%**），420 函数入口，间接近似 0 处，无解码失败；blob 模块边界已证（UHCI 0x2353+20358B / OHCI 0x33E9+11759B / EHCI 0x469D+19562B / 重定向器 0x5841+140B）。动态侧（bootlab，见 DYNAMIC_FINDINGS.md）已点亮：EHCI 枚举+BOT 全周期、UHCI 端口/TD 引擎、OHCI MMIO/ED 引擎、WRITE(10) 落盘、数字引导端到端——三 USB 模块的寄存器语义与 BOT 语义全部实测闭环（DRIVERS.md §6.1-§6.8）。
