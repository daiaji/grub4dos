#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""EHCI probe v7: cheap instrumentation.
- exact-address MMIO read hooks (per-address, not whole-BAR) so polling
  other registers stays native speed
- UC_HOOK_MEM_WRITE on the modeled register addresses: logs the reset /
  doorbell sequence with tick stamps
- hot-loop sampler every 2M insns (cs/ip histogram)
- milestones on the transfer primitives (file->ip = X-0x469D+0x100)
Short run (120M insns) - enumeration + first transfers happen early."""
import os, sys, struct
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import bootlab
from bootlab import Plop

HSEG, GAP, M0 = 0x9A700, 0x100, 0x469D
def lin(foff): return HSEG + GAP + (foff - M0)

M = {
    0x4B9C: 'sub_4B9C enum entry',
    0x5316: 'sub_5316 QH fill',
    0x5416: 'sub_5416 qTD build',
    0x54A9: 'sub_54A9 link+doorbell',
    0x54B0: 'async gate wait',
    0x54E7: 'USBCMD|=0x20 ring',
    0x54F6: 'sub_54F6 usbint wait',
    0x54F8: 'usbint loop',
    0x4E20: 'sub_4E20 setup phase',
    0x4E56: 'sub_4E56 data phase',
    0x4E8F: 'sub_4E8F status phase',
}
hits, ticks_at = {}, {}
def mk(name):
    def cb(uc, addr, size, ud):
        hits[name] = hits.get(name, 0) + 1
        if name not in ticks_at:
            ticks_at[name] = p.ticks_fired
    return cb

writes = []
hot = {}
_n = [0]
def sampler(uc, cs_off):
    _n[0] += 1
    if _n[0] >= 2_000_000:
        _n[0] = 0
        cs = uc.reg_read(bootlab.X86_REG_CS)
        ip = uc.reg_read(bootlab.X86_REG_IP)
        hot[(cs, ip)] = hot.get((cs, ip), 0) + 1

p = Plop(keys='u', edd='USBD', tick_insns=200_000, feed_watchdog=True,
         hook_extra=sampler, max_insns=120_000_000)
p.bios.disk_attach(bootlab.default_disk())
u = p.uc
for foff, name in M.items():
    u.hook_add(bootlab.UC_HOOK_CODE, mk(name), begin=lin(foff), end=lin(foff))

bar = bootlab.Bios.PCI_EHCI_BAR
op_usbcmd  = bar + 0x10
op_usbsts  = bar + 0x14
portscs    = (bar + 0x10 + 0x24, bar + 0x10 + 0x40, bar + 0x10 + 0x44)
def wcb(uc, access, address, size, value, ud):
    if address == op_usbcmd or address == op_usbsts or address in portscs:
        writes.append((p.ticks_fired, hex(address), hex(value)))
for a in (op_usbcmd, op_usbsts) + portscs:
    u.hook_add(bootlab.UC_HOOK_MEM_WRITE, wcb, begin=a, end=a)

r = p.run()
print('run:', r, flush=True)
print('milestones:', {k: (v, ticks_at.get(k)) for k, v in hits.items()}, flush=True)
print('mmio writes (tick, addr, val):', writes[:40], flush=True)
print('hot (cs,ip):', {(hex(c), hex(i)): n for (c, i), n in
      sorted(hot.items(), key=lambda kv: -kv[1])[:10]}, flush=True)

def d32(a):  return struct.unpack('<I', bytes(u.mem_read(a, 4)))[0]
reg = bytes(u.mem_read(bar + 0x10, 0x30))
print('op regs:', reg.hex(' '), flush=True)
al = d32(bar + 0x10 + 0x18)
print('ASYNCLISTADDR = %08X' % al, flush=True)
if al:
    q = al
    for _ in range(8):
        d = [d32(q + 4*i) for i in range(8)]
        print('QH@%08X h=%08X ep=%08X cur=%08X n=%08X tok=%08X'
              % (q, d[0], d[1], d[3], d[4], d[6]), flush=True)
        if d[4] & 1 == 0:
            t = d[4] & ~0x1F
            td = [d32(t + 4*i) for i in range(8)]
            print('  qTD@%08X tok=%08X b0=%08X' % (t, td[2], td[3]), flush=True)
        q = d[0] & ~0x1F
        if d[0] & 1 or q == al or q == 0:
            break